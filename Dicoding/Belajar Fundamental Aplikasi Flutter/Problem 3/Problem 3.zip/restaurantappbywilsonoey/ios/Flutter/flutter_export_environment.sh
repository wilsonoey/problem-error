#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=D:\Dicoding_Indonesia_files\Flutter\Submission\flutter"
export "FLUTTER_APPLICATION_PATH=D:\Dicoding_Indonesia_files\Flutter\Submission\TestAwal\Belajar_Fundamental_Aplikasi_Flutter\Deployment\Submission_2\restaurantappbywilsonoey"
export "FLUTTER_TARGET=lib\main.dart"
export "FLUTTER_BUILD_DIR=build"
export "SYMROOT=${SOURCE_ROOT}/../build\ios"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=false"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.packages"
