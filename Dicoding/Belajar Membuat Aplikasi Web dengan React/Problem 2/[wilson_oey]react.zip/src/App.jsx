import React from "react";
import { BrowserRouter, Switch, Route } from "react-router-dom";

import HomePage from "./pages/HomePage";
import AddNewPage from "./pages/AddNewPage";
import DetailPage from "./pages/DetailPage";
import ArchivePage from "./pages/ArchivePage";
import { useDarkMode } from "./hooks/useDarkMode";
// import { useLocale } from "./hooks/useLocale";

function App() {
  const [theme] = useDarkMode();
  // const [theme, toggleTheme] = useDarkMode();
  // const [locale, toggleLocale] = useLocale();

  return (
    <BrowserRouter>
      <div className={`app-container ${theme}`}>
        
        <header>
          <h1>
            <a href="/">Aplikasi Catatan</a>
          </h1>
          <nav className="navigation">
            <ul>
              <li>
                <a href="/archives">Arsip</a>
              </li>
            </ul>
          </nav>
        </header>
        <Switch>
          <Route path="/" exact component={HomePage} />
          <Route path="/add-new" component={AddNewPage} />
          <Route path="/note/:id" component={DetailPage} />
          <Route path="/archive" component={ArchivePage} />
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;
