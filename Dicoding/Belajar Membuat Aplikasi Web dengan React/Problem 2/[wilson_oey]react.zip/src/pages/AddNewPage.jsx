import React, { useState } from "react";
import { Link } from "react-router-dom";
import { addNote } from "../utils/local-data";

function AddNewPage() {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");

  const handleInputChange = (event) => {
    const { name, value } = event.target;

    if (name === "title") {
      setTitle(value);
    } else {
      setBody(value);
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    addNote({ title, body });
    setTitle("");
    setBody("");
  };

  return (
    <main>
      <form className="add-new-page__input" onSubmit={handleSubmit}>
        <input
          type="text"
          name="title"
          className="add-new-page__input__title"
          placeholder="Catatan rahasia"
          autoFocus
          value={title}
          data-placeholder="Untitled"
          onChange={handleInputChange}
        />
        <textarea
          name="body"
          className="add-new-page__input__body"
          placeholder="Sebenarnya saya adalah ..."
          value={body}
          data-placeholder="Nothing to note"
          onChange={handleInputChange}
        />
      </form>
      <div className="add-new-page__action">
        <Link to="/">
          <button className="action">&#x2190;</button>
        </Link>
        <Link to="/">
          <button className="action" type="submit" form="form">&#x2714;</button>
        </Link>
      </div>
    </main>
  );
}

export default AddNewPage;