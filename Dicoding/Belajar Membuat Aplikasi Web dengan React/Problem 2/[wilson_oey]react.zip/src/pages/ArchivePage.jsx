import React, { useState } from "react";
import { Link } from "react-router-dom";
import { getArchivedNotes, deleteNote, unarchiveNote } from "../utils/local-data";
import { showFormattedDate } from "../utils/index";

function ArchivePage() {
  const [notes, setNotes] = useState(getArchivedNotes());

  const deleteNoteHandler = (id) => {
    deleteNote(id);
    setNotes(getArchivedNotes());
  };

  const unarchiveNoteHandler = (id) => {
    unarchiveNote(id);
    setNotes(getArchivedNotes());
  };

  const renderNotesList = () => {
    if (notes.length === 0) {
      return (
        <div className="notes-list-empty">
          <p>No archived notes.</p>
        </div>
      );
    }

    return (
      <div className="notes-list">
        {notes.map((note) => (
          <div className="note-item" key={note.id}>
            <h2 className="note-item__title">{note.title}</h2>
            <p className="note-item__createdAt">
              {showFormattedDate(note.createdAt)}
            </p>
            <p className="note-item__body">{note.body}</p>
            <div className="note-item__actions">
              <Link to={`note/${note.id}`}>View</Link>
              <button onClick={() => deleteNoteHandler(note.id)}>Delete</button>
              <button onClick={() => unarchiveNoteHandler(note.id)}>
                Unarchive
              </button>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return <main>{renderNotesList()}</main>;
}

export default ArchivePage;