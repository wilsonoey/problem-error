import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getNote, editNote, deleteNote, archiveNote } from "../utils/local-data";
import { showFormattedDate } from "../utils/index";

function DetailPage(props) {
  const [note, setNote] = useState({});
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");

  useEffect(() => {
    const foundNote = getNote(props.match.params.id);
    setNote(foundNote);
    setTitle(foundNote.title);
    setBody(foundNote.body);
  }, []);

  // const handleInputChange = (event) => {
  //   const { name, value } = event.target;

  //   if (name === "title") {
  //     setTitle(value);
  //   } else {
  //     setBody(value);
  //   }
  // };

  const handleSubmit = (event) => {
    event.preventDefault();
    editNote({ id: note.id, title, body });
  };

  const deleteNoteHandler = (id) => {
    deleteNote(id);
  };

  const archiveNoteHandler = (id) => {
    archiveNote(id);
  };

  return (
    <main>
      <div className="detail-page">
        <form className="detail-page__note__input" onSubmit={handleSubmit}>
          <div className="detail-page__title">{title}</div>
          <div className="detail-page__createdAt">{showFormattedDate(note.createdAt)}</div>
          <div className="detail-page__body">{body}</div>
        </form>
      </div>
      <div className="detail-page__action">
        <Link to="/">
          <button className="action" onClick={() => archiveNoteHandler(note.id)}>&#x2709;</button>
        </Link>
        <Link to="/">
          <button className="action" onClick={() => deleteNoteHandler(note.id)} href="/">X</button>
        </Link>
      </div>
    </main>
  );
}

export default DetailPage;