import React, { useState } from "react";
import { Link } from "react-router-dom";
import { getActiveNotes, deleteNote, archiveNote } from "../utils/local-data";
import { showFormattedDate } from "../utils/index";

function HomePage() {
  const [notes, setNotes] = useState(getActiveNotes());

  const deleteNoteHandler = (id) => {
    deleteNote(id);
    setNotes(getActiveNotes());
  };

  const archiveNoteHandler = (id) => {
    archiveNote(id);
    setNotes(getActiveNotes());
  };

  const renderNotesList = () => {
    if (notes.length === 0) {
      return (
        <div className="notes-list-empty">
          <p>
            You have no notes. Create one <Link to="/add-new">here</Link>.
          </p>
        </div>
      );
    }

    return (
      <div className="notes-list">
        {notes.map((note) => (
          <div className="note-item" key={note.id}>
            <h2 className="note-item__title">{note.title}</h2>
            <p className="note-item__createdAt">
              {showFormattedDate(note.createdAt)}
            </p>
            <p className="note-item__body">{note.body}</p>
            <div className="note-item__actions">
              <Link to={`note/${note.id}`}>View</Link>
              <button className="note-item__delete-button" onClick={() => deleteNoteHandler(note.id)}>Delete</button>
              <button className="note-item__delete-button" onClick={() => archiveNoteHandler(note.id)}>
                Archive
              </button>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <main>
      {renderNotesList()}
      <div className="homepage__action">
        <Link to="/add-new">
          <button className="action">+</button>
        </Link>
      </div>
    </main>
  );
}

export default HomePage;