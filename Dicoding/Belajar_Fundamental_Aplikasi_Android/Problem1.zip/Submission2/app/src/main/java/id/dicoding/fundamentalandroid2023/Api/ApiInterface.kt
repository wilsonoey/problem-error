package id.dicoding.fundamentalandroid2023.Api

import id.dicoding.fundamentalandroid2023.apiKey
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiInterface {
    @GET("users/{username}")
    fun getDetail(
        @Path("username") username: String,
        @Header("Authorization") token: String = "token ${apiKey}"
    ): Call<ApiItemStructure>

    @GET("/users/{username}/followers")
    fun getFollowers(
        @Path("username") username: String,
        @Header("Authorization") token: String = "token ${apiKey}"
    ): Call<List<ApiItemStructure>>

    @GET("/users/{username}/following")
    fun getFollowing(@Path("username") username: String,
                     @Header("Authorization") token: String = "token ${apiKey}"
    ): Call<List<ApiItemStructure>>

    @GET("search/users")
    fun searchUser(
        @Query("q") query: String,
        @Header("Authorization") token: String = "token ${apiKey}"
    ): Call<ApiStructure>

    @GET("users")
    fun getUsersList(): Call<List<ApiItemStructure>>
}