package id.dicoding.fundamentalandroid2023.Api

data class ApiItemStructure(
    val login: String? = null,
    val avatar_url: String? = null,
    val url: String? = null,

    val followers: Int? = null,
    val following: Int? = null,
    val name: String? = null,
    val following_url: String? = null,
    val followers_url: String? = null,

    val gists_url: String? = null,
    val repos_url: String? = null,
    val created_at: String? = null,
    val type: String? = null,
    val blog: String? = null,
    val subscriptions_url: String? = null,
    val updated_at: String? = null,
    val site_admin: Boolean? = null,
    val company: String? = null,
    val id: Int = 0,
    val public_repos: Int? = null,
    val gravatar_id: String? = null,
    val organizations_url: String? = null,
    val public_gists: Int? = null,
    val location: String? = null,
)