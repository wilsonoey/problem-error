package id.dicoding.fundamentalandroid2023.Api

data class ApiStructure (
    val total_count: Int,
    val incomplete_results: Boolean,
    val items: List<ApiItemStructure>
)