package id.dicoding.fundamentalandroid2023.UI

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import id.dicoding.fundamentalandroid2023.Api.ApiClient
import id.dicoding.fundamentalandroid2023.Api.ApiItemStructure
import id.dicoding.fundamentalandroid2023.R
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailActivity : AppCompatActivity() {
    private lateinit var apiClient: ApiClient

    companion object {
        const val EXTRA_USER = "extra_user"
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_followers,
            R.string.tab_following
        )
    }

    private lateinit var fullNameTextView: TextView
    private lateinit var usernameTextView: TextView
    private lateinit var followingCountTextView: TextView
    private lateinit var followersCountTextView: TextView
    private lateinit var profilePictureImageView: ImageView
    private lateinit var loadingView: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        loadingView = findViewById(R.id.loading_detail)
        fullNameTextView = findViewById(R.id.detailname)
        usernameTextView = findViewById(R.id.detailusername)
        followingCountTextView = findViewById(R.id.detailfollowingcount)
        followersCountTextView = findViewById(R.id.detailfollowerscount)
        profilePictureImageView = findViewById(R.id.detailimage)

        val username = intent.getStringExtra(EXTRA_USER)
        apiClient = ApiClient(OkHttpClient())
        getDetail(username)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val sectionsPagerAdapter = FragmentsAdapter(this)
        val viewPager: ViewPager2 = findViewById(R.id.view_pager)
        viewPager.adapter = sectionsPagerAdapter
        val tabs: TabLayout = findViewById(R.id.tabs)
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
            println("Tab ke-${position}")
        }.attach()
        supportActionBar?.elevation = 0f
    }

    private fun getDetail(username: String?) {
        apiClient.getClient().getDetail(username!!).enqueue(object : Callback<ApiItemStructure> {
            override fun onResponse(call: Call<ApiItemStructure>, response: Response<ApiItemStructure>) {
                loadingView.visibility = View.GONE
                if(response.isSuccessful) {
                    val userData = response.body()
                    fullNameTextView.text = userData?.name
                    usernameTextView.text = userData?.login
                    followingCountTextView.text = ("${userData?.following.toString()}\nFollowing")
                    followersCountTextView.text = ("${userData?.followers.toString()}\n" +
                            "Followers")
                    Glide.with(this@DetailActivity).load(userData?.avatar_url).into(profilePictureImageView)
                }
            }

            override fun onFailure(call: Call<ApiItemStructure>, t: Throwable) {
                Toast.makeText(applicationContext, t.message, Toast.LENGTH_SHORT).show()
            }
        })
    }
}