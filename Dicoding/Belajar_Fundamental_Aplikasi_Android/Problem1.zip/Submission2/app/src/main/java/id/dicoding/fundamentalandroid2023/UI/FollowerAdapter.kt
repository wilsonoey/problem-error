package id.dicoding.fundamentalandroid2023.UI

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import id.dicoding.fundamentalandroid2023.Api.ApiItemStructure
import id.dicoding.fundamentalandroid2023.R

class FollowerAdapter(private val followerDataList: List<ApiItemStructure>) : RecyclerView.Adapter<FollowerAdapter.FollowerViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FollowerViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.fragment_followers, parent, false)
        return FollowerViewHolder(view)
    }

    override fun getItemCount() = followerDataList.size

    override fun onBindViewHolder(holder: FollowerViewHolder, position: Int) {
        val followerData = followerDataList[position]
        Glide.with(holder.itemView.context).load(followerData.avatar_url).into(holder.avatarImageView)
        holder.nameTextView.text = followerData.login
        holder.urlTextView.text = followerData.url
    }

    inner class FollowerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView: TextView = itemView.findViewById(R.id.name)
        val avatarImageView: ImageView = itemView.findViewById(R.id.avatar)
        val urlTextView: TextView = itemView.findViewById(R.id.url)
    }
}