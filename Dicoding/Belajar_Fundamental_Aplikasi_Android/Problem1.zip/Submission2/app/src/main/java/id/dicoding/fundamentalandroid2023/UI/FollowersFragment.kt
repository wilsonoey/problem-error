package id.dicoding.fundamentalandroid2023.UI

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import id.dicoding.fundamentalandroid2023.Api.ApiClient
import id.dicoding.fundamentalandroid2023.Api.ApiInterface
import id.dicoding.fundamentalandroid2023.Api.ApiItemStructure
import id.dicoding.fundamentalandroid2023.R
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FollowersFragment : Fragment() {
    private lateinit var apiClient: ApiClient
    private lateinit var username: String
    private lateinit var apiInterface: ApiInterface
    private lateinit var recyclerView: RecyclerView
    private lateinit var followerAdapter: FollowerAdapter
    private lateinit var loadingView: ProgressBar
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_followers, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadingView = view.findViewById(R.id.loading_followers)
        recyclerView = view.findViewById(R.id.followers_recycler_view)
        apiClient = ApiClient(OkHttpClient())
        apiInterface = apiClient.getClient()
        username = DetailActivity.EXTRA_USER
        println("Nama Username : ${username}")
        getFollowersList(username)
    }

    private fun getFollowersList(username: String) {
        apiInterface.getFollowers(username).enqueue(object : Callback<List<ApiItemStructure>> {
            override fun onResponse(
                call: Call<List<ApiItemStructure>>,
                response: Response<List<ApiItemStructure>>
            ) {
                loadingView.visibility = View.GONE
                if (response.isSuccessful) {
                    val followerDataList = response.body()
                    followerAdapter = FollowerAdapter(followerDataList!!)
                    recyclerView.layoutManager = LinearLayoutManager(context)
                    recyclerView.adapter = followerAdapter
                }
            }
            override fun onFailure(call: Call<List<ApiItemStructure>>, t: Throwable) {
            }
        })
    }
}