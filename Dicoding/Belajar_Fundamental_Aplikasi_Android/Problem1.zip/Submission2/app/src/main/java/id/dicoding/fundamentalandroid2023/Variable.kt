package id.dicoding.fundamentalandroid2023

const val apiUrl = "https://api.github.com/"
const val apiKey = "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"