package id.dicoding.fundamentalandroid2023.Api

import id.dicoding.fundamentalandroid2023.BuildConfig
import id.dicoding.fundamentalandroid2023.apiKey
import id.dicoding.fundamentalandroid2023.apiUrl
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class ApiClient(okHttpClient: OkHttpClient) {
    fun getClient(): ApiInterface {
        val okHttpClient = OkHttpClient.Builder().addInterceptor { chain ->
            val original = chain.request()
            val request = original.newBuilder()
                .header("Authorization", "token $apiKey")
                .method(original.method, original.body)
                .build()
            chain.proceed(request)
        }.apply {
            if (BuildConfig.DEBUG) {
                val logging = HttpLoggingInterceptor()
                logging.setLevel(HttpLoggingInterceptor.Level.BODY)
                addInterceptor(logging)
            }
        }.build()
        val retrofit = Retrofit.Builder()
            .baseUrl(apiUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .client(okHttpClient)
            .build()
        return retrofit.create(ApiInterface::class.java)
    }
}