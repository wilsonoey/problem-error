package id.dicoding.fundamentalandroid2023.Api

import id.dicoding.fundamentalandroid2023.apiUrl
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class ApiClient(okHttpClient: OkHttpClient) {
    fun getClient(): ApiInterface {
        val okHttpClient = OkHttpClient.Builder().build()
        val retrofit = Retrofit.Builder()
            .baseUrl(apiUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .client(okHttpClient)
            .build()
        return retrofit.create(ApiInterface::class.java)
    }
}