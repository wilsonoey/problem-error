package id.dicoding.fundamentalandroid2023

const val apiUrl = "https://api.github.com/"
const val apiKey = "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"