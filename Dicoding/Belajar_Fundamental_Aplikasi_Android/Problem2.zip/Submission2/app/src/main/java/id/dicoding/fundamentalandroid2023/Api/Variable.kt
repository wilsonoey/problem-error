package id.dicoding.fundamentalandroid2023

const val apiUrl = "https://api.github.com/"
const val apiKey = "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"