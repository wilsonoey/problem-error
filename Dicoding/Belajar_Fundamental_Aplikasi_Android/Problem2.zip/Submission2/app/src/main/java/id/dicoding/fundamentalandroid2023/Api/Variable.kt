package id.dicoding.fundamentalandroid2023

const val apiUrl = "https://api.github.com/"
const val apiKey = "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"