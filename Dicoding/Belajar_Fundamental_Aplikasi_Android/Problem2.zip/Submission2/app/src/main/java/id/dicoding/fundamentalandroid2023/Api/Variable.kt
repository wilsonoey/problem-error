package id.dicoding.fundamentalandroid2023

const val apiUrl = "https://api.github.com/"
const val apiKey = "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"