package id.dicoding.fundamentalandroid2023.Favorite

import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.widget.ImageView
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.google.gson.Gson

@TypeConverters(FavoriteConverter::class)
class FavoriteConverter {
    @TypeConverter
    fun fromdrawable(avatar_url: Drawable?): String? {
        return Gson().toJson(avatar_url)
    }

    @TypeConverter
    fun todrawable(avatar_url: String?): Drawable? {
        return Gson().fromJson(avatar_url, Drawable::class.java)
    }
}