package id.dicoding.fundamentalandroid2023.Favorite

import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.widget.ImageView
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorite_user")
data class FavoriteUser(
    @PrimaryKey
    @field:ColumnInfo(name = "id")
    val id: Int,
    @field:ColumnInfo(name = "login")
    val login: String?,
    @field:ColumnInfo(name = "avatar_url")
    val avatar_url: String?,
    @field:ColumnInfo(name = "name")
    val name: String?,
    @field:ColumnInfo(name = "location")
    val location: String?,
    @field:ColumnInfo(name = "followers")
    val followers: String?,
    @field:ColumnInfo(name = "following")
    val following: String?,
) : java.io.Serializable