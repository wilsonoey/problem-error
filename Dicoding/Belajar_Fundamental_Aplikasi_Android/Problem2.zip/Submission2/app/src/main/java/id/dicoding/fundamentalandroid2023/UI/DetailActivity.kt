package id.dicoding.fundamentalandroid2023.UI

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.core.graphics.drawable.toBitmap
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import id.dicoding.fundamentalandroid2023.Api.ApiClient
import id.dicoding.fundamentalandroid2023.Api.ApiItemStructure
import id.dicoding.fundamentalandroid2023.Favorite.FavoriteConverter
import id.dicoding.fundamentalandroid2023.Favorite.FavoriteUser
import id.dicoding.fundamentalandroid2023.Favorite.UserDatabase
import id.dicoding.fundamentalandroid2023.R
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailActivity : AppCompatActivity() {
    private lateinit var apiClient: ApiClient

    companion object {
        const val EXTRA_USER = "extra_user"
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_followers,
            R.string.tab_following
        )
    }

    private lateinit var fullNameTextView: TextView
    private lateinit var usernameTextView: TextView
    private lateinit var followingCountTextView: TextView
    private lateinit var followersCountTextView: TextView
    private lateinit var profilePictureImageView: ImageView
    private lateinit var loadingView: ProgressBar
    private lateinit var detaillocationTextView: TextView
    private var isFavorite: Boolean = false
    private var id: Int = (0..1000000000).random()

    @SuppressLint("UseCompatLoadingForDrawables")
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.detail, menu)
        menu.findItem(R.id.favorite).icon = if (isFavorite) {
            getDrawable(R.drawable.ic_baseline_favorite_24)
        } else {
            getDrawable(R.drawable.ic_baseline_favorite_border_24)
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.favorite -> {
                val user = FavoriteUser(
                    id,
                    usernameTextView.text.toString(),
//                    FavoriteConverter().todrawable("https://avatars.githubusercontent.com/u/76278250?v=4"),
                    profilePictureImageView.drawable.toBitmap().toString(),
                    fullNameTextView.text.toString(),
                    detaillocationTextView.text.toString(),
                    followingCountTextView.text.toString(),
                    followersCountTextView.text.toString()
                )
                CoroutineScope(Dispatchers.IO).launch {
                    if (isFavorite) {
                        UserDatabase.getInstance(this@DetailActivity)?.favoriteUserDao()
                            ?.deleteFavoriteUser(user.id)
                        isFavorite = false
                    } else {
                        UserDatabase.getInstance(this@DetailActivity)?.favoriteUserDao()
                            ?.insertFavoriteUser(user)
                        isFavorite = true
                    }
                    runOnUiThread {
                        invalidateOptionsMenu()
                    }
                }
            }
        }
        println("Status item is ${super.onOptionsItemSelected(item)}")
        return super.onOptionsItemSelected(item)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        loadingView = findViewById(R.id.loading_detail)
        fullNameTextView = findViewById(R.id.detailname)
        usernameTextView = findViewById(R.id.detailusername)
        followingCountTextView = findViewById(R.id.detailfollowingcount)
        followersCountTextView = findViewById(R.id.detailfollowerscount)
        profilePictureImageView = findViewById(R.id.detailimage)
        detaillocationTextView = findViewById(R.id.detaillocation)

        val username = intent.getStringExtra(EXTRA_USER)
        apiClient = ApiClient(OkHttpClient())
        getDetail(username)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    private fun getDetail(username: String?) {
        apiClient.getClient().getDetail(username!!).enqueue(object : Callback<ApiItemStructure> {
            override fun onResponse(call: Call<ApiItemStructure>, response: Response<ApiItemStructure>) {
                loadingView.visibility = View.GONE
                if(response.isSuccessful) {
                    val userData = response.body()
                    fullNameTextView.text = userData?.name
                    usernameTextView.text = userData?.login
                    followingCountTextView.text = "${userData?.following.toString()}\nFollowing"
                    followersCountTextView.text = "${userData?.followers.toString()}\n" +
                            "Followers"
                    Glide.with(this@DetailActivity).load(userData?.avatar_url).into(profilePictureImageView)
                    detaillocationTextView.text = userData?.location

                    val sectionsPagerAdapter = FragmentsAdapter(this@DetailActivity, userData?.login!!)
                    val viewPager: ViewPager2 = findViewById(R.id.view_pager)
                    viewPager.adapter = sectionsPagerAdapter
                    val tabs: TabLayout = findViewById(R.id.tabs)
                    TabLayoutMediator(tabs, viewPager) { tab, position ->
                        tab.text = resources.getString(TAB_TITLES[position])
                    }.attach()
                    supportActionBar?.elevation = 0f
                }
            }

            override fun onFailure(call: Call<ApiItemStructure>, t: Throwable) {
                Toast.makeText(applicationContext, t.message, Toast.LENGTH_SHORT).show()
            }
        })
    }
}