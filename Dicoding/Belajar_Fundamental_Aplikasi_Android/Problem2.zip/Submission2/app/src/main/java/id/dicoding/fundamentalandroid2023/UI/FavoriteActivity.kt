package id.dicoding.fundamentalandroid2023.UI

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import id.dicoding.fundamentalandroid2023.Favorite.UserDatabase
import id.dicoding.fundamentalandroid2023.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FavoriteActivity : AppCompatActivity() {
    private lateinit var loadingView: ProgressBar
    private lateinit var userDatabase: UserDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.favorite)
        loadingView = findViewById(R.id.loading_favorite)
        userDatabase = UserDatabase.getInstance(this)!!
        GlobalScope.launch(Dispatchers.IO) {
            val favoriteUsers = userDatabase.favoriteUserDao().getFavoriteUser()
            withContext(Dispatchers.Main) {
                loadingView.visibility = View.GONE
                val favoriteAdapter = FavoriteAdapter(favoriteUsers)
                val recyclerView = findViewById<RecyclerView>(R.id.favorite_recycler_view)
                recyclerView.adapter = favoriteAdapter
                recyclerView.layoutManager = LinearLayoutManager(this@FavoriteActivity)
            }
        }
    }
}