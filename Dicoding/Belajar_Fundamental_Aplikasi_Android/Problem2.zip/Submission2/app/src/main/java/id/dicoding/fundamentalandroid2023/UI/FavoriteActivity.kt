package id.dicoding.fundamentalandroid2023.UI

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import id.dicoding.fundamentalandroid2023.Favorite.FavoriteUserDao
import id.dicoding.fundamentalandroid2023.Favorite.UserDatabase
import id.dicoding.fundamentalandroid2023.R
import kotlinx.coroutines.*

class FavoriteActivity : AppCompatActivity() {
    private lateinit var loadingView: ProgressBar
    private var userDao: FavoriteUserDao? = null
    private var userDatabase: UserDatabase? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.favorite)
        println("My data is $userDao and $userDatabase")
        loadingView = findViewById(R.id.loading_favorite)
        userDatabase = UserDatabase.getInstance(this)
        userDao = userDatabase?.favoriteUserDao()
        CoroutineScope(Dispatchers.Main).launch {
            val favoriteUser = withContext(Dispatchers.IO) {
                userDao?.getFavoriteUser()
            }
            if (favoriteUser != null) {
                val adapter = FavoriteAdapter(favoriteUser)
                val recyclerView = findViewById<RecyclerView>(R.id.favorite_recycler_view)
                recyclerView.layoutManager = LinearLayoutManager(this@FavoriteActivity)
                recyclerView.adapter = adapter
                loadingView.visibility = View.GONE
            }
        }
    }
}