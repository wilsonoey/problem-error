package id.dicoding.fundamentalandroid2023.UI

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import id.dicoding.fundamentalandroid2023.Favorite.FavoriteUser
import id.dicoding.fundamentalandroid2023.databinding.ListItemBinding

class FavoriteAdapter(private val listFavorite: List<FavoriteUser>) : RecyclerView.Adapter<FavoriteAdapter.FavoriteViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteViewHolder {
        val view = ListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FavoriteViewHolder(view)
    }

    override fun getItemCount() = listFavorite.size

    override fun onBindViewHolder(holder: FavoriteViewHolder, position: Int) {
        with(holder){
            binding.apply {
                val favoriteData = listFavorite[position]
                Glide.with(itemView.context).load(favoriteData.avatar_url).into(avatarImageView)
                nameTextView.text = favoriteData.login
                urlTextView.text = null
                holder.itemView.setOnClickListener{
                    val intentDetail = Intent(holder.itemView.context, DetailActivity::class.java)
                    intentDetail.putExtra(DetailActivity.EXTRA_USER, favoriteData.login)
                    holder.itemView.context.startActivity(intentDetail)
                }
            }
        }
    }

    inner class FavoriteViewHolder(val binding: ListItemBinding) : RecyclerView.ViewHolder(binding.root) {
        val avatarImageView: ImageView = binding.avatar
        val nameTextView: TextView = binding.name
        val urlTextView: TextView = binding.url
    }
}