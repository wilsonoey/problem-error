package id.dicoding.fundamentalandroid2023.UI

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import id.dicoding.fundamentalandroid2023.R
import id.dicoding.fundamentalandroid2023.Api.ApiItemStructure

class ListAdapter(private val userDataList: List<ApiItemStructure>) : RecyclerView.Adapter<ListAdapter.UserDataViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserDataViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_item, parent, false)
        return UserDataViewHolder(view)
    }

    override fun getItemCount() = userDataList.size

    override fun onBindViewHolder(holder: UserDataViewHolder, position: Int) {
        val userData = userDataList[position]
        Glide.with(holder.itemView.context).load(userData.avatar_url).into(holder.avatarImageView)
        holder.nameTextView.text = userData.login
        holder.urlTextView.text = userData.url
        holder.itemView.setOnClickListener{
            val intentDetail = Intent(holder.itemView.context, DetailActivity::class.java)
            intentDetail.putExtra(DetailActivity.EXTRA_USER, userData.login)
            holder.itemView.context.startActivity(intentDetail)
        }
    }

    inner class UserDataViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView: TextView = itemView.findViewById(R.id.name)
        val avatarImageView: ImageView = itemView.findViewById(R.id.avatar)
        val urlTextView: TextView = itemView.findViewById(R.id.url)
    }
}