package id.dicoding.fundamentalandroid2023.Favorite

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorite_user")
data class FavoriteUser(
    @PrimaryKey
    @field:ColumnInfo(name = "id")
    val id: Int,
    @field:ColumnInfo(name = "login")
    val login: String?,
    @field:ColumnInfo(name = "avatar_url")
    val avatar_url: String?,
    @field:ColumnInfo(name = "name")
    val name: String?,
    @field:ColumnInfo(name = "location")
    val location: String?,
    @field:ColumnInfo(name = "followers")
    val followers: String?,
    @field:ColumnInfo(name = "following")
    val following: String?,
//    @field:ColumnInfo(name = "followers_url")
//    val followers_url: String?,
//    @field:ColumnInfo(name = "following_url")
//    val following_url: String?,
) : java.io.Serializable