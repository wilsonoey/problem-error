package id.dicoding.fundamentalandroid2023

const val apiUrl = "https://api.github.com/"
const val apiKey = "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"