package id.dicoding.fundamentalandroid2023.UI

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.lifecycle.LiveData
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import id.dicoding.fundamentalandroid2023.Favorite.FavoriteUser
import id.dicoding.fundamentalandroid2023.databinding.ListItemBinding

class FavoriteAdapter(private val listFavorite: LiveData<List<FavoriteUser>>) : RecyclerView.Adapter<FavoriteAdapter.FavoriteViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteViewHolder {
        val view = ListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FavoriteViewHolder(view)
    }
    override fun getItemCount() = listFavorite.value?.size ?: 0
    override fun onBindViewHolder(holder: FavoriteViewHolder, position: Int) {
        with(holder) {
            itemView.apply {
                val favorite = listFavorite.value?.get(position)
                Glide.with(context).load(favorite?.avatar_url).into(avatar)
                name.text = favorite?.name
                url.text = null
            }
        }
    }
    inner class FavoriteViewHolder(itemView: ListItemBinding) : RecyclerView.ViewHolder(itemView.root) {
        val avatar = itemView.avatar
        val name = itemView.name
        val url = itemView.url
    }
}