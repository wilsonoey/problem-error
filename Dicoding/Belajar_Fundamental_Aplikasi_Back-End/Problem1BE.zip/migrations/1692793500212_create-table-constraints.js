/* eslint-disable camelcase */

exports.shorthands = undefined;

exports.up = (pgm) => {
  // connect using foreign key constraints from id in playlists to playlist_id in playlist_songs
  pgm.addConstraint('playlist_songs', 'fk_playlist_songs.playlist_id_playlists.id', 'FOREIGN KEY(playlist_id) REFERENCES playlists(id) ON DELETE CASCADE');
  // connect using foreign key constraints from id in playlists to playlist_id in colaborations
  pgm.addConstraint('colaborations', 'fk_colaborations.playlist_id_playlists.id', 'FOREIGN KEY(playlist_id) REFERENCES playlists(id) ON DELETE CASCADE');
  // connect using foreign key constraints from id in songs to song_id in playlist_songs
  pgm.addConstraint('playlist_songs', 'fk_playlist_songs.song_id_songs.id', 'FOREIGN KEY(song_id) REFERENCES songs(id) ON DELETE CASCADE');
  // connect using foreign key constraints from id in users to owner in playlists
  pgm.addConstraint('playlists', 'fk_playlists.owner_users.id', 'FOREIGN KEY(owner) REFERENCES users(id) ON DELETE CASCADE');
  // connect using foreign key constraints from id in users to user_id in colaborations
  pgm.addConstraint('colaborations', 'fk_colaborations.user_id_users.id', 'FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE');
  // connect using foreign key constraints from id in albums to album_id in songs
  pgm.addConstraint('songs', 'fk_songs.album_id_albums.id', 'FOREIGN KEY(album_id) REFERENCES albums(id) ON DELETE CASCADE');
};

exports.down = (pgm) => {
  pgm.dropConstraint('playlist_songs', 'fk_playlist_songs.playlist_id_playlists.id');
  pgm.dropConstraint('colaborations', 'fk_colaborations.playlist_id_playlists.id');
  pgm.dropConstraint('playlist_songs', 'fk_playlist_songs.song_id_songs.id');
  pgm.dropConstraint('playlists', 'fk_playlists.owner_users.id');
  pgm.dropConstraint('colaborations', 'fk_colaborations.user_id_users.id');
  pgm.dropConstraint('songs', 'fk_songs.album_id_albums.id');
};
