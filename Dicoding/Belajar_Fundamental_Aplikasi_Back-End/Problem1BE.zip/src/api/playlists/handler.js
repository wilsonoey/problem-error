class PlaylistsHandler {
  constructor(service, validator) {
    this._service = service;
    this._validator = validator;
  }

  postPlaylistHandler = async (request, h) => {
    // input based from validation
    this._validator.validatePostPlaylistPayload(request.payload);
    const playlistId = await this._service.addPlaylist(request.payload);
    const response = h.response({
      status: 'success',
      message: 'Playlist berhasil ditambahkan',
      data: {
        playlistId,
      },
    });
    response.code(201);
    return response;
  };

  postSongToPlaylistHandler = async (request, h) => {
    this._validator.validatePostSongToPlaylistPayload(request.payload);
    const { id: credentialId } = request.auth.credentials;
    const { playlistId } = request.params;
    await this._service.verifyPlaylistAccess(playlistId, credentialId);
    await this._service.addSongToPlaylist(request.payload);
    const response = h.response({
      status: 'success',
      message: 'Lagu berhasil ditambahkan ke playlist',
    });
    response.code(201);
    return response;
  };

  getPlaylistsHandler = async () => {
    const playlists = await this._service.getPlaylists();
    return {
      status: 'success',
      data: {
        playlists,
      },
    };
  };

  getPlaylistWithSongsByIdHandler = async (request) => {
    const { id } = request.params;
    const { id: credentialId } = request.auth.credentials;
    await this._service.verifyPlaylistAccess(id, credentialId);
    const playlist = await this._service.getPlaylistWithSongsById(id);
    return {
      status: 'success',
      data: {
        playlist,
      },
    };
  };

  deleteSongFromPlaylistHandler = async (request) => {
    this._validator.validateDeleteSongFromPlaylistPayload(request.payload);
    const { id: credentialId } = request.auth.credentials;
    const { playlistId } = request.params;
    await this._service.verifyPlaylistAccess(playlistId, credentialId);
    await this._service.deleteSongFromPlaylist(request.payload);
    return {
      status: 'success',
      message: 'Lagu berhasil dihapus dari playlist',
    };
  };

  deletePlaylistByIdHandler = async (request) => {
    const { id } = request.params;
    const { id: credentialId } = request.auth.credentials;
    await this._service.verifyPlaylistOwner(id, credentialId);
    await this._service.deletePlaylistById(id);
    return {
      status: 'success',
      message: 'Playlist berhasil dihapus',
    };
  };
}

module.exports = PlaylistsHandler;
