const Joi = require('joi');

const postschemeauth = Joi.object({
  username: Joi.string().required(),
  password: Joi.string().required(),
});

const tokenschemeauth = Joi.object({
  refreshToken: Joi.string().required(),
});

module.exports = { postschemeauth, tokenschemeauth };
