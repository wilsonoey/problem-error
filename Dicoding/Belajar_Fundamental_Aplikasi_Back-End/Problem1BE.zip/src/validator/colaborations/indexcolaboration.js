const InvariantError = require('../../exceptions/InvariantError');
const { schemeindexcolaboration } = require('./schemecolaboration');

const IndexColaborationValidator = {
  validateIndexColaborationPayload: (payload) => {
    const validationResult = schemeindexcolaboration.validate(payload);
    if (validationResult.error) {
      throw new InvariantError(validationResult.error.message);
    }
  },
};

module.exports = IndexColaborationValidator;
