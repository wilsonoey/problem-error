const Joi = require('joi');

const schemecolaboration = Joi.object({
  playlistId: Joi.string().required(),
});

module.exports = { schemecolaboration };
