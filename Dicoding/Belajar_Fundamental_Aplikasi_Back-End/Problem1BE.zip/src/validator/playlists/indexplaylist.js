const InvariantError = require('../../exceptions/InvariantError');
const { postplaylistschema, songtoplaylistpayloadschema } = require('./schemeplaylist');

const PlaylistsValidator = {
  validatePostPlaylistPayload: (payload) => {
    const validationResult = postplaylistschema.validate(payload);
    if (validationResult.error) {
      throw new InvariantError(validationResult.error.message);
    }
  },
  validatePostSongToPlaylistPayload: (payload) => {
    const validationResult = songtoplaylistpayloadschema.validate(payload);
    if (validationResult.error) {
      throw new InvariantError(validationResult.error.message);
    }
  },
  validateDeleteSongFromPlaylistPayload: (payload) => {
    const validationResult = songtoplaylistpayloadschema.validate(payload);
    if (validationResult.error) {
      throw new InvariantError(validationResult.error.message);
    }
  },
};

module.exports = PlaylistsValidator;
