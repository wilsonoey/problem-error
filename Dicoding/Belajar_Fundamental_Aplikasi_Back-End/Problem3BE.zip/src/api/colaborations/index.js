const ColaborationsHandler = require('./handler');
const routes = require('./routes');

module.exports = {
  name: 'colaborations',
  version: '1.0.0',
  register: async (server, { service, validator }) => {
    const colaborationsHandler = new ColaborationsHandler(service, validator);
    server.route(routes(colaborationsHandler));
  },
};
