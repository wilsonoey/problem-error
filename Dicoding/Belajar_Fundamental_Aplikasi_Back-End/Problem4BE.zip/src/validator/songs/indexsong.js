const InvariantError = require('../../exceptions/InvariantError');
const { schemesong } = require('./schemesong');

const SongValidator = {
  validateSongPayload: (payload) => {
    const validationResult = schemesong.validate(payload);
    if (validationResult.error) {
      throw new InvariantError(validationResult.error.message);
    }
  },
};

module.exports = SongValidator;
