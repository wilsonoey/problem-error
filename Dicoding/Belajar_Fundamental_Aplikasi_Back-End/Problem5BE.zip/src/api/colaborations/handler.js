class ColaborationsHandler {
  constructor(service, validator) {
    this._service = service;
    this._validator = validator;
  }

  postCollaborationHandler = async (request, h) => {
    this._validator.validateIndexColaborationPayload(request.payload.playlistId);
    const { playlistId } = request.params;
    const { id: credentialId } = request.auth.credentials;
    await this._service.verifyPlaylistOwner(playlistId, credentialId);
    const colaborationId = await this._service.addColaboration(request.payload, credentialId);
    const response = h.response({
      status: 'success',
      message: 'Kolaborasi berhasil ditambahkan',
      data: {
        colaborationId,
      },
    });
    response.code(201);
    return response;
  };

  deleteCollaborationHandler = async (request, h) => {
    this._validator.validateIndexColaborationPayload(request.payload);
    const { playlistId } = request.params;
    const { id: credentialId } = request.auth.credentials;
    await this._service.verifyPlaylistOwner(playlistId, credentialId);
    await this._service.deleteColaboration(request.payload, credentialId);
    const response = h.response({
      status: 'success',
      message: 'Kolaborasi berhasil dihapus',
    });
    response.code(200);
    return response;
  };
}

module.exports = ColaborationsHandler;
