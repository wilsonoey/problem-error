class PlaylistsHandler {
  constructor(service, validator) {
    this._service = service;
    this._validator = validator;
  }

  postPlaylistHandler = async (request, h) => {
    // input based from validation
    this._validator.validatePostPlaylistPayload(request.payload);
    const { id: credentialId } = request.auth.credentials;
    const playlistId = await this._service.addPlaylist(request.payload.name, credentialId);
    const response = h.response({
      status: 'success',
      message: 'Playlist berhasil ditambahkan',
      data: {
        playlistId,
      },
    });
    response.code(201);
    return response;
  };

  postSongToPlaylistHandler = async (request, h) => {
    this._validator.validatePostSongToPlaylistPayload(request.payload);
    const { songId } = request.payload;
    const { id: credentialId } = request.auth.credentials;
    await this._service.verifyPlaylistOwner(request.params.id, credentialId);
    await this._service.addSongToPlaylist(request.params.id, songId);
    const response = h.response({
      status: 'success',
      message: 'Lagu berhasil ditambahkan ke playlist',
    });
    response.code(201);
    return response;
  };

  getPlaylistsHandler = async (request, h) => {
    const { id: credentialId } = request.auth.credentials;
    const playlists = await this._service.getPlaylists(credentialId);
    const response = h.response({
      status: 'success',
      data: {
        playlists,
      },
    });
    response.code(200);
    return response;
  };

  getPlaylistWithSongsByIdHandler = async (request, h) => {
    const { id } = request.params;
    const { id: credentialId } = request.auth.credentials;
    await this._service.verifyPlaylistOwner(id, credentialId);
    const playlist = await this._service.getPlaylistWithSongsById(id);
    const response = h.response({
      status: 'success',
      data: {
        playlist,
      },
    });
    response.code(200);
    return response;
  };

  deleteSongFromPlaylistHandler = async (request, h) => {
    this._validator.validateDeleteSongFromPlaylistPayload(request.payload);
    const { id: credentialId } = request.auth.credentials;
    await this._service.verifyPlaylistOwner(request.params.id, credentialId);
    await this._service.deleteSongFromPlaylistHandler(request.params.id, request.payload.songId);
    const response = h.response({
      status: 'success',
      message: 'Lagu berhasil dihapus dari playlist',
    });
    response.code(200);
    return response;
  };

  deletePlaylistByIdHandler = async (request, h) => {
    const { id } = request.params;
    const { id: credentialId } = request.auth.credentials;
    await this._service.verifyPlaylistOwner(id, credentialId);
    await this._service.deletePlaylistById(id);
    const response = h.response({
      status: 'success',
      message: 'Playlist berhasil dihapus',
    });
    response.code(200);
    return response;
  };
}

module.exports = PlaylistsHandler;
