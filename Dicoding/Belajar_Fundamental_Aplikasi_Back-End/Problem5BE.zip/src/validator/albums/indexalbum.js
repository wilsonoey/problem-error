const InvariantError = require('../../exceptions/InvariantError');
const SchemeAlbum = require('./schemealbum');

const AlbumsValidator = {
  validateAlbumPayload: (payload) => {
    const validationResult = SchemeAlbum.validate(payload);
    if (validationResult.error) {
      throw new InvariantError(validationResult.error.message);
    }
  },
};

module.exports = AlbumsValidator;
