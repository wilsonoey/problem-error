const InvariantError = require('../../exceptions/InvariantError');
const { postschemeauth, tokenschemeauth } = require('./schemeauth');

const IndexAuthenticationValidator = {
  validatePostAuthenticationsPayload: (payload) => {
    const validationResult = postschemeauth.validate(payload);
    if (validationResult.error) {
      throw new InvariantError(validationResult.error.message);
    }
  },
  validateTokenAuthenticationsPayload: (payload) => {
    const validationResult = tokenschemeauth.validate(payload);
    if (validationResult.error) {
      throw new InvariantError(validationResult.error.message);
    }
  },
};

module.exports = IndexAuthenticationValidator;
