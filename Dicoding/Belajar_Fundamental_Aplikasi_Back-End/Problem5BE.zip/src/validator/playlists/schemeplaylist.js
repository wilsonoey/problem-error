const Joi = require('joi');

const postplaylistschema = Joi.object({
  name: Joi.string().required(),
});

const songtoplaylistpayloadschema = Joi.object({
  songId: Joi.string().required(),
});

module.exports = { postplaylistschema, songtoplaylistpayloadschema };
