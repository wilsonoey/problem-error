const Hapi = require('@hapi/hapi');
const routes = require('./routes');
const Jwt = require('@hapi/jwt');
const variable = require('./variable');

const init = async () => {
  const server = Hapi.server({
    port: 5000,
    host: 'localhost',
    routes: {
      cors: {
        origin: ['*'],
      },
    },
  });
  server.route(routes);
  await server.register([
    {
      plugin: Jwt,
    },
  ]);
  server.auth.strategy('kamiada_jwt', 'jwt', {
    keys: variable.ACCESS_TOKEN_KEY,
    verify: {
      aud: false,
      iss: false,
      sub: false,
      maxAgeSec: variable.ACCESS_TOKEN_AGE,
    },
    validate: (artifacts) => ({
      isValid: true,
      credentials: {
        iduser: artifacts.decoded.payload.iduser,
        emailuser: artifacts.decoded.payload.emailuser,
        passworduser: artifacts.decoded.payload.passworduser,        
      },
    }),
  });
  await server.start();
  console.log(`Server running at ${server.info.uri}`);
};
     
init();