const { customAlphabet, nanoid } = require('nanoid');
const {
  clienterror,
  notfound,
  servererror,
  successwithdata,
  success,
  successcreated,
  successcreatedwithdata,
  authenticationerror,
  authorizationerror,
  successwithdataANDcount,
} = require('./response');
const bcrypt = require('bcryptjs');
const connection = require('./connection');
const TokenManager = require('./tokenmanager');
const partAuth = require('./authuser');

async function loginUser(request, h) {
  try {
    const { emailuser, passworduser } = request.payload;
    const query = 'SELECT * FROM userskad WHERE emailuser = ?';
    return new Promise((resolve, reject) => {
      connection.query(query, emailuser, async function(error, results) {
        if (error) reject(error);
        if (results.length > 0) {
          const user = results[0];
          const isValid = await bcrypt.compare(passworduser, user.passworduser);
          if (isValid) {
            const accessToken = TokenManager.generateAccessToken({
              iduser: user.iduser,
              emailuser: user.emailuser,
              passworduser: user.passworduser,
            });
            const refreshToken = TokenManager.generateRefreshToken({
              iduser: user.iduser,
              emailuser: user.emailuser,
              passworduser: user.passworduser,
            });
            await partAuth.addToken(refreshToken);
            resolve(h.response(
              successcreatedwithdata('Login berhasil', {accessToken, refreshToken})
            ).code(201));
          } else resolve(h.response(authenticationerror('Password Salah')).code(401));
        } else {
          resolve(h.response(
            clienterror('Email tidak ditemukan. Silakan registrasi terlebih dahulu.')
          ).code(400));
        }
      });
    });
  } catch (error) {
    console.log(error);
    throw error;
  }
}

async function registerUser(request, h) {
  try {
    const addOtherPayload = { ...request.payload };
    const id = customAlphabet('1234567890', 15);
    const hashPassword = await bcrypt.hash(addOtherPayload.passworduser, 10);
    const createdat = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
    const data = {
      iduser: id(),
      ...request.payload,
      passworduser: hashPassword,
      createdatuser: createdat,
      updatedatuser: createdat,
    };
    const querychecker = 'SELECT * FROM userskad WHERE phoneuser = ? OR emailuser = ? OR username = ?';
    return new Promise((resolve, reject) => {
      connection.query(querychecker, [
        addOtherPayload.phoneuser, addOtherPayload.emailuser, addOtherPayload.username,
      ], async function(errorchecker, resultschecker) {
        const userchecker = resultschecker[0];
        if (errorchecker) { reject(errorchecker) } else {
          if (resultschecker.length > 0) {
            if (userchecker.phoneuser == addOtherPayload.phoneuser) {
              resolve(h.response(
                clienterror('Nomor ponsel sudah ada. Silakan hubungi admin untuk bantuan.')
              ).code(400));
            } else if (userchecker.emailuser == addOtherPayload.emailuser) {
              resolve(h.response(
                clienterror('Email sudah ada. Silakan hubungi admin untuk bantuan.')
              ).code(400));
            } else if (userchecker.username == addOtherPayload.username) {
              resolve(h.response(
                clienterror('Username sudah ada. Gunakan username yang lain.')
              ).code(400));
            } 
          } else if (resultschecker.length === 0) {
            const query = 'INSERT INTO userskad SET ?';
            connection.query(query, data, () => {
              resolve(h.response(
                successcreated(`User berhasil ditambahkan dengan iduser ${data.iduser}`)
              ).code(201));
            });
          }
        }
      });
    });
  } catch (error) {
    console.log(error);
    throw error;
  }
}

async function getAllUsers(_, h) {
  try {
    const query = 'SELECT * FROM userskad';
    return new Promise((resolve, reject) => {
      connection.query(query, (error, results) => error ? reject(error) : resolve(h.response(
        successwithdataANDcount(results.length, 'User berhasil ditampilkan', results)
      ).code(200)));
    });
  } catch (error) {
    // const { message } = error;
    // return h.response(servererror(message)).code(500);
    const { stack } = error;
    return h.response(servererror(stack)).code(500);
  }
}

async function getUserById(request, h) {
  try {
    const { iduser } = request.params;
    const query = 'SELECT * FROM userskad WHERE iduser = ?';
    return new Promise((resolve, reject) => {
      connection.query(query, iduser, (error, results) => error ? reject(error) : (
        results.length === 0 ? resolve(
          h.response(notfound('User tidak ditemukan')).code(404)
        ) : resolve(h.response(
          successwithdata('User berhasil ditampilkan', results[0])
        ).code(200))
      ));
    });
  } catch (error) {
    console.log(error);
    throw error;
  }
}

async function editUser(request, h) {
  try {
    const verify = request.auth.credentials;
    const { iduser } = request.params;
    const addOtherPayload = { ...request.payload };
    const hashPassword = await bcrypt.hash(addOtherPayload.passworduser, 10);
    const updatedat = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
    const data = {
      ...request.payload,
      passworduser: hashPassword,
      updatedatuser: updatedat,
    };
    const querychecker = 'SELECT * FROM userskad WHERE iduser = ?';
    return new Promise((resolve, reject) => {
      connection.query(querychecker, iduser, async function(errorchecker, resultschecker) {
        if (errorchecker) reject(errorchecker);
        const userchecker = resultschecker[0];
        if (resultschecker.length === 0) {
          resolve(h.response(notfound('User tidak ditemukan')).code(404));
        } else if (userchecker.phoneuser == addOtherPayload.phoneuser) {
          resolve(h.response(
            clienterror('Nomor ponsel sudah ada. Silakan hubungi admin untuk bantuan.')
          ).code(400));
        } else if (userchecker.emailuser == addOtherPayload.emailuser) {
          resolve(h.response(
            clienterror('Email sudah ada. Silakan hubungi admin untuk bantuan.')
          ).code(400));
        } else if (userchecker.username == addOtherPayload.username) {
          resolve(h.response(
            clienterror('Username sudah ada. Gunakan username yang lain.')
          ).code(400));
        } else if (userchecker.iduser !== verify.iduser) {
          resolve(h.response(authorizationerror('User tidak berhak untuk mengedit user lain')));
        } else if (userchecker.phoneuser !== addOtherPayload.phoneuser
                    && userchecker.emailuser !== addOtherPayload.emailuser
                    && userchecker.username !== addOtherPayload.username
                    && userchecker.iduser == verify.iduser) {
          let updateQuery = 'UPDATE userskad SET';
          const values = [];
          let i = 0;
          for (const [key, value] of Object.entries(data)) {
            if (value !== null && value !== undefined) {
              if (i > 0) {
                updateQuery += ',';
              }
              updateQuery += ` \`${key}\` = ?`;
              values.push(value);
              i++;
            }
          }
          updateQuery += ' WHERE iduser = ?';
          values.push(iduser);
          if (userchecker.passworduser !== verify.passworduser) {
            connection.query(updateQuery, values, async (error, results) => {
              if (error) { reject(error) } else {
                const accessToken = TokenManager.generateAccessToken({
                  iduser: userchecker.iduser,
                  emailuser: addOtherPayload.emailuser,
                  passworduser: addOtherPayload.passworduser,
                });
                const refreshToken = TokenManager.generateRefreshToken({
                  iduser: userchecker.iduser,
                  emailuser: addOtherPayload.emailuser,
                  passworduser: addOtherPayload.passworduser,
                });
                await partAuth.addToken(refreshToken);
                resolve(h.response(
                  successcreatedwithdata('User dan token berhasil diupdate', {accessToken, refreshToken})
                ).code(200));
              }
            });
          } else if (userchecker.passworduser === verify.passworduser) {
            connection.query(updateQuery, values, (error) => error ? reject(error) : (
              resolve(h.response(success('User berhasil diupdate')).code(200))
            ));
          }
        }
      });
    });
  } catch (error) {
    console.log(error);
    throw error;
  }
}

async function deleteUser(request, h) {
  try {
    const verify = request.auth.credentials;
    const deletetoken = request.headers.authorization.replace('Bearer ', '');
    const { iduser } = request.params;
    const query = 'DELETE FROM userskad WHERE iduser = ?';
    return new Promise((resolve, reject) => {
      if (verify.iduser !== iduser) {
        resolve(h.response(
          authorizationerror('User tidak memiliki akses untuk menghapus user lain')
        ).code(403));
      } else if (verify.iduser === iduser) {
        connection.query(query, iduser, async (error, results) => (error ? reject(error) : (
          await partAuth.deleteToken(deletetoken),
          results.affectedRows === 0 ? resolve(h.response(
            notfound('User tidak ditemukan')
          ).code(404)) : resolve(h.response(success('User berhasil dihapus')).code(200))
        )));
      }
    });
  } catch (error) {
    console.log(error);
    throw error;
  }
}

async function addservicebyuser(request, h) {
  try {
    const verify = request.auth.credentials;
    const { iduser } = request.params;
    const selectediduserchecker = 'SELECT * FROM userskad WHERE iduser = ?';
    return new Promise((resolve, reject) => {
      connection.query(selectediduserchecker, iduser, async function(errorchecker, resultschecker) {
        if (errorchecker) reject(errorchecker);
        const user = resultschecker[0];
        const idservice = nanoid(50);
        const createdat = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
        const data = {
          idservice: idservice,
          iduser: iduser,
          avataruser: user.avataruser,
          username: user.username,
          ...request.payload,
          createdatservice: createdat,
          updatedatservice: createdat,
        };
        const query = 'INSERT INTO serviceskad SET ?';
        if (verify.iduser !== iduser) {
          resolve(h.response(
            authorizationerror('User tidak memiliki akses untuk menambahkan layanan jasa')
          ).code(403));
        } else if (verify.iduser == iduser) {
          connection.query(query, data, (error, results) => error ? reject(error) : (
            resolve(h.response(successcreated('Service berhasil ditambahkan')).code(201))
          ));
        }
      });
    });
  } catch (error) {
    console.log(error);
    throw error;
  }
}

async function getallservice(_, h) {
  try {
    const query = 'SELECT * FROM serviceskad';
    return new Promise((resolve, reject) => {
      connection.query(query, (error, results) => (error ? reject(error) : resolve(h.response(
        successwithdataANDcount(results.length, 'Service berhasil ditampilkan', results)
      ).code(200))));
    });
  } catch (error) {
    console.log(error);
    throw error;
  }
}

async function getallservicebyiduser(request, h) {
  try {
    const { iduser } = request.params;
    const query = 'SELECT * FROM serviceskad WHERE iduser = ?';
    return new Promise((resolve, reject) => {
      connection.query(query, iduser, (error, results) => error ? reject(error) : (
        results.length === 0 ? resolve(h.response(
          notfound('User dan / atau layanan jasa tidak ditemukan')
        ).code(404)) : resolve(h.response(
          successwithdata('Service berhasil ditampilkan', results)
        ).code(200))
      ));
    });
  } catch (error) {
    console.log(error);
    throw error;
  }
}

async function getservicebyiduserthenidservice(request, h) {
  try {
    const { iduser, idservice } = request.params;
    const querychecker = 'SELECT * FROM userskad WHERE iduser = ?';
    return new Promise((resolve, reject) => {
      connection.query(querychecker, iduser, async function(errorchecker, resultschecker) {
        if (errorchecker) reject(errorchecker);
        if (resultschecker.length > 0) {
          const query = 'SELECT * FROM serviceskad WHERE idservice = ?';
          connection.query(query, idservice, (error, results) => error ? reject(error) : (
            (results.length > 0) ? (
              resolve(h.response(
                successwithdata('Service berhasil ditampilkan', results[0])
              ).code(200))
            ) : (
              resolve(h.response(notfound('Layanan jasa tidak ditemukan')).code(404))
            )
          ));
        } else resolve(h.response(notfound('User tidak ditemukan')).code(404));
      });
    });
  } catch (error) {
    console.log(error);
    throw error;
  }
}

async function getservicebyidservice(request, h) {
  try {
    const { idservice } = request.params;
    const query = 'SELECT * FROM serviceskad WHERE idservice = ?';
    return new Promise((resolve, reject) => {
      connection.query(query, idservice, (error, results) => (error ? reject(error) : (
        results.length === 0 ? resolve(h.response(
          notfound('Layanan jasa tidak ditemukan')
        ).code(404)) : resolve(h.response(
          successwithdata('Service berhasil ditampilkan', results[0])
        ).code(200))
      )));
    });
  } catch (error) {
    console.log(error);
    throw error;
  }
}

async function getservicebycategory(request, h) {
  try {
    const { categoryservice } = request.params;
    const query = 'SELECT * FROM serviceskad WHERE categoryservice = ?';
    return new Promise((resolve, reject) => {
      connection.query(query, categoryservice, (error, results) => error ? reject(error) : (
        results.length === 0 ? resolve(h.response(
          notfound('Layanan jasa tidak ditemukan')
        ).code(404)) : resolve(h.response(
          successwithdata('Service berhasil ditampilkan', results)
        ).code(200))
      ));
    });
  } catch (error) {
    console.log(error);
    throw error;
  }
}

async function updateservice(request, h) {
  try {
    const verify = request.auth.credentials;
    const { iduser, idservice } = request.params;
    const updatedat = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
    const data = { ...request.payload, updatedatservice: updatedat };
    const querychecker = 'SELECT * FROM userskad WHERE iduser = ?';
    return new Promise((resolve, reject) => {
      connection.query(querychecker, iduser, async function(errorchecker, resultschecker) {
        const servicechecker = resultschecker[0];
        if (errorchecker) { reject(errorchecker) } else if (servicechecker.iduser !== iduser) {
          resolve(h.response(
            authorizationerror('User tidak memiliki akses untuk mengedit layanan jasa')
          ).code(403));
        } else if (resultschecker.length > 0 && servicechecker.iduser == iduser) {
          let updateQuery = 'UPDATE serviceskad SET';
          const values = [];
          let i = 0;
          for (const [key, value] of Object.entries(data)) {
            if (value !== null && value !== undefined) {
              if (i > 0) {
                updateQuery += ',';
              }
              updateQuery += ` \`${key}\` = ?`;
              values.push(value);
              i++;
            }
          }
          updateQuery += ' WHERE idservice = ?';
          values.push(idservice);
          connection.query(updateQuery, values, (error, results) => {
            error ? reject(error) : (
              (results.affectedRows > 0) ? (
                resolve(h.response(
                  success('Service berhasil diupdate')
                ).code(200))
              ) : (
                resolve(h.response(
                  clienterror('Service gagal diupdate')
                ).code(400))
              )
            );
          });
        } else {
          resolve(h.response(notfound('User tidak ditemukan')).code(404));
        }
      });
    });
  } catch (error) {
    console.log(error);
    throw error;
  }
}

async function deleteservice(request, h) {
  try {
    const verify = request.auth.credentials;
    const { iduser, idservice } = request.params;
    const querychecker = 'SELECT * FROM userskad WHERE iduser = ?';
    return new Promise((resolve, reject) => {
      connection.query(querychecker, iduser, (errorchecker, resultschecker) => {
        if (errorchecker) { reject(errorchecker) } else if (servicechecker.iduser !== iduser) {
          resolve(h.response(
            authorizationerror('User tidak memiliki akses untuk mengedit layanan jasa')
          ).code(403));
        } else if (resultschecker.length > 0 && servicechecker.iduser == iduser) {
          const query = 'DELETE FROM serviceskad WHERE idservice = ?';
          connection.query(query, idservice, (error, results) => error ? reject(error) : (
            (results.affectedRows > 0) ? (
              resolve(h.response(
                success('Service berhasil dihapus')
              ).code(200))
            ) : (
              resolve(h.response(
                notfound('Layanan jasa tidak ditemukan')
              ).code(404))
            )
          ));
        } else {
          resolve(h.response(notfound('User tidak ditemukan')).code(404));
        }
      });
    });
  } catch (error) {
    console.log(error);
    throw error;
  }
}

const part = {
  loginkad: loginUser,
  registerkad: registerUser,
  alluserskad: getAllUsers,
  userbyidkad: getUserById,
  edituserkad: editUser,
  deleteuserkad: deleteUser,
  addservicebyuserkad: addservicebyuser,
  allservicekad: getallservice,
  allservicebyiduserkad: getallservicebyiduser,
  servicebyiduserthenidservicekad: getservicebyiduserthenidservice,
  servicebyidservicekad: getservicebyidservice,
  servicebycategorykad: getservicebycategory,
  updateservicekad: updateservice,
  deleteservicekad: deleteservice,
};

module.exports = part;
