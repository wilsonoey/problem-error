const part = require('./handler');

const routes = [
  {
    method: 'POST',
    path: '/user/login',
    handler: part.loginkad,
  },
  {
    method: 'POST',
    path: '/user/register',
    handler: part.registerkad,
  },
  {
    method: 'GET',
    path: '/user',
    handler: part.alluserskad,
  },
  {
    method: 'GET',
    path: '/user/{iduser}',
    handler: part.userbyidkad,
  },
  {
    method: 'PUT',
    path: '/user/{iduser}',
    handler: part.edituserkad,
    options: {
      auth: 'kamiada_jwt',
    }
  },
  {
    method: 'DELETE',
    path: '/user/{iduser}',
    handler: part.deleteuserkad,
    options: {
      auth: 'kamiada_jwt',
    }
  },
  {
    method: 'POST',
    path: '/user/{iduser}/service/add',
    handler: part.addservicebyuserkad,
    options: {
      auth: 'kamiada_jwt',
    }
  },
  {
    method: 'GET',
    path: '/service',
    handler: part.allservicekad,
  },
  {
    method: 'GET',
    path: '/user/{iduser}/service',
    handler: part.allservicebyiduserkad,
  },
  {
    method: 'GET',
    path: '/user/{iduser}/service/{idservice}',
    handler: part.servicebyiduserthenidservicekad,
  },
  {
    method: 'GET',
    path: '/service/{idservice}',
    handler: part.servicebyidservicekad,
  },
  {
    method: 'GET',
    path: '/service/category/{categoryservice}',
    handler: part.servicebycategorykad,
  },
  {
    method: 'PUT',
    path: '/user/{iduser}/service/{idservice}',
    handler: part.updateservicekad,
    options: {
      auth: 'kamiada_jwt',
    }
  },
  {
    method: 'DELETE',
    path: '/user/{iduser}/service/{idservice}',
    handler: part.deleteservicekad,
    options: {
      auth: 'kamiada_jwt',
    }
  },
];

module.exports = routes;
