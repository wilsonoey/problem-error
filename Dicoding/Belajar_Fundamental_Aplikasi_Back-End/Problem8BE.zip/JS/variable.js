const variable = {
  HOSTDB: 'localhost',
  USERDB: 'root',
  PASSDB: '',
  NAMEDB: 'wilsonoey_kamiada',
  ACCESSJWT: 'c8c8d45684cc80a7100961087b65360bd9de65d9b233860e43eab82345d4b97794f70df61b93353116747a0084df55085da792e3c91b9e75b024c44ce670bb7b',
  REFRESHJWT: '3890a847ef129a8fb05ca88f1c0ab0ad3736b03a43f56c8ed04db147ebbb7ebeba38bff128a55bb1e40f953f07b442cf3fa0094ea218c4fbbc147847cc257c7b',
  ACCESS_TOKEN_AGE: 86400,
}

module.exports = variable;