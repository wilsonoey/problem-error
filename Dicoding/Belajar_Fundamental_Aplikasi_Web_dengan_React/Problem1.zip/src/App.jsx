import React from 'react';

import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import AddItemPage from './pages/AddItemPage';
import DetailPage from './pages/DetailPage';
import ArchivePage from './pages/ArchivePage';

function App() {
  
  return (
    <div className="app-container">
      <header>
        <h1><a href="/">Aplikasi Catatan</a></h1>
        <nav class="navigation">
          <ul>
            <li>
              <a href="/archives">Arsip</a>
            </li>
          </ul>
        </nav>
      </header>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="notes/new" element={<AddItemPage />} />
        <Route path="notes/:id" element={<DetailPage />} />
        <Route path="archives" element={<ArchivePage />} />
      </Routes>
    </div>
  );
}

export default App;