// import { useState } from "react";

// export function useLocale() {
//   const [locale, setLocale] = useState("en");

//   const toggleLocale = () => {
//     locale === "en" ? setLocale("id") : setLocale("en");
//   };

//   return [locale, toggleLocale];
// }