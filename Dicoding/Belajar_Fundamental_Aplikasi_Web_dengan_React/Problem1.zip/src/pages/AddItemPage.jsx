import React from 'react';
import AddInput from '../component/input/AddInput';
import { addNote } from '../utils/local-data';
import { useNavigate } from 'react-router-dom';

const AddItemPage = () => {
  const navigate = useNavigate();

  function onAddNoteHandler(Note) {
    addNote(Note);
    navigate('/');
  }

  return (
    <AddInput addNote={onAddNoteHandler}/>
  );
};

export default AddItemPage;