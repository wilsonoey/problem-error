import React from 'react';
import List from '../component/item/List';
import PropTypes from 'prop-types';

function ArchivePage ({ notes }) {
  return (
    <div className="archive-page">
      <h1>Arsip</h1>
      {notes.length > 0 ? 
        <List notes={notes}/>
        :
        <h2>Tidak ada catatan</h2>
      }
    </div>
  );
};

ArchivePage.propTypes = {
  notes: PropTypes.array.isRequired
};

export default ArchivePage;