import React from 'react';
import PropTypes from 'prop-types';
import DetailItem from '../component/item/DetailItem';
import { getNote } from '../utils/local-data';
import { useParams } from 'react-router-dom';

class DetailPage extends React.Component {
  constructor(props) {
    super(props);
    const { id } = useParams();
    this.state = {
      note: getNote(id),
    }
    return <DetailItem id={id}/>
  }

  render() {
    if(typeof this.state.note === 'undefined'){
      return( <p>Note is not found !</p> );
  }
    return (
      <DetailItem {...this.state.note} />
    );
  }
  
}

DetailPage.propType = {
  note: PropTypes.object.isRequired,
  ArchiveClick: PropTypes.func.isRequired,
  DeleteClick: PropTypes.func.isRequired
}

export default DetailPage;


