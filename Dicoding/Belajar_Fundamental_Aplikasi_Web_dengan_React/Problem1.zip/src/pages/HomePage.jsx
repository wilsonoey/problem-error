import React from 'react';
import PropTypes from 'prop-types';
import List from '../component/item/List';
import SearchInput from '../component/input/SearchInput';
import RouteToAddButton from '../component/button/RouteToAddButton';
import { getAllNotes } from '../utils/local-data';

class HomePage extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      notes: getAllNotes(),
      keyword: ''
    }
  }

  keywordChange = (keyword) => {
    this.setState({ keyword });
  }

  render() {
    return (
      <main>
        <h2>Catatan Aktif</h2>
        <div className="search-bar">
          <SearchInput keyword={this.state.keyword} keywordChange={this.keywordChange} />
        </div>
        <List notes={this.state.notes} />
        <div className="homepage__action">
          <RouteToAddButton />
        </div>
      </main>
    );
  }
  
}

HomePage.propType = {
  notes: PropTypes.array.isRequired,
  keyword: PropTypes.string.isRequired,
  keywordChange: PropTypes.func.isRequired
}

export default HomePage;