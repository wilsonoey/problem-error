import React from 'react';
import PropTypes from 'prop-types';
import ArchivedButton from './DetailGroup/ArchivedButton';
import DeleteButton from './DetailGroup/DeleteButton';

function DetailGroup({
  id, onDelete, archived, onArchived, onUnarchived,
}) {
  return (
    <div className="detail-page__action">
      <ArchivedButton
        id={id}
        archived={archived}
        onArchive={onArchived}
        onUnarchive={onUnarchived}
      />
      <DeleteButton id={id} onDelete={onDelete} />
    </div>
  );
}

DetailGroup.propTypes = {
  id: PropTypes.string.isRequired,
  archived: PropTypes.bool.isRequired,
  onArchived: PropTypes.func.isRequired,
  onUnarchived: PropTypes.func.isRequired,
  onDelete: PropTypes.func.isRequired,
};

export default DetailGroup;
