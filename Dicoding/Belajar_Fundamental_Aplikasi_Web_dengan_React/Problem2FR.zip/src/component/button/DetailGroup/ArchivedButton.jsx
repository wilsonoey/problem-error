import React from 'react';
import PropTypes from 'prop-types';
import { FiArchive } from 'react-icons/fi';
import { FaArchive } from 'react-icons/fa';

function ArchivedButton({
  id, archived, onArchive, onUnarchive,
}) {
  switch (archived) {
    case true:
      return (
        <button className="action" type="button" title="Unarchive" onClick={() => onUnarchive(id)}>
          <FiArchive />
        </button>
      );
    case false:
      return (
        <button className="action" type="button" title="Archive" onClick={() => onArchive(id)}>
          <FaArchive />
        </button>
      );
    default:
      return (
        <button className="action" type="button" title="Archive" onClick={() => onArchive(id)}>
          <FaArchive />
        </button>
      );
  }
}

ArchivedButton.propTypes = {
  id: PropTypes.string.isRequired,
  onArchive: PropTypes.func.isRequired,
  onUnarchive: PropTypes.func.isRequired,
  archived: PropTypes.bool.isRequired,
};

export default ArchivedButton;
