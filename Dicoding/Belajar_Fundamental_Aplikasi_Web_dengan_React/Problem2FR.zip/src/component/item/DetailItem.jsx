import React from 'react';
import PropTypes from 'prop-types';
import DetailAction from '../button/DetailGroup';
import { showFormattedDate } from '../../utils';

function DetailItem({
  id, title, body, createdAt, Archive, ArchiveClick, UnarchiveClick, DeleteClick,
}) {
  return (
    <main>
      <div className="detail-page">
        <h3 className="detail-page__title">{title}</h3>
        <p className="detail-page__createdAt">{showFormattedDate(createdAt)}</p>
        <p className="detail-page__body">{body}</p>
        <DetailAction
          id={id}
          archived={Archive}
          onArchived={ArchiveClick}
          onDelete={DeleteClick}
          onUnarchived={UnarchiveClick}
        />
      </div>
    </main>
  );
}

DetailItem.propType = {
  id: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  body: PropTypes.string.isRequired,
  createdAt: PropTypes.string.isRequired,
  Archive: PropTypes.bool.isRequired,
  UnarchiveClick: PropTypes.func.isRequired,
  ArchiveClick: PropTypes.func.isRequired,
  DeleteClick: PropTypes.func.isRequired,
};

export default DetailItem;
