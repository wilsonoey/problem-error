import React from 'react';
import { useSearchParams } from 'react-router-dom';
import { getArchivedNotes } from '../utils/network-data';
import { LocaleConsumer } from '../contexts/LocaleContext';
import List from '../component/item/List';
import SearchInput from '../component/input/SearchInput';

function ArchivePageWrapper() {
  const [searchParams, setSearchParams] = useSearchParams();
  const keyword = searchParams.get('keyword');
  function changeSearchParams(keywords) {
    setSearchParams({ keywords });
  }
  return <ArchivePage defaultKeyword={keyword} keywordChange={changeSearchParams} />;
}

class ArchivePage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      notes: [],
      keyword: '',
    };
  }

  async componentDidMount() {
    const { data } = await getArchivedNotes();
    this.setState(() => ({
      notes: data,
    }));
  }

  onSearch = (title) => {
    this.setState(() => ({
      keyword: title,
    }));
  };

  render() {
    const notes = this.state.notes.filter(
      (note) => note.title.toLowerCase().includes(this.state.keyword.toLowerCase()),
    );
    const archivedNote = notes.filter((note) => note.archived === true);
    return (
      <LocaleConsumer>
        {
          ({ locale }) => (
            <main>
              <h2>{locale === 'id' ? 'Catatan Arsip' : 'Archived Notes'}</h2>
              <div className="search-bar">
                <SearchInput keyword={this.props.keyword} keywordChange={this.onSearch} />
              </div>
              {
                archivedNote.length > 0
                  ? <List notes={archivedNote} />
                  : (
                    <section className="notes-list-empty">
                      <p>{locale === 'id' ? 'Tidak ada catatan arsip' : 'Archive note is empty'}</p>
                    </section>
                  )
              }
            </main>
          )
        }
      </LocaleConsumer>
    );
  }
}

export default ArchivePageWrapper;
