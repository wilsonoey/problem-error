import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import LoginInput from '../component/input/LoginInput';
import { login } from '../utils/network-data';
import { LocaleConsumer } from '../contexts/LocaleContext';

function LoginPage({ loginSuccess }) {
  async function onLogin({ emailuser, passworduser }) {
    const { error, data } = await login({ emailuser, passworduser });
    if (!error) {
      loginSuccess(data);
    } else {
      alert('Email or password is wrong. Please try again');
    }
  }

  return (
    <LocaleConsumer>
      {
        ({ locale }) => (
          <section className="login-page">
            <h2>{locale === 'id' ? 'Yuk, login untuk menggunakan aplikasi.' : 'Login to use app, please.'}</h2>
            <LoginInput login={onLogin} />
            <p>
              {locale === 'id' ? 'Belum punya akun? ' : 'Don\'t have an account? '}
              <Link to="/register">{locale === 'id' ? 'Daftar di sini' : 'Register here'}</Link>
            </p>
          </section>
        )
      }
    </LocaleConsumer>
  );
}

LoginPage.propTypes = {
  loginSuccess: PropTypes.func.isRequired,
};

export default LoginPage;
