package id.dicoding.submission_android_jetpack_compose.model

object ListsData {
    val lists = listOf(
        List(
            "1",
            "Abdul Muis",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/1.jpg"
        ),
        List(
            "2",
            "Ki Hajar Dewantara",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/2.jpg"
        ),
        List(
            "3",
            "R.M. Surjopranoto",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/3.jpg"
        ),
        List(
            "4",
            "Mohammad Hoesni Thamrin",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/4.jpg"
        ),
        List(
            "5",
            "KH. Samanhudi",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/5.jpg"
        ),
        List(
            "6",
            "H.O.S. Cokroaminoto",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/6.jpg"
        ),
        List(
            "7",
            "Danudirja Setiabudi",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/7.jpg"
        ),
        List(
            "8",
            "Si Singamangaradja XII",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/8.jpg"
        ),
        List(
            "9",
            "Dr. G.S.S.J Ratulangie",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/9.jpg"
        ),
        List(
            "10",
            "DR. Sutomo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/10.jpg"
        ),
        List(
            "11",
            "KH. Akhmad Dahlan",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/11.jpg"
        ),
        List(
            "12",
            "KH. Agus Salim",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/12.jpg"
        ),
        List(
            "13",
            "Jend. Gatot Subroto",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/13.jpg"
        ),
        List(
            "14",
            "Sukarjo Wiryopranoto",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/14.jpg"
        ),
        List(
            "15",
            "Dr. Ferdinand Lumban Tobing",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/15.jpg"
        ),
        List(
            "16",
            "KH. Zainul Arifin",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/16.jpg"
        ),
        List(
            "17",
            "Tan Malaka",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/17.jpg"
        ),
        List(
            "18",
            "MGR.A. Sugyopranoto SJ",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/18.jpg"
        ),
        List(
            "19",
            "Ir. H. Djuanda Kartawijaya",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/19.jpg"
        ),
        List(
            "20",
            "DR. Sahardjo, SH",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/20.jpg"
        ),
        List(
            "21",
            "Cut Nyak Dhien",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/21.jpg"
        ),
        List(
            "22",
            "Cut Meutia",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/22.jpg"
        ),
        List(
            "23",
            "R.A. Kartini",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/23.jpg"
        ),
        List(
            "24",
            "Dr. Ciptomangunkusumo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/24.jpg"
        ),
        List(
            "25",
            "H. Fakhrudin",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/25.jpg"
        ),
        List(
            "26",
            "KH. Mas Mansyur",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/26.jpg"
        ),
        List(
            "27",
            "Alimin",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/27.jpg"
        ),
        List(
            "28",
            "Dr. Muwardi",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/28.jpg"
        ),
        List(
            "29",
            "KH. Abdul Wahid Hasjim",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/29.jpg"
        ),
        List(
            "30",
            "Sri Susuhunan Pakubuwono VI",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/30.jpg"
        ),
        List(
            "31",
            "KH. Hasjim Asjarie",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/31.jpg"
        ),
        List(
            "32",
            "Gubernur Surjo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/32.jpg"
        ),
        List(
            "33",
            "Jenderal Soedirman",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/33.jpg"
        ),
        List(
            "34",
            "Jenderal Urip Sumohardjo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/34.jpg"
        ),
        List(
            "35",
            "Prof. DR. Supomo, SH",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/35.jpg"
        ),
        List(
            "36",
            "DR. Kusumaatmadja, SH",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/36.jpg"
        ),
        List(
            "37",
            "Jenderal TNI Anm. A. Yani",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/37.jpg"
        ),
        List(
            "38",
            "Letjen. TNI.R. Anm Suprapto",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/38.jpg"
        ),
        List(
            "39",
            "Letjen. TNI. Anm. MT. Harjono",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/39.jpg"
        ),
        List(
            "40",
            "Letjen. TNI. Anm. S. Parman",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/40.jpg"
        ),
        List(
            "41",
            "Mayjen. TNI. Anm. D.I. Panjaitan",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/41.jpg"
        ),
        List(
            "42",
            "Mayjen. TNI.Anm. S. Siswomihardjo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/42.jpg"
        ),
        List(
            "43",
            "Kapten CZI. Anm. Pierre Tendean",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/43.jpg"
        ),
        List(
            "44",
            "AIP. TK. II Brig.Pol. K.S. Tubun",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/44.jpg"
        ),
        List(
            "45",
            "Brigjen. TNI. Anm. Katamso",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/45.jpg"
        ),
        List(
            "46",
            "Kol. Inf. TNI. Anm. Sugiono",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/46.jpg"
        ),
        List(
            "47",
            "Sutan Sjahrir",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/47.jpg"
        ),
        List(
            "48",
            "Laks.Laut R.E. Martadinata",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/48.jpg"
        ),
        List(
            "49",
            "Raden Dewi Sartika",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/49.jpg"
        ),
        List(
            "50",
            "Prof. DR. W.Z. Johannes",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/50.jpg"
        ),
        List(
            "51",
            "Pangeran Antasari",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/51.jpg"
        ),
        List(
            "52",
            "Sersan II KKO. Anm. Janatin alias Osman",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/52.jpg"
        ),
        List(
            "53",
            "Kopral KKO. Anm. Harun",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/53.jpg"
        ),
        List(
            "54",
            "Jend. TNI. Basuki Rakhmat",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/54.jpg"
        ),
        List(
            "55",
            "Arie Frederik Lasut",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/55.jpg"
        ),
        List(
            "56",
            "Martha Christina Tijahahu",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/56.jpg"
        ),
        List(
            "57",
            "Maria Walanda Maramis",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/57.jpg"
        ),
        List(
            "58",
            "Supeno",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/58.jpg"
        ),
        List(
            "59",
            "Sultan Ageng Tirtajasa",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/59.jpg"
        ),
        List(
            "60",
            "W.R. Supratman",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/60.jpg"
        ),
        List(
            "61",
            "Nyai Akhmad Dahlan",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/61.jpg"
        ),
        List(
            "62",
            "KH. Zainal Mustofa",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/62.jpg"
        ),
        List(
            "63",
            "Sultan Hasanuddin",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/63.jpg"
        ),
        List(
            "64",
            "Kapitan Pattimura",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/64.jpg"
        ),
        List(
            "65",
            "Pangeran Diponegoro",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/65.jpg"
        ),
        List(
            "66",
            "Tuanku Imam Bonjol",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/66.jpg"
        ),
        List(
            "67",
            "Teungku Chik Ditiro",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/67.jpg"
        ),
        List(
            "68",
            "Teuku Umar",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/68.jpg"
        ),
        List(
            "69",
            "Dr. Wahidin Sudirohusodo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/69.jpg"
        ),
        List(
            "70",
            "R. Otto Iskandardinata",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/70.jpg"
        ),
        List(
            "71",
            "Robert Wolter Mongisidi",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/71.jpg"
        ),
        List(
            "72",
            "Prof. Mohammad Yamin, SH.",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/72.jpg"
        ),
        List(
            "73",
            "Laksda TNI. Anm. Jos Sudarso",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/73.jpg"
        ),
        List(
            "74",
            "Prof. DR. R. Suharso",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/74.jpg"
        ),
        List(
            "75",
            "Marsdfa TNI. Anm. Prof. DR. Abdurahman Saleh",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/75.jpg"
        ),
        List(
            "76",
            "Marsda TNI. Anm. Mas Agustinus Adisucipto",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/76.jpg"
        ),
        List(
            "77",
            "Teuku Nyak Arief",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/77.jpg"
        ),
        List(
            "78",
            "Nyi Ageng Serang",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/78.jpg"
        ),
        List(
            "79",
            "H. Rasuna Said",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/79.jpg"
        ),
        List(
            "80",
            "Marsda TNI. Anm. A. Halim Perdanakusuma",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/80.jpg"
        ),
        List(
            "81",
            "Marsma TNI. Anm. R. Iswahyudi",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/81.jpg"
        ),
        List(
            "82",
            "Kol. TNI. Inf. I Gusti Ngurah Rai",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/82.jpg"
        ),
        List(
            "83",
            "Supriyadi",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/83.jpg"
        ),
        List(
            "84",
            "Sultan Agung Hanyokrokusumo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/84.jpg"
        ),
        List(
            "85",
            "Untung Suropati",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/85.jpg"
        ),
        List(
            "86",
            "Tengku Amir Hamzah",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/86.jpg"
        ),
        List(
            "87",
            "Sultan Thaha Syaifudin",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/87.jpg"
        ),
        List(
            "88",
            "Sultan Mahmud Badaruddin II",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/88.jpg"
        ),
        List(
            "89",
            "Dr. Ir. Soekarno",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/89.jpg"
        ),
        List(
            "90",
            "Dr. Drs. H. Mohammad Hatta",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/90.jpg"
        ),
        List(
            "91",
            "R.P. Soeroso",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/91.jpg"
        ),
        List(
            "92",
            "Radin Inten II",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/92.jpg"
        ),
        List(
            "93",
            "Pangeran Sambernyowo ( KGPAA Mangkunegoro I )",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/93.jpg"
        ),
        List(
            "94",
            "Sri Sultan Hamengku Buwono IX",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/94.jpg"
        ),
        List(
            "95",
            "Sultan Iskandar Muda",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/95.jpg"
        ),
        List(
            "96",
            "I Gusti Ketut Jelantik",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/96.jpg"
        ),
        List(
            "97",
            "Frans Kaisiepo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/97.jpg"
        ),
        List(
            "98",
            "Silas Papare",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/98.jpg"
        ),
        List(
            "99",
            "Marthen Indey",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/99.jpg"
        ),
        List(
            "100",
            "Nuku Muhammad Amiruddin",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/100.jpg"
        ),
        List(
            "101",
            "Tuanku Tambusai",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/101.jpg"
        ),
        List(
            "102",
            "Syekh Yusuf Tajul Khalwati",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/102.jpg"
        ),
        List(
            "103",
            "Hj. Fatimah Siti Hartinah Suharto",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/103.jpg"
        ),
        List(
            "104",
            "Raja Haji Fisabilillah",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/104.jpg"
        ),
        List(
            "105",
            "H. Adam Malik",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/105.jpg"
        ),
        List(
            "106",
            "Tjilik Riwut",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/106.jpg"
        ),
        List(
            "107",
            "La Maddukelleng",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/107.jpg"
        ),
        List(
            "108",
            "Sultan Assyaidis Syarif Kasim Sani Abdul Jalil Syarifuddin",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/108.jpg"
        ),
        List(
            "109",
            "H. Ilyas Yacoub",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/109.jpg"
        ),
        List(
            "110",
            "Prof. Dr. Hazairin, SH.",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/110.jpg"
        ),
        List(
            "111",
            "Abdul Kadir Gelar Raden Tumenggung Setia Pahlawan",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/111.jpg"
        ),
        List(
            "112",
            "Hj. Fatmawati Soekarno",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/112.jpg"
        ),
        List(
            "113",
            "Ranggong Daeng Romo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/113.jpg"
        ),
        List(
            "114",
            "Brigjen TNI (Purn) H. Hasan Basry",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/114.jpg"
        ),
        List(
            "115",
            "Jend. Besar TNI. Kehormatan A.H. Nasution",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/115.jpg"
        ),
        List(
            "116",
            "Jend. TNI. Keh. GPH. Djatikusumo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/116.jpg"
        ),
        List(
            "117",
            "Andi Djemma",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/117.jpg"
        ),
        List(
            "118",
            "Pong Tiku alias Ne Baso",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/118.jpg"
        ),
        List(
            "119",
            "Prof. MR. RH. Iwa Kusuma Sumantri",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/119.jpg"
        ),
        List(
            "120",
            "H.I. Nani Wartabone",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/120.jpg"
        ),
        List(
            "121",
            "Maskoen Soemadiredja",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/121.jpg"
        ),
        List(
            "122",
            "Andi Mapanyuki",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/122.jpg"
        ),
        List(
            "123",
            "Raja Ali Haji",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/123.jpg"
        ),
        List(
            "124",
            "KH. Akhmad Rifai",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/124.jpg"
        ),
        List(
            "125",
            "Gatot Mangkupradja",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/125.jpg"
        ),
        List(
            "126",
            "Ismail Marzuki",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/126.jpg"
        ),
        List(
            "127",
            "Kiras Bangun ( Garamata )",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/127.jpg"
        ),
        List(
            "128",
            "Bagindo Azischan",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/128.jpg"
        ),
        List(
            "129",
            "Andi Abdullah Bau Massepe",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/129.jpg"
        ),
        List(
            "130",
            "Pangeran Mangkubumi/Sultan HB I",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/130.jpg"
        ),
        List(
            "131",
            "Kiai Haji Noer Ali",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/131.jpg"
        ),
        List(
            "132",
            "R.M. Tirto Adhi Soerjo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/132.jpg"
        ),
        List(
            "133",
            "H. Padjonga Daeng Ngalle Polobangkeng",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/133.jpg"
        ),
        List(
            "134",
            "Opu Daeng Risadju",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/134.jpg"
        ),
        List(
            "135",
            "H. Andi Sulthan Daeng Radja",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/135.jpg"
        ),
        List(
            "136",
            "Izaac Huru Doko",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/136.jpg"
        ),
        List(
            "137",
            "Dr. Mr. Teuku H. Moehammad Hasan",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/137.jpg"
        ),
        List(
            "138",
            "Mayjen. TNI. (Purn) dr. Adnan Kapau Gani",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/138.jpg"
        ),
        List(
            "139",
            "Mr. Dr. Ide Anak Agung Gde Agung",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/139.jpg"
        ),
        List(
            "140",
            "Mayjen. TNI (Purn). Prof. DR.Moestopo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/140.jpg"
        ),
        List(
            "141",
            "Brigjen.TNI. (Anm) Ign. Slamet Rijadi",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/141.jpg"
        ),
        List(
            "142",
            "DR. Mohammad Natsir",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/142.jpg"
        ),
        List(
            "143",
            "K.H. Abdul Halim",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/143.jpg"
        ),
        List(
            "144",
            "Sutomo ( Bung Tomo )",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/144.jpg"
        ),
        List(
            "145",
            "Laksamana Muda TNI (Purn) Jahja Daniel Dharma",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/145.jpg"
        ),
        List(
            "146",
            "Prof. Dr. Ir. Herman Johannes",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/146.jpg"
        ),
        List(
            "147",
            "Prof. Mr. Achmad Subardjo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/147.jpg"
        ),
        List(
            "148",
            "Johannes Abraham Dimara",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/148.jpg"
        ),
        List(
            "149",
            "Dr. Johannes Leimena",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/149.jpg"
        ),
        List(
            "150",
            "I.J. Kasimo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/150.jpg"
        ),
        List(
            "151",
            "Sri Susuhunan Pakubuwono X",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/151.jpg"
        ),
        List(
            "152",
            "Dr. K.H. Idham Chalid",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/152.jpg"
        ),
        List(
            "153",
            "H. Abdul Malik Karim Amrullah ( Buya Hamka)",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/153.jpg"
        ),
        List(
            "154",
            "I Gusti Ketut Pudja",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/154.jpg"
        ),
        List(
            "155",
            "Ki Sarmidi Mangunsarkoro",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/155.jpg"
        ),
        List(
            "156",
            "Mr. Syafruddin Prawiranegara",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/156.jpg"
        ),
        List(
            "157",
            "Dr. K.R.T. Radjiman Wediodiningrat",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/157.jpg"
        ),
        List(
            "158",
            "Lambertus Nicodemus Palar",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/158.jpg"
        ),
        List(
            "159",
            "Letnan Jenderal (Purn) Tahi Bonar Simatupang",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/159.jpg"
        ),
        List(
            "160",
            "Letnan Jenderal (Purn) Jamin Gintings",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/160.jpg"
        ),
        List(
            "161",
            "Mr. H.R. Moehammad Mangoendiprodjo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/161.jpg"
        ),
        List(
            "162",
            "Sukarni Kartodiwirjo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/162.jpg"
        ),
        List(
            "163",
            "K.H. Abdul Wahab Chasbullah",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/163.jpg"
        ),
        List(
            "164",
            "Bernard Wilhelm Lapian",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/164.jpg"
        ),
        List(
            "165",
            "Mas Isman",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/165.jpg"
        ),
        List(
            "166",
            "I Gusti Ngurah Made Agung",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/166.jpg"
        ),
        List(
            "167",
            "Komjen Pol. (Purn) DR. H. M. Jasin",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/167.jpg"
        ),
        List(
            "168",
            "Ki Bagus Hadikusumo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/168.jpg"
        ),
        List(
            "169",
            "K.H.R. Asad Syamsul Arifin",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/169.jpg"
        ),
        List(
            "170",
            "TGKH.Muhammad Zainuddin Abdul Madjid",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/170.jpg"
        ),
        List(
            "171",
            "Laksamana Keumalahayati",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/171.jpg"
        ),
        List(
            "172",
            "Sultan Mahmud Riayat Syah",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/172.jpg"
        ),
        List(
            "173",
            "Prof.Drs.H.Lafran Pane",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/173.jpg"
        ),
        List(
            "174",
            "Depati Amir",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/174.jpg"
        ),
        List(
            "175",
            "Abdurrahman Baswedan",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/175.jpg"
        ),
        List(
            "176",
            "Mr.Kasman Singodimedjo",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/176.jpg"
        ),
        List(
            "177",
            "Ir.Pangeran Mohammad Noor",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/177.jpg"
        ),
        List(
            "178",
            "Ibu Agung Hajjah Andi Depu",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/178.jpg"
        ),
        List(
            "179",
            "Brigjen K H Syamun",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/179.jpg"
        ),
        List(
            "180",
            "MR. Alexander Andries Maramis",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/180.jpg"
        ),
        List(
            "181",
            "K.H. Masjkur",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/181.jpg"
        ),
        List(
            "182",
            "Prof. Dr. M.Sardjito",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/182.jpg"
        ),
        List(
            "183",
            "Prof. KH. Abdul Kahar Mudzakkir",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/183.jpg"
        ),
        List(
            "184",
            "Ruhana Kuddus",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/184.jpg"
        ),
        List(
            "185",
            "Sultan Himayatuddin Muhammad Saidi",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/185.jpg"
        ),
        List(
            "186",
            "Arnold Mononutu",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/186.jpg"
        ),
        List(
            "187",
            "Jend.Pol (Purn) R.S.Soekanto",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/187.jpg"
        ),
        List(
            "188",
            "Machmud Singgirei Rumagesan",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/188.jpg"
        ),
        List(
            "189",
            "Mr. S.M. Amin Nasution",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/189.jpg"
        ),
        List(
            "190",
            "Raden Mattaher",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/190.jpg"
        ),
        List(
            "191",
            "Sultan Baabullah",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/191.jpg"
        ),
        List(
            "192",
            "Tombolotutu Gelar Poidarawati",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/192.jpg"
        ),
        List(
            "193",
            "Sultan Aji Muhammad Idris",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/193.jpg"
        ),
        List(
            "194",
            "Raden Aria Wangsakara",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/194.jpg"
        ),
        List(
            "195",
            "H. Usmar Ismail",
            "https://raw.githubusercontent.com/dicodingacademy/assets/main/android_compose_academy/pahlawan/195.jpg"
        ),
    )
}