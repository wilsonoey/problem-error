package id.dicoding.submission_android_jetpack_compose.ui.theme

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import id.dicoding.submission_android_jetpack_compose.model.ListsData

@Composable
fun JetListsApp(
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier) {
        LazyColumn {
            items(ListsData.lists, key = { it.id }) { list ->
                ListItem(
                    name = list.name,
                    photoUrl = list.photoUrl,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}



@Preview(showBackground = true)
@Composable
fun JetListsAppPreview() {
    Submission_android_jetpack_composeTheme {
        JetListsApp()
    }
}