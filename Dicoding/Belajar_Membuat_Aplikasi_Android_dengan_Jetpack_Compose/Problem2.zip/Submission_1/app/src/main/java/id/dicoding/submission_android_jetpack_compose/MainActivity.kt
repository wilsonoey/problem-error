package id.dicoding.submission_android_jetpack_compose

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import id.dicoding.submission_android_jetpack_compose.ui.theme.JetListsApp
import id.dicoding.submission_android_jetpack_compose.ui.theme.Submission_android_jetpack_composeTheme
import id.dicoding.submission_android_jetpack_compose.ui.theme.modifiers.AboutApp
import id.dicoding.submission_android_jetpack_compose.ui.theme.navigation.Screen


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Submission_android_jetpack_composeTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    DefaultPreview()
                }
            }
        }
    }

}



@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            JetListsApp(navController = rememberNavController())
        }
        composable(Screen.Profile.route) {
            AboutApp(navController = rememberNavController())
        }
    }
}