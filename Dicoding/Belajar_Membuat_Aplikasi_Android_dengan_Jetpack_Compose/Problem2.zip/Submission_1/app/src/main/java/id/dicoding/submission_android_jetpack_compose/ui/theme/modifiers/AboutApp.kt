package id.dicoding.submission_android_jetpack_compose.ui.theme.modifiers

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import coil.ImageLoader
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import id.dicoding.submission_android_jetpack_compose.ui.theme.Submission_android_jetpack_composeTheme
import id.dicoding.submission_android_jetpack_compose.ui.theme.navigation.Screen

@Composable
fun AboutApp(modifier: Modifier = Modifier, navController: NavHostController = rememberNavController()) {
    Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .fillMaxWidth()
                .fillMaxHeight()
                .padding(10.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                rememberAsyncImagePainter(
                    ImageRequest.Builder(LocalContext.current)
                    .data(data = "https://d17ivq9b7rppb3.cloudfront.net/small/avatar/2020102114351257b989b1365010d37943fb517e2fbe2a.png")
                    .allowHardware(false)
                    .build()),
                contentDescription = null,
                modifier = Modifier.size(128.dp)
            )
            Text(text = "Wilson Jonathan Oey", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
    }
    Box(modifier = modifier) {
        TopAppBar(elevation = 10.dp) {
            Button(onClick = {navController.navigate(Screen.Home.route)}, modifier = modifier) {
                Box(modifier = modifier.fillMaxWidth()) {
                    Icon(
                        Icons.Filled.ArrowBack,
                        contentDescription = "Kembali",
                        modifier = Modifier.size(ButtonDefaults.IconSize)
                    )
                }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(text = "Profil Saya", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
    }
}



@Preview(showBackground = true)
@Composable
fun JetListsAppPreview() {
    Submission_android_jetpack_composeTheme {
        AboutApp()
    }
}