package id.dicoding.submission_android_jetpack_compose.ui.theme

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.R
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.navigation.compose.rememberNavController
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import id.dicoding.submission_android_jetpack_compose.model.ListsData
import id.dicoding.submission_android_jetpack_compose.ui.theme.modifiers.AboutApp
import id.dicoding.submission_android_jetpack_compose.ui.theme.navigation.Screen

@Composable
fun JetListsApp(navController: NavHostController, modifier: Modifier = Modifier) {
//    val navBackStackEntry by navController.currentBackStackEntryAsState()
//    val currentRoute = navBackStackEntry?.destination?.route
    Box(modifier = modifier) {
        LazyColumn {
            items(ListsData.lists, key = { it.id }) { list ->
                ListItem(
                    name = list.name,
                    photoUrl = list.photoUrl,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
    Box(modifier = modifier) {
        TopAppBar(elevation = 10.dp) {
            Row(horizontalArrangement = Arrangement.SpaceBetween) {
                Spacer(modifier = Modifier.width(10.dp))
                Text(text = "AppBar", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Button(onClick = {navController.navigate(Screen.Profile.route)}) {
                    Icon(
                        Icons.Filled.AccountCircle,
                        contentDescription = "Profil Saya",
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun JetListsAppPreview() {
    Submission_android_jetpack_composeTheme {
        JetListsApp(navController = rememberNavController())
    }
}