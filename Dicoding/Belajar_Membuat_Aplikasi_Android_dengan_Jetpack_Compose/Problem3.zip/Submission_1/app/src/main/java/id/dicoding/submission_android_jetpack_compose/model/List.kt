package id.dicoding.submission_android_jetpack_compose.model

data class List(
    val id: Int,
    val name: String,
    val photoUrl: String,
    val description: String
)