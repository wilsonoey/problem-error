package id.dicoding.submission_android_jetpack_compose.ui.theme

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.navigation.compose.rememberNavController
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.dicoding.submission_android_jetpack_compose.model.ListsData
import id.dicoding.submission_android_jetpack_compose.ui.theme.navigation.Screen

@JvmOverloads
@Composable
fun JetListsApp(navController: NavHostController = rememberNavController(), selectedList: (Int) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(elevation = 10.dp, modifier = Modifier) {
                Row(horizontalArrangement = Arrangement.SpaceBetween) {
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(text = "TV List", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(230.dp))
                    Button(onClick = {navController.navigate(Screen.Profile.route)}) {
                        Icon(
                            Icons.Filled.AccountCircle,
                            contentDescription = "about_page",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    ) {padding ->
        LazyColumn {
            items(ListsData.lists, key = { it.id }) { list ->
                ListItem(
                    name = list.name,
                    photoUrl = list.photoUrl,
                    modifier = Modifier
                        .fillMaxWidth().padding(padding)
                        .clickable(onClick = { selectedList(list.id) })
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun JetListsAppPreview() {
    Submission_android_jetpack_composeTheme {
        JetListsApp(selectedList = {})
    }
}