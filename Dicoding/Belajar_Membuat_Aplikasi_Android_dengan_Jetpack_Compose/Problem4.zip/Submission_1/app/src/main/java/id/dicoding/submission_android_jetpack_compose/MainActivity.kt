package id.dicoding.submission_android_jetpack_compose

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import id.dicoding.submission_android_jetpack_compose.ui.theme.Submission_android_jetpack_composeTheme
import id.dicoding.submission_android_jetpack_compose.modifiers.AboutApp
import id.dicoding.submission_android_jetpack_compose.modifiers.DetailScreen
import id.dicoding.submission_android_jetpack_compose.modifiers.JetListsApp
import id.dicoding.submission_android_jetpack_compose.navigation.Screen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Submission_android_jetpack_composeTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    DefaultPreview()
                }
            }
        }
    }

}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            JetListsApp(
                navController = navController,
                modifier = Modifier,
                selectedList = {data ->
                    navController.navigate(Screen.Detail.createRoute(data))
                }
            )
        }
        composable(Screen.Profile.route) {
            AboutApp(modifier = Modifier, navController)
        }
        composable(
            Screen.Detail.route,
            arguments = listOf(navArgument("detailId") { type = NavType.StringType })
        ) {
            val id = it.arguments?.getString("detailId") ?: "00"
            DetailScreen(listId = id, navController = navController, modifier = Modifier)
        }
    }
}