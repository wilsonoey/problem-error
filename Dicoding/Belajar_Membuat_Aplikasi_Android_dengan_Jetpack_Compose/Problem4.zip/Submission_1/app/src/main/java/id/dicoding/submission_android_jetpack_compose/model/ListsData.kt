package id.dicoding.submission_android_jetpack_compose.model

object ListsData {
    val lists = listOf(
        ListTV(
            "1",
            "GTV",
            "https://www.transtv.co.id/livetv/anytv/GTV_live_streaming_tv.jpg",
            "GTV adalah salah satu stasiun televisi swasta nasional di Indonesia yang diluncurkan pada tanggal 22 Maret 1999. Stasiun televisi ini awalnya dimiliki oleh ICMI dan IIFTIHAR (via PT Titian Paraputra Sejahtera) dengan nama perusahaan PT Global Informasi Bermutu. Global TV memperoleh izin siaran pada tanggal 25 Oktober 1999 yang ditujukan untuk televisi dengan syiar Islam, pendidikan, teknologi dan pengembangan sumber daya manusia. Berawal dari sebuah stasiun televisi lokal di Jakarta, GTV belakangan meluaskan siaran ke 5 kota besar lainnya. Pada tanggal 11 Oktober 2017, Global TV berganti nama menjadi GTV dalam rangka acara ulang tahun GTV yang bernama \"Amazing 15\"."
        ),
        ListTV(
            "2",
            "Indosiar",
            "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Indosiar_2015.svg/300px-Indosiar_2015.svg.png",
            "PT. Indosiar Visual Mandiri resmi mengudara sebagai televisi nasional pada tanggal 11 Januari 1995. Selanjutnya Indosiar melakukan perubahan status Perseroan menjadi Perseroan Terbatas Terbuka pada tahun 2004, sehingga nama Indosiar berubah menjadi PT. Indosiar Visual Mandiri Tbk."
        ),
        ListTV(
            "3",
            "Kompas TV",
            "https://cdns.klimg.com/merdeka.com/i/w/news/2015/06/16/554640/540x270/tayangkan-ciuman-bibir-kompas-tv-disemprit-kpi.jpg",
            "Kompas TV adalah stasiun televisi swasta nasional di Indonesia yang berfokus pada konten berita yang diluncurkan pada tanggal 9 September 2011. Stasiun televisi ini hadir menggantikan stasiun televisi yang pernah dimiliki oleh Kompas Gramedia, yaitu TV7. Sejak saham TV7 dibeli oleh pihak Trans Corp dibawah kepemimpinan Chairul Tanjung pada tahun 2006 dan nama TV7 diganti menjadi Trans7, maka saham Kompas Gramedia terhadap Trans7 menurun menjadi hampir setengah dari Trans Corp. "
        ),
        ListTV(
            "4",
            "Metro TV",
            "https://scontent.fupg7-1.fna.fbcdn.net/v/t1.6435-9/47500411_2523991977614406_5826182235773992960_n.jpg?_nc_cat=105&ccb=1-7&_nc_sid=174925&_nc_eui2=AeGVcChlG-TC2Ba39AGiCQpaUcM5glYs4LRRwzmCVizgtO1NvkmdsI6Pu_VysXJtSv2HvNwmpUPkQx4k0sMByJmj&_nc_ohc=obetSiiKfXEAX8Vb-mh&_nc_ht=scontent.fupg7-1.fna&oh=00_AfBI-UknpGiyuWhGcft_WYklENicziL32yDPEyLlgoWvSw&oe=63B26AA7",
            "MetroTV adalah sebuah stasiun televisi swasta berita yang berkedudukan di Indonesia yang diluncurkan pada tanggal 25 November 2000 di Jakarta dan didirikan oleh PT Media Televisi Indonesia. Pada awalnya didirikan sebagai perusahaan patungan dengan kepemilikan saat itu adalah Media Group dan Bimantara Citra dengan kepemilikan masing-masing 75% dan 25%. Sejak Oktober 2003, pihak Bimantara Citra resmi menjual sisa 25% saham MetroTV ke Media Group, sehingga kepemilikan MetroTV sudah 100 persen dimiliki oleh Media Group dibawah pimpinan Surya Paloh yang juga memiliki harian Media Indonesia dan Lampung Post. Pada tanggal 20 Mei 2010, MetroTV memperkenalkan logo dengan dasar lambang  burung elang dan warna dasar biru dan kuning, jenis huruf Handel Gothic kursif yang memberikan kesan modern, segar dan futuristik, serta slogan barunya \"Knowledge to Elevate\". Stasiun TV ini memiliki konsep agak berbeda dengan stasiun televisi lain, sebab selain mengudara selama 24 jam setiap hari, stasiun TV ini hanya memusatkan acaranya pada siaran warta berita saja. Seiring dari waktu ke waktu, stasiun ini kemudian juga memasukkan unsur hiburan dalam program-programnya, meski tetap dalam koridor warta berita. Stasiun ini terkenal dengan pembawa acara berita terbanyak di Indonesia. "
        ),
        ListTV(
            "5",
            "RCTI",
            "https://upload.wikimedia.org/wikipedia/id/thumb/d/dd/RCTI_logo_2015.svg/300px-RCTI_logo_2015.svg.png",
            "RCTI merupakan jaringan televisi swasta pertama di Indonesia yang dimiliki oleh Media Nusantara Citra (MNC) yang mengudara pada 13 November 1988 dan diresmikan 24 Agustus 1989 pukul 13.30 WIB dan pada waktu itu, siaran RCTI hanya dapat ditangkap oleh pelanggan yang memiliki dekoder dan membayar iuran setiap bulannya.RCTI melepas dekodernya setahun setelah mulai bersiaran pada tanggal 24 Agustus 1990 yang menandakan mulainya TV ini bersiaran secara terestrial. Setelah tiga tahun, pada tanggal 24 Agustus 1993, RCTI resmi bersiaran secara nasional. Sejak Oktober 2003, RCTI dimiliki oleh Media Nusantara Citra, kelompok perusahaan media yang juga memiliki GTV dan MNCTV. "
        ),
        ListTV(
            "6",
            "SCTV",
            "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cc/SCTV_Logo.svg/300px-SCTV_Logo.svg.png",
            "SCTV atau yang disingkat dengan Surya Citra Televisi adalah sebuah stasiun televisi swasta nasional di Indonesia yang diluncurkan pada tanggal 24 Agustus 1990 sebagai stasiun televisi lokal di Surabaya yang berpusat di Jl. Darmo Permai, Surabaya, Jawa Timur dan stasiun televisi ini merupakan stasiun televisi swasta kedua di Indonesia setelah RCTI. Meski tanggal itu (24 Agustus 1990) ditetapkan sebagai tanggal lahir SCTV, tetapi baru tanggal 1 Januari 1993, SCTV mendapatkan izin sebagai stasiun televisi nasional di Jakarta."
        ),
        ListTV(
            "7",
            "Trans 7",
            "https://upload.wikimedia.org/wikipedia/id/thumb/7/79/Trans_7_2013.svg/300px-Trans_7_2013.svg.png",
            "Trans7 adalah sebuah stasiun televisi swasta nasional di Indonesia yang pada awalnya menggunakan nama TV7, melakukan siaran perdananya secara terestrial di Jakarta pada 25 November 2001 pukul 17:00 WIB. Pada tanggal 4 Agustus 2006, Trans Corp menjajaki kerjasama strategis dengan mengakuisisi saham TV7 dan melakukan relaunch (peluncuran ulang) pada tanggal 15 Desember 2006 pukul 17:00 WIB menggunakan nama baru, menjadi Trans7. Pada tahun 2017, Trans7 memegang hak siar berlisensi dalam ajang Piala Dunia FIFA 2018 bersama Trans TV dan Transvision. Acara yang ditayangkan pada stasiun televisi ini cukup beragam, mulai dari acara berita, selebriti, hingga hibuaran yang akan ditonton oleh semua masyarakat Indonesia."
        ),
        ListTV(
            "8",
            "Trans TV",
            "https://upload.wikimedia.org/wikipedia/id/thumb/6/62/Trans_TV_2013.svg/300px-Trans_TV_2013.svg.png",
            "Trans TV adalah sebuah stasiun televisi swasta nasional di Indonesia yang dimiliki oleh Trans Media (dulunya dimiliki oleh Trans Corp) yang diluncurkan pada tanggal 15 Desember 2001 pukul 17.00 WIB."
        ),
        ListTV(
            "9",
            "TV One",
            "https://upload.wikimedia.org/wikipedia/id/thumb/2/20/TvOne_logo_2012.svg/300px-TvOne_logo_2012.svg.png",
            "tvOne (sebelumnya bernama Lativi) adalah sebuah stasiun televisi nasional di Indonesia. Berawal dari penggunaan nama Lativi, stasiun televisi ini didirikan pada tanggal 30 Juli 2002 pukul 16:00 WIB oleh Abdul Latief dan dimiliki oleh ALatief Corporation. Pada saat itu, konsep penyusunan acaranya adalah banyak menonjolkan masalah yang berbau klenik, erotisme, berita kriminalitas dan beberapa hiburan ringan lainnya. Sejak tahun 2007, saham mayoritasnya dimiliki oleh Grup Bakrie (melalui PT Visi Media Asia) yang juga memiliki stasiun televisi antv, dan Abdul Latief tidak lagi berada dalam kepemilikan sahamnya.\n" +
                    "\n" +
                    "Pada tanggal 14 Februari 2008 pukul 19:30 WIB, Lativi secara resmi berganti nama menjadi tvOne, dengan komposisi 70 persen berita, sisanya gabungan program olahraga dan hiburan. Direktur Utama tvOne saat ini adalah Ahmad R. Widarmana."
        ),
        ListTV(
            "10",
            "TVRI",
            "https://upload.wikimedia.org/wikipedia/commons/thumb/e/eb/TVRILogo2019.svg/225px-TVRILogo2019.svg.png",
            "TVRI atau yang disingkat Televisi Republik Indonesia adalah jaringan televisi publik berskala nasional di Indonesia yang diluncurkan pada tanggal 24 Agustus 1962. Berdasarkan Undang-Undang Nomor 32 Tahun 2002 tentang Penyiaran, TVRI berstatus sebagai Lembaga Penyiaran Publik bersama Radio Republik Indonesia. TVRI saat ini mengudara di seluruh wilayah Indonesia dengan sistem siaran analog dan siaran digital. TVRI menjalankan 3 saluran televisi berskala nasional (dengan 2 di antaranya hanya bersiaran digital) dan 30 stasiun televisi daerah serta didukung 361 stasiun transmisi (termasuk 120 stasiun transmisi digital) di seluruh provinsi Indonesia."
        ),
    )
}