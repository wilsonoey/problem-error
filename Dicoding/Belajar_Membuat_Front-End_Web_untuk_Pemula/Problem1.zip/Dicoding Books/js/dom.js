const UNCOMPLETED_LIST_TODO_ID = "todos";
const COMPLETED_LIST_TODO_ID = "completed-todos";
const TODO_BEFOREITEMID = "itemId";
const TODO_ITEMID = "itemId";

function makeTodo(data, name, timestamp, isCompleted) {
    const textTitle = document.createElement("h1");
    textTitle.innerText = data;
    const textName = document.createElement("h2");
    textName.innerText = name;
    const textTimestamp = document.createElement("p");
    textTimestamp.innerText = timestamp;
    const textContainer = document.createElement("div");
    textContainer.classList.add("inner")
    textContainer.append(textTitle, textName, textTimestamp);
    const container = document.createElement("div");
    container.classList.add("item", "shadow")
    container.append(textContainer);
    if (isCompleted) {
        container.append(
            createUndoButton(),
            createTrashButton()
        );
    } else {
        container.append(
            createCheckButton(),
            createTrashButton()
        );
    }
    return container;
}

function createUndoButton() {
    return createButton("undo-button", function (event) {
        undoTaskFromCompleted(event.target.parentElement);
    });
}

function createTrashButton() {
    return createButton("trash-button", function (event) {
        visibleAlertDialog.style.visibility = "visible";
        const cancelButton = document.getElementById("close");
        const noButton = document.getElementById("no");
        const yesButton = document.getElementById("yes");
        const okButton = document.getElementById("ok");
        if (noButton || cancelButton || yesButton || okButton) {
            noButton.addEventListener("click", function () {
                visibleAlertDialog.style.visibility = "hidden";
            });
            cancelButton.addEventListener("click", function () {
                visibleAlertDialog.style.visibility = "hidden";
            });
            yesButton.addEventListener("click", function () {
                visibleAlertDialog.style.visibility = "hidden";
                visibleSuccessDialog.style.visibility = "visible";
                removeTaskFromCompleted(event.target.parentElement);
            });
            okButton.addEventListener("click", function () {
                visibleSuccessDialog.style.visibility = "hidden";
            });
        }
    });
}

function createCheckButton() {
    return createButton("check-button", function (event) {
        addTaskToCompleted(event.target.parentElement);
    });
}

function createButton(buttonTypeClass, eventListener) {
    const button = document.createElement("button");
    button.classList.add(buttonTypeClass);
    button.addEventListener("click", function (event) {
        eventListener(event);
        event.stopPropagation();
    });
    return button;
}

function addTodo() {
    const uncompletedTODOList = document.getElementById(UNCOMPLETED_LIST_TODO_ID);
    const textTodo = document.getElementById("title").value;
    const textName = document.getElementById("nameauthor").value;
    const timestamp = document.getElementById("date").value;
    const todo = makeTodo(textTodo, textName, timestamp, false);
    const todoObject = composeTodoObject(textTodo, textName, timestamp, false);
    todo[TODO_ITEMID, TODO_BEFOREITEMID] = todoObject.id;
    todos.push(todoObject);
    uncompletedTODOList.append(todo);
    updateDataToStorage();
}

function addTaskToCompleted(taskElement) {
    const listCompleted = document.getElementById(COMPLETED_LIST_TODO_ID);
    const taskTitle = taskElement.querySelector(".inner > h1").innerText;
    const taskName = taskElement.querySelector(".inner > h2").innerText;
    const taskTimestamp = taskElement.querySelector(".inner > p").innerText;
    const newTodo = makeTodo(taskTitle, taskName, taskTimestamp, true);
    const todo = findTodo(taskElement[TODO_ITEMID, TODO_BEFOREITEMID]);
    todo.isCompleted = true;
    newTodo[TODO_ITEMID, TODO_BEFOREITEMID] = todo.id;
    listCompleted.append(newTodo);
    taskElement.remove();
    updateDataToStorage();
}

function removeTaskFromCompleted(taskElement) {
    const todoPosition = findTodoIndex(taskElement[TODO_ITEMID, TODO_BEFOREITEMID]);
    todos.splice(todoPosition, 1);
    taskElement.remove();
    updateDataToStorage();
}

function undoTaskFromCompleted(taskElement) {
    const listUncompleted = document.getElementById(UNCOMPLETED_LIST_TODO_ID);
    const taskTitle = taskElement.querySelector(".inner > h1").innerText;
    const taskName = taskElement.querySelector(".inner > h2").innerText;
    const taskTimestamp = taskElement.querySelector(".inner > p").innerText;
    const newTodo = makeTodo(taskTitle, taskName, taskTimestamp, false);
    const todo = findTodo(taskElement[TODO_ITEMID, TODO_BEFOREITEMID]);
    todo.isCompleted = false;
    newTodo[TODO_ITEMID, TODO_BEFOREITEMID] = todo.id;
    listUncompleted.append(newTodo);
    taskElement.remove();
    updateDataToStorage();
}

function refreshDataFromTodos() {
    const listUncompleted = document.getElementById(UNCOMPLETED_LIST_TODO_ID);
    let listCompleted = document.getElementById(COMPLETED_LIST_TODO_ID);
    for(todo of todos){
        const newTodo = makeTodo(todo.title, todo.author, todo.year, todo.isCompleted);
        newTodo[TODO_ITEMID, TODO_BEFOREITEMID] = todo.id;
        if(todo.isCompleted){
            listCompleted.append(newTodo);
        } else {
            listUncompleted.append(newTodo);
        }
    }
}