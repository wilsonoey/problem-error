const visibleAlertDialog = document.getElementById("dialog-alert");
const visibleSuccessDialog = document.getElementById("dialog-success");
visibleAlertDialog.style.visibility = "hidden";
visibleSuccessDialog.style.visibility = "hidden";

document.addEventListener("DOMContentLoaded", function () {
    const submitForm = document.getElementById("form");
    submitForm.addEventListener("submit", function (event) {
        event.preventDefault();
        addTodo();
    });
    if(isStorageExist()){
        loadDataFromStorage();
    }
    search();
    const uncompletedTabButton = document.getElementById("uncompleted");
    const completedTabButton = document.getElementById("completed");
    const uncompletedList = document.getElementById(UNCOMPLETED_LIST_TODO_ID);
    const completedList = document.getElementById(COMPLETED_LIST_TODO_ID);
    uncompletedTabButton.style.border = "3px solid #000000";
    completedList.style.display = "none";
    uncompletedTabButton.addEventListener("click", function () {
        search();
        uncompletedTabButton.style.border = "3px solid #000000";
        completedTabButton.style.border = "none";
        uncompletedList.style.display = "block";
        completedList.style.display = "none";
    });
    completedTabButton.addEventListener("click", function () {
        search();
        completedTabButton.style.border = "3px solid #000000";
        uncompletedTabButton.style.border = "none";
        completedList.style.display = "block";
        uncompletedList.style.display = "none";
    });
});

document.addEventListener("ondatasaved", () => {
    console.log("Data berhasil di simpan.");
});

document.addEventListener("ondataloaded", () => {
    refreshDataFromTodos();
});

function search() {
    const searchElement = document.getElementById("searchElement");
    searchElement.addEventListener("input", function () {
        const searchText = searchElement.value.toLowerCase();
        const todoItems = document.querySelectorAll(".item");
        todoItems.forEach(function (item) {
            const title = item.querySelector(".inner > h1").innerText.toLowerCase();
            const todosList = document.getElementById("todos");
            const completedList = document.getElementById("completed-todos");
            if (title.indexOf(searchText) > -1) {
                item.querySelector(".inner > h1").innerHTML = title.replace(searchText, `<mark>${searchText}</mark>`);
            } else {
                todosList.innerHTML = "<p>No matching plan items found.</p>";
                completedList.innerHTML = "<p>No matching completed items found.</p>";
            }
        });
    });
}