function clickVisible() {
  var show_hide = document.getElementById("main-content");
  if (show_hide.className === "show-hide") {
    show_hide.className += "menu-nav";
  } else {
    show_hide.className = "show-hide";
  }
}
class appBar extends HTMLElement {
    connectedCallback() {
      this.render();
    }
  
    render() {
      this.innerHTML = `
        <header class="restaurant-app__header">
          <h1>Restaurant Apps</h1>
          <a href="#main-content" class="return-to-link-main-content">Menuju ke konten</a>
          <div class="menu">
            <a href="/" class="menu-button">Home</a>
            <a href="#" class="menu-button">Favorite</a>
            <a href="https://github.com/wilsonoey60" class="menu-button">About Us</a>
          </div>
          <button id="show-hide" class="menu-phone" type="button" aria-label="navigation-menu" onclick="${clickVisible}">☰</button>
        </header>
        <div class="navigation-drawer" id="menu-nav">
          <a href="/" class="menu-drawer-button">Home</a>
          <a href="#" class="menu-drawer-button">Favorite</a>
			    <a href="https://github.com/wilsonoey60" class="menu-drawer-button">About Us</a>
		    </div>
      `;
    }
  }
  
  customElements.define('app-bar', appBar);