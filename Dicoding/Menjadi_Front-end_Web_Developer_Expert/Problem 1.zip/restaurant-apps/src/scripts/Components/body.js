class customBody extends HTMLElement {
    connectedCallback() {
      this.render();
    }
  
    render() {
      this.innerHTML = `
    <div class="container-image">
        <div class="container-glass">
            <h1>Restaurant Apps</h1>
            <h3>Temukan aneka kuliner di sini!</h3>
            <a href="#" class="container-glass-button">Selengkapnya</a>
        </div>
    </div>
      `;
    }
  }
  
  customElements.define('custom-body', customBody);