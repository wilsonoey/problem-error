import 'regenerator-runtime';
import '../styles/Features/main.css';
import '../styles/Features/appbar.css';
import '../styles/Features/body.css';
import '../styles/Features/footer.css';
import '../styles/Responsives/responsive.css';
import '../scripts/Components/appBar.js';
import lists from '../data.json';




const getExploreRestaurant = (data) => {
    data.restaurants.forEach(restaurant => {
        const restaurantItem = document.getElementById('explore-restaurant-list');
        restaurantItem.innerHTML += `
        <div id="Group" class="Group">
		    <div id="items" class="items">
			    <img class="item-image" alt="${restaurant.name}" src="${restaurant.pictureId}"/>
			    <div id="item-title" class="item_title">
				    <div id="Nama_Restoran">
				    	<span>${restaurant.name}</span>
				    </div>
				    <div id="Rating">
					    <span>Rating : ${restaurant.rating}</span>
				    </div>
			    </div>
			    <div id="item-description" class="item_description">
			    	<div id="Deskripsi">
			    		<span>${restaurant.description}</span>
			    	</div>
			    </div>
		    </div>
	    </div>
		
        `;
    })
}
getExploreRestaurant(lists);