class appBar extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `
    <header class="restaurant-app__header">
        <h1>Restaurant Apps</h1>
        <a href="#main-content" class="return-to-link-main-content">Menuju ke konten</a>
        <div class="menu">
          <a href="/" class="menu-button">Home</a>
          <a href="#" class="menu-button">Favorite</a>
          <a href="https://github.com/wilsonoey60" class="menu-button">About Us</a>
        </div>
        <button id="show-hide" type="button" aria-label="navigation-menu">☰</button>
      </header>
      <nav id="menu-nav">
        <a href="/" class="menu-drawer-button">Home</a>
        <a href="#" class="menu-drawer-button">Favorite</a>
        <a href="https://github.com/wilsonoey60" class="menu-drawer-button">About Us</a>
      </nav>
    `;
  }
}

customElements.define('app-bar', appBar);
