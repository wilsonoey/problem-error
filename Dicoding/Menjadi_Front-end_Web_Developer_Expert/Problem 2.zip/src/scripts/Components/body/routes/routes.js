import Lists from '../items/home';

const routes = {
  '/': Lists, // default page
  '/home': Lists,
};

export default routes;
