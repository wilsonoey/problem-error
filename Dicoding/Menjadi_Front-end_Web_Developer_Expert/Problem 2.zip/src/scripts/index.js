// eslint-disable-next-line import/no-unresolved
import '../styles/Features/main.css';
import '../styles/Features/appbar.css';
import '../styles/Features/body.css';
import '../styles/Features/footer.css';
import '../styles/Responsives/responsive.css';
import './Components/appBar';
import './Components/body/jumbotron';
import './Components/body/items/home';
import 'regenerator-runtime';

const restaurantButtonElement = document.querySelector('#show-hide');
const drawerElement = document.querySelector('#menu-nav');

restaurantButtonElement.addEventListener('click', event => {
  drawerElement.classList.toggle('open');
  event.stopPropagation();
});

drawerElement.addEventListener('click', event => {
  drawerElement.classList.remove('open');
  event.stopPropagation();
});
