import TheRestaurantDbSource from '../../../Data/call';

const Lists = {
  async render() {
    return `
    <div id="main-content" class="container-content">
      <h1>Explore Restaurant</h1>
    </div>
    `;
  },

  async afterRender() {
    const restaurants = await TheRestaurantDbSource.listRestaurants();
    const restaurantsContainer = document.querySelector('#explore-restaurant-list');
    restaurants.forEach((restaurant) => {
      restaurantsContainer.innerHTML += createRestaurantItemTemplate(restaurant);
    });
  },
};

export default Lists;
