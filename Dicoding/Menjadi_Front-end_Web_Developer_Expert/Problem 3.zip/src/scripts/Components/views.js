import DrawerInitiator from '../Utils/drawer-initiator';
import UrlParser from '../routes/url_parser';
import routes from '../routes/routes';

class App {
  constructor({ button, drawer, content }) {
    this.Button = button;
    this.Drawer = drawer;
    this.Content = content;

    this.initialAppShell();
  }

  initialAppShell() {
    DrawerInitiator.init({
      button: this.Button,
      drawer: this.Drawer,
      content: this.Content,
    });

    // kita bisa menginisiasikan komponen lain bila ada
  }

  async renderPage() {
    const url = UrlParser.parseActiveUrlWithCombiner();
    const page = routes[url];
    this.Content.innerHTML = await page.render();
    await page.afterRender();
  }
}

export default App;
