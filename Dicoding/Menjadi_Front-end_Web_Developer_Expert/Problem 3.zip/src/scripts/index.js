// eslint-disable-next-line import/no-unresolved
import '../styles/Features/main.css';
import '../styles/Features/appbar.css';
import '../styles/Features/body.css';
import '../styles/Features/footer.css';
import '../styles/Responsives/responsive.css';
import './Components/appBar';
import './Components/body/jumbotron';
import './Components/body/items/home';
import 'regenerator-runtime';
import App from './Components/views';

const app = new App({
  button: document.querySelector('#show-hide'),
  drawer: document.querySelector('#menu-nav'),
  content: document.querySelector('#main-content'),
});

window.addEventListener('hashchange', () => {
  app.renderPage();
});

window.addEventListener('load', () => {
  app.renderPage();
});
