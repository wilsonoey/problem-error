import CONFIG from '../../Data/api';

const createRestaurantItemTemplate = (restaurant) => `
<div id="Group" class="Group">
<div id="items" class="items">
  <img class="item-image" alt="${restaurant.name}" src="${CONFIG.BASE_IMAGE_MEDIUM_URL}"/>
  <div id="item-title" class="item_title">
    <div id="Nama_Restoran"><span>${restaurant.name}</span></div>
    <div id="Rating"><span>★${restaurant.rating}</span></div>
  </div>
  <div id="item-description" class="item_description">
    <div id="Deskripsi"><span>${restaurant.description}</span></div>
  </div>
</div>
</div>
`;

const createRestaurantDetailTemplate = (restaurant) => `
<div id="Group" class="Group">
<div id="items" class="items">
  <img class="item-image" alt="${restaurant.name}" src="${CONFIG.BASE_IMAGE_LARGE_URL + restaurant.pictureId}"/>
  <div id="item-title" class="item_title">
    <div id="Nama_Restoran"><span>${restaurant.name}</span></div>
    <div id="Rating"><span>★${restaurant.rating}</span></div>
  </div>
  <div id="item-description" class="item_description">
    <div id="Deskripsi"><span>${restaurant.description}</span></div>
  </div>
</div>
</div>
`;

export { createRestaurantItemTemplate, createRestaurantDetailTemplate };
