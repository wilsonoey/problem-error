import TheRestaurantDbSource from '../../../Data/call';

const Detail = {
  async render() {
    return `
    <div id="main-content" class="container-content">
      <h1>Detail Restaurant</h1>
    </div>
    `;
  },

  async afterRender() {
    const url = UrlParser.parseActiveUrlWithoutCombiner();
    const restaurant = await TheRestaurantDbSource.detailMovie(url.id);
    const movieContainer = document.querySelector('#explore-restaurant-list');
    movieContainer.innerHTML = createMovieDetailTemplate(restaurant);
  },
};

export default Detail;
