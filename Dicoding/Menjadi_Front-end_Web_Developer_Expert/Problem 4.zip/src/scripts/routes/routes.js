import Lists from '../Components/body/items/home';

const routes = {
  '/': Lists, // default page
  '/home': Lists,
};

export default routes;
