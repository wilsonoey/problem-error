-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 20, 2022 at 11:47 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_klinik`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_dokter`
--

CREATE TABLE `tb_dokter` (
  `id` int(11) NOT NULL,
  `nik` int(16) NOT NULL,
  `username` varchar(25) NOT NULL,
  `namalengkap` varchar(50) NOT NULL,
  `umur` int(3) NOT NULL,
  `jeniskelamin` varchar(20) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `faskes` varchar(10) NOT NULL,
  `diagnosa` text NOT NULL,
  `obat` text NOT NULL,
  `hargakonsultasi` int(10) NOT NULL,
  `statuspembayaran` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_dokter`
--

INSERT INTO `tb_dokter` (`id`, `nik`, `username`, `namalengkap`, `umur`, `jeniskelamin`, `alamat`, `faskes`, `diagnosa`, `obat`, `hargakonsultasi`, `statuspembayaran`) VALUES
(15, 0, 'jen_fe1', 'Nemin Melani', 21, 'Perempuan', 'kjrtbnjstgbbfgnbf', 'Umum', 'test vnijfd dfjdfvbjhdfv dfvbdfjvhbdfv dvdbjkvbdfv', 'bbduvdbufiv dvfvubdfbvuidfv dfvbuidbvuidbv ', 100000, ''),
(18, 0, 'jen_fe1', 'Nemin Melani', 21, 'Perempuan', 'kjrtbnjstgbbfgnbf', 'Umum', 'iuhrithgr', 'tyjntyh tyh ty trnty ntyn', 80000, 'Menunggu Pembayaran');

-- --------------------------------------------------------

--
-- Table structure for table `tb_obat`
--

CREATE TABLE `tb_obat` (
  `id` int(16) NOT NULL,
  `namaobat` varchar(100) NOT NULL,
  `jumlahobat` int(255) NOT NULL,
  `hargaobat` int(20) NOT NULL,
  `stokmasuk` int(255) NOT NULL,
  `stokkeluar` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_obat`
--

INSERT INTO `tb_obat` (`id`, `namaobat`, `jumlahobat`, `hargaobat`, `stokmasuk`, `stokkeluar`) VALUES
(9, 'OBH', 1000, 1000, 0, 0),
(10, 'Vitamin B12', 1000, 500, 0, 0),
(11, 'Lasegar', 100, 10000, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pasien`
--

CREATE TABLE `tb_pasien` (
  `id` int(11) NOT NULL,
  `nik` int(16) NOT NULL,
  `username` varchar(25) NOT NULL,
  `namalengkap` varchar(50) NOT NULL,
  `umur` int(3) NOT NULL,
  `jeniskelamin` varchar(20) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `faskes` varchar(10) NOT NULL,
  `status` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_pasien`
--

INSERT INTO `tb_pasien` (`id`, `nik`, `username`, `namalengkap`, `umur`, `jeniskelamin`, `alamat`, `faskes`, `status`) VALUES
(13, 0, 'jen_fe1', 'Nemin Melani', 21, 'Perempuan', 'kjrtbnjstgbbfgnbf', 'Umum', 'Menunggu Dokter'),
(16, 0, 'Namaj_Sharma', 'Namaj Sharma', 22, 'Laki-Laki', 'uhfbujjufv', 'BPJS', 'Menunggu Dokter');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `namalengkap` varchar(50) NOT NULL,
  `umur` int(3) NOT NULL,
  `jeniskelamin` varchar(20) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `jabatan` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `username`, `namalengkap`, `umur`, `jeniskelamin`, `alamat`, `jabatan`, `password`) VALUES
(10, 'vila1', 'Vila Dani', 19, 'Perempuan', 'jvkfv', 'Admin', 'd044de77ace8d1da16a1f74130ff73bd'),
(11, 'nfc', 'theherh', 23, 'Laki-Laki', 'bgfbfgc', 'Dokter', '062993585a465aecb861561818225523');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_dokter`
--
ALTER TABLE `tb_dokter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_obat`
--
ALTER TABLE `tb_obat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_pasien`
--
ALTER TABLE `tb_pasien`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_dokter`
--
ALTER TABLE `tb_dokter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tb_obat`
--
ALTER TABLE `tb_obat`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tb_pasien`
--
ALTER TABLE `tb_pasien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
