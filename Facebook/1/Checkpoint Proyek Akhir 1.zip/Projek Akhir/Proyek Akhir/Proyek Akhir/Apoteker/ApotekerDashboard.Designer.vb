﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ApotekerDashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ApotekerDashboard))
        Me.appBar = New System.Windows.Forms.Panel()
        Me.txtJadwal = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.showMenuItem = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.listMenuItem = New System.Windows.Forms.Panel()
        Me.pictureObat = New System.Windows.Forms.PictureBox()
        Me.pictureKeluar = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.pictureAkun = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pictureLaporan = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.pictureTransaksi = New System.Windows.Forms.PictureBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.picturePasien = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.pictureDashboard = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.buttonKeluar = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.buttonAkun = New System.Windows.Forms.Button()
        Me.buttonLaporan = New System.Windows.Forms.Button()
        Me.buttonTransaksi = New System.Windows.Forms.Button()
        Me.buttonDaftar_Obat = New System.Windows.Forms.Button()
        Me.buttonDaftar_Pasien = New System.Windows.Forms.Button()
        Me.buttonDashboard = New System.Windows.Forms.Button()
        Me.panelGrup = New System.Windows.Forms.Panel()
        Me.panelDaftarPasien = New System.Windows.Forms.Panel()
        Me.panelTindakanDP = New System.Windows.Forms.Panel()
        Me.Panel164 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.btn_IP_PengambilanObat = New System.Windows.Forms.Button()
        Me.btn_IP_Batal = New System.Windows.Forms.Button()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.txt_IP_Obat = New System.Windows.Forms.Label()
        Me.Panel31 = New System.Windows.Forms.Panel()
        Me.Panel32 = New System.Windows.Forms.Panel()
        Me.Panel35 = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Panel36 = New System.Windows.Forms.Panel()
        Me.Panel26 = New System.Windows.Forms.Panel()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.panelPengajuanObat = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.DaftarKeranjang = New System.Windows.Forms.FlowLayoutPanel()
        Me.ItemKeranjang1 = New Proyek_Akhir.ItemKeranjang()
        Me.Panel33 = New System.Windows.Forms.Panel()
        Me.Panel34 = New System.Windows.Forms.Panel()
        Me.Panel37 = New System.Windows.Forms.Panel()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Panel40 = New System.Windows.Forms.Panel()
        Me.Panel38 = New System.Windows.Forms.Panel()
        Me.Panel39 = New System.Windows.Forms.Panel()
        Me.Panel41 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Panel42 = New System.Windows.Forms.Panel()
        Me.Panel43 = New System.Windows.Forms.Panel()
        Me.Panel44 = New System.Windows.Forms.Panel()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Panel45 = New System.Windows.Forms.Panel()
        Me.Panel84 = New System.Windows.Forms.Panel()
        Me.Panel167 = New System.Windows.Forms.Panel()
        Me.Panel170 = New System.Windows.Forms.Panel()
        Me.Panel173 = New System.Windows.Forms.Panel()
        Me.txt_IP_Faskes = New System.Windows.Forms.Label()
        Me.Panel174 = New System.Windows.Forms.Panel()
        Me.Panel175 = New System.Windows.Forms.Panel()
        Me.txt_IP_Alamat = New System.Windows.Forms.Label()
        Me.Panel176 = New System.Windows.Forms.Panel()
        Me.Panel177 = New System.Windows.Forms.Panel()
        Me.txt_IP_JenisKelamin = New System.Windows.Forms.Label()
        Me.Panel178 = New System.Windows.Forms.Panel()
        Me.Panel179 = New System.Windows.Forms.Panel()
        Me.txt_IP_Umur = New System.Windows.Forms.Label()
        Me.Panel180 = New System.Windows.Forms.Panel()
        Me.Panel181 = New System.Windows.Forms.Panel()
        Me.txt_IP_NamaLengkap = New System.Windows.Forms.Label()
        Me.Panel182 = New System.Windows.Forms.Panel()
        Me.Panel183 = New System.Windows.Forms.Panel()
        Me.txt_IP_UserName = New System.Windows.Forms.Label()
        Me.Panel86 = New System.Windows.Forms.Panel()
        Me.Panel87 = New System.Windows.Forms.Panel()
        Me.txt_IP_NIK = New System.Windows.Forms.Label()
        Me.Panel184 = New System.Windows.Forms.Panel()
        Me.Panel185 = New System.Windows.Forms.Panel()
        Me.Panel188 = New System.Windows.Forms.Panel()
        Me.Panel191 = New System.Windows.Forms.Panel()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Panel192 = New System.Windows.Forms.Panel()
        Me.Panel193 = New System.Windows.Forms.Panel()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Panel194 = New System.Windows.Forms.Panel()
        Me.Panel195 = New System.Windows.Forms.Panel()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Panel196 = New System.Windows.Forms.Panel()
        Me.Panel197 = New System.Windows.Forms.Panel()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Panel198 = New System.Windows.Forms.Panel()
        Me.Panel199 = New System.Windows.Forms.Panel()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Panel200 = New System.Windows.Forms.Panel()
        Me.Panel201 = New System.Windows.Forms.Panel()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Panel119 = New System.Windows.Forms.Panel()
        Me.Panel118 = New System.Windows.Forms.Panel()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Panel202 = New System.Windows.Forms.Panel()
        Me.Panel240 = New System.Windows.Forms.Panel()
        Me.Panel165 = New System.Windows.Forms.Panel()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.btn_IP_Kembali = New System.Windows.Forms.Button()
        Me.panelBerandaDP = New System.Windows.Forms.Panel()
        Me.panelDatabaseDP = New System.Windows.Forms.Panel()
        Me.dgvDaftarPasien = New System.Windows.Forms.DataGridView()
        Me.panelTab = New System.Windows.Forms.Panel()
        Me.panelTengah = New System.Windows.Forms.Panel()
        Me.btnBelumSelesai = New System.Windows.Forms.Button()
        Me.btnSemuaPasien = New System.Windows.Forms.Button()
        Me.panelAtas = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.panelKanan = New System.Windows.Forms.Panel()
        Me.panelKiri = New System.Windows.Forms.Panel()
        Me.Panel145 = New System.Windows.Forms.Panel()
        Me.Panel146 = New System.Windows.Forms.Panel()
        Me.txtCariPasien = New System.Windows.Forms.TextBox()
        Me.Panel147 = New System.Windows.Forms.Panel()
        Me.btnCariPasien = New System.Windows.Forms.Button()
        Me.Panel148 = New System.Windows.Forms.Panel()
        Me.Panel149 = New System.Windows.Forms.Panel()
        Me.Panel150 = New System.Windows.Forms.Panel()
        Me.Panel151 = New System.Windows.Forms.Panel()
        Me.panelKeteranganDP = New System.Windows.Forms.Panel()
        Me.textKeterangan = New System.Windows.Forms.Label()
        Me.VScrollBar1 = New System.Windows.Forms.VScrollBar()
        Me.panelRiwayatDP = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.dgvRiwayatPasien = New System.Windows.Forms.DataGridView()
        Me.Panel46 = New System.Windows.Forms.Panel()
        Me.Panel47 = New System.Windows.Forms.Panel()
        Me.Panel48 = New System.Windows.Forms.Panel()
        Me.Panel49 = New System.Windows.Forms.Panel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Panel50 = New System.Windows.Forms.Panel()
        Me.Panel51 = New System.Windows.Forms.Panel()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Panel52 = New System.Windows.Forms.Panel()
        Me.Panel53 = New System.Windows.Forms.Panel()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Panel54 = New System.Windows.Forms.Panel()
        Me.Panel55 = New System.Windows.Forms.Panel()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Panel56 = New System.Windows.Forms.Panel()
        Me.Panel57 = New System.Windows.Forms.Panel()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Panel58 = New System.Windows.Forms.Panel()
        Me.Panel59 = New System.Windows.Forms.Panel()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Panel60 = New System.Windows.Forms.Panel()
        Me.Panel61 = New System.Windows.Forms.Panel()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Panel62 = New System.Windows.Forms.Panel()
        Me.Panel63 = New System.Windows.Forms.Panel()
        Me.Panel64 = New System.Windows.Forms.Panel()
        Me.Panel65 = New System.Windows.Forms.Panel()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Panel66 = New System.Windows.Forms.Panel()
        Me.Panel67 = New System.Windows.Forms.Panel()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Panel68 = New System.Windows.Forms.Panel()
        Me.Panel69 = New System.Windows.Forms.Panel()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Panel70 = New System.Windows.Forms.Panel()
        Me.Panel71 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Panel72 = New System.Windows.Forms.Panel()
        Me.Panel73 = New System.Windows.Forms.Panel()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Panel74 = New System.Windows.Forms.Panel()
        Me.Panel75 = New System.Windows.Forms.Panel()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Panel76 = New System.Windows.Forms.Panel()
        Me.Panel77 = New System.Windows.Forms.Panel()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Panel78 = New System.Windows.Forms.Panel()
        Me.Panel79 = New System.Windows.Forms.Panel()
        Me.Panel80 = New System.Windows.Forms.Panel()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.panelTransaksi = New System.Windows.Forms.Panel()
        Me.panelDatabaseTransaksi = New System.Windows.Forms.Panel()
        Me.TLPNoData = New System.Windows.Forms.TableLayoutPanel()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.dgvTransaksiObat = New System.Windows.Forms.DataGridView()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.btnBelumBayar = New System.Windows.Forms.Button()
        Me.btnSemuaTransaksi = New System.Windows.Forms.Button()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.panelKeteranganTransaksi = New System.Windows.Forms.Panel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.VScrollBar2 = New System.Windows.Forms.VScrollBar()
        Me.panelDaftarObat = New System.Windows.Forms.Panel()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.dgvDaftarObat = New System.Windows.Forms.DataGridView()
        Me.panelFormulirObat = New System.Windows.Forms.Panel()
        Me.Panel85 = New System.Windows.Forms.Panel()
        Me.Panel98 = New System.Windows.Forms.Panel()
        Me.Panel99 = New System.Windows.Forms.Panel()
        Me.txtHargaObat = New System.Windows.Forms.TextBox()
        Me.Panel100 = New System.Windows.Forms.Panel()
        Me.Panel101 = New System.Windows.Forms.Panel()
        Me.txtJumlahObat = New System.Windows.Forms.TextBox()
        Me.Panel88 = New System.Windows.Forms.Panel()
        Me.Panel89 = New System.Windows.Forms.Panel()
        Me.txtNamaObat = New System.Windows.Forms.TextBox()
        Me.Panel102 = New System.Windows.Forms.Panel()
        Me.Panel103 = New System.Windows.Forms.Panel()
        Me.Panel105 = New System.Windows.Forms.Panel()
        Me.Panel106 = New System.Windows.Forms.Panel()
        Me.Panel107 = New System.Windows.Forms.Panel()
        Me.Panel108 = New System.Windows.Forms.Panel()
        Me.Panel109 = New System.Windows.Forms.Panel()
        Me.btnBatal = New System.Windows.Forms.Button()
        Me.Panel111 = New System.Windows.Forms.Panel()
        Me.Panel112 = New System.Windows.Forms.Panel()
        Me.Panel113 = New System.Windows.Forms.Panel()
        Me.Panel114 = New System.Windows.Forms.Panel()
        Me.Panel115 = New System.Windows.Forms.Panel()
        Me.btnSimpan = New System.Windows.Forms.Button()
        Me.Panel117 = New System.Windows.Forms.Panel()
        Me.Panel130 = New System.Windows.Forms.Panel()
        Me.Panel131 = New System.Windows.Forms.Panel()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Panel132 = New System.Windows.Forms.Panel()
        Me.Panel133 = New System.Windows.Forms.Panel()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Panel120 = New System.Windows.Forms.Panel()
        Me.Panel121 = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Panel134 = New System.Windows.Forms.Panel()
        Me.Panel135 = New System.Windows.Forms.Panel()
        Me.Panel136 = New System.Windows.Forms.Panel()
        Me.Panel137 = New System.Windows.Forms.Panel()
        Me.btnTambah = New System.Windows.Forms.Button()
        Me.Panel138 = New System.Windows.Forms.Panel()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.Panel139 = New System.Windows.Forms.Panel()
        Me.btnHapus = New System.Windows.Forms.Button()
        Me.Panel140 = New System.Windows.Forms.Panel()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.Panel141 = New System.Windows.Forms.Panel()
        Me.Panel142 = New System.Windows.Forms.Panel()
        Me.Panel143 = New System.Windows.Forms.Panel()
        Me.Panel144 = New System.Windows.Forms.Panel()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.txtCariNamaObat = New System.Windows.Forms.TextBox()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.btnCariObat = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.VScrollBar6 = New System.Windows.Forms.VScrollBar()
        Me.panelDashboard = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.VScrollBar3 = New System.Windows.Forms.VScrollBar()
        Me.panelLaporan = New System.Windows.Forms.Panel()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.VScrollBar4 = New System.Windows.Forms.VScrollBar()
        Me.panelAkun = New System.Windows.Forms.Panel()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.VScrollBar5 = New System.Windows.Forms.VScrollBar()
        Me.jadwal = New System.Windows.Forms.Timer(Me.components)
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.ItemKeranjang2 = New Proyek_Akhir.ItemKeranjang()
        Me.appBar.SuspendLayout()
        CType(Me.showMenuItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.listMenuItem.SuspendLayout()
        CType(Me.pictureObat, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureKeluar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureAkun, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureLaporan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureTransaksi, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picturePasien, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureDashboard, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelGrup.SuspendLayout()
        Me.panelDaftarPasien.SuspendLayout()
        Me.panelTindakanDP.SuspendLayout()
        Me.Panel164.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel25.SuspendLayout()
        Me.Panel28.SuspendLayout()
        Me.Panel29.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel32.SuspendLayout()
        Me.Panel35.SuspendLayout()
        Me.Panel26.SuspendLayout()
        Me.Panel27.SuspendLayout()
        Me.panelPengajuanObat.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.DaftarKeranjang.SuspendLayout()
        Me.Panel34.SuspendLayout()
        Me.Panel37.SuspendLayout()
        Me.Panel38.SuspendLayout()
        Me.Panel39.SuspendLayout()
        Me.Panel41.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.Panel43.SuspendLayout()
        Me.Panel44.SuspendLayout()
        Me.Panel84.SuspendLayout()
        Me.Panel167.SuspendLayout()
        Me.Panel173.SuspendLayout()
        Me.Panel175.SuspendLayout()
        Me.Panel177.SuspendLayout()
        Me.Panel179.SuspendLayout()
        Me.Panel181.SuspendLayout()
        Me.Panel183.SuspendLayout()
        Me.Panel87.SuspendLayout()
        Me.Panel185.SuspendLayout()
        Me.Panel191.SuspendLayout()
        Me.Panel193.SuspendLayout()
        Me.Panel195.SuspendLayout()
        Me.Panel197.SuspendLayout()
        Me.Panel199.SuspendLayout()
        Me.Panel201.SuspendLayout()
        Me.Panel118.SuspendLayout()
        Me.Panel240.SuspendLayout()
        Me.Panel165.SuspendLayout()
        Me.panelBerandaDP.SuspendLayout()
        Me.panelDatabaseDP.SuspendLayout()
        CType(Me.dgvDaftarPasien, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelTab.SuspendLayout()
        Me.panelTengah.SuspendLayout()
        Me.Panel145.SuspendLayout()
        Me.Panel146.SuspendLayout()
        Me.panelKeteranganDP.SuspendLayout()
        Me.panelRiwayatDP.SuspendLayout()
        Me.TableLayoutPanel5.SuspendLayout()
        CType(Me.dgvRiwayatPasien, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel46.SuspendLayout()
        Me.Panel47.SuspendLayout()
        Me.Panel49.SuspendLayout()
        Me.Panel51.SuspendLayout()
        Me.Panel53.SuspendLayout()
        Me.Panel55.SuspendLayout()
        Me.Panel57.SuspendLayout()
        Me.Panel59.SuspendLayout()
        Me.Panel61.SuspendLayout()
        Me.Panel63.SuspendLayout()
        Me.Panel65.SuspendLayout()
        Me.Panel67.SuspendLayout()
        Me.Panel69.SuspendLayout()
        Me.Panel71.SuspendLayout()
        Me.Panel73.SuspendLayout()
        Me.Panel75.SuspendLayout()
        Me.Panel77.SuspendLayout()
        Me.Panel79.SuspendLayout()
        Me.Panel80.SuspendLayout()
        Me.panelTransaksi.SuspendLayout()
        Me.panelDatabaseTransaksi.SuspendLayout()
        Me.TLPNoData.SuspendLayout()
        CType(Me.dgvTransaksiObat, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.panelKeteranganTransaksi.SuspendLayout()
        Me.panelDaftarObat.SuspendLayout()
        Me.Panel14.SuspendLayout()
        CType(Me.dgvDaftarObat, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFormulirObat.SuspendLayout()
        Me.Panel85.SuspendLayout()
        Me.Panel99.SuspendLayout()
        Me.Panel101.SuspendLayout()
        Me.Panel89.SuspendLayout()
        Me.Panel103.SuspendLayout()
        Me.Panel105.SuspendLayout()
        Me.Panel111.SuspendLayout()
        Me.Panel117.SuspendLayout()
        Me.Panel131.SuspendLayout()
        Me.Panel133.SuspendLayout()
        Me.Panel121.SuspendLayout()
        Me.Panel136.SuspendLayout()
        Me.Panel137.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.Panel22.SuspendLayout()
        Me.panelDashboard.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.panelLaporan.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.panelAkun.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'appBar
        '
        Me.appBar.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.appBar.Controls.Add(Me.txtJadwal)
        Me.appBar.Controls.Add(Me.Label8)
        Me.appBar.Controls.Add(Me.showMenuItem)
        Me.appBar.Controls.Add(Me.PictureBox3)
        Me.appBar.Dock = System.Windows.Forms.DockStyle.Top
        Me.appBar.Location = New System.Drawing.Point(0, 0)
        Me.appBar.Name = "appBar"
        Me.appBar.Size = New System.Drawing.Size(1318, 48)
        Me.appBar.TabIndex = 0
        '
        'txtJadwal
        '
        Me.txtJadwal.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtJadwal.AutoSize = True
        Me.txtJadwal.Location = New System.Drawing.Point(1157, 15)
        Me.txtJadwal.Name = "txtJadwal"
        Me.txtJadwal.Size = New System.Drawing.Size(108, 17)
        Me.txtJadwal.TabIndex = 5
        Me.txtJadwal.Text = "Tanggal, Waktu"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(65, 8)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(137, 32)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Apoteker"
        '
        'showMenuItem
        '
        Me.showMenuItem.BackgroundImage = CType(resources.GetObject("showMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.showMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.showMenuItem.Location = New System.Drawing.Point(12, 6)
        Me.showMenuItem.Name = "showMenuItem"
        Me.showMenuItem.Size = New System.Drawing.Size(38, 33)
        Me.showMenuItem.TabIndex = 0
        Me.showMenuItem.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox3.Location = New System.Drawing.Point(12, 6)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(38, 33)
        Me.PictureBox3.TabIndex = 0
        Me.PictureBox3.TabStop = False
        '
        'listMenuItem
        '
        Me.listMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.listMenuItem.Controls.Add(Me.pictureObat)
        Me.listMenuItem.Controls.Add(Me.pictureKeluar)
        Me.listMenuItem.Controls.Add(Me.Label4)
        Me.listMenuItem.Controls.Add(Me.pictureAkun)
        Me.listMenuItem.Controls.Add(Me.Label3)
        Me.listMenuItem.Controls.Add(Me.pictureLaporan)
        Me.listMenuItem.Controls.Add(Me.Label5)
        Me.listMenuItem.Controls.Add(Me.pictureTransaksi)
        Me.listMenuItem.Controls.Add(Me.Label7)
        Me.listMenuItem.Controls.Add(Me.picturePasien)
        Me.listMenuItem.Controls.Add(Me.Label6)
        Me.listMenuItem.Controls.Add(Me.pictureDashboard)
        Me.listMenuItem.Controls.Add(Me.Label2)
        Me.listMenuItem.Controls.Add(Me.buttonKeluar)
        Me.listMenuItem.Controls.Add(Me.Label1)
        Me.listMenuItem.Controls.Add(Me.buttonAkun)
        Me.listMenuItem.Controls.Add(Me.buttonLaporan)
        Me.listMenuItem.Controls.Add(Me.buttonTransaksi)
        Me.listMenuItem.Controls.Add(Me.buttonDaftar_Obat)
        Me.listMenuItem.Controls.Add(Me.buttonDaftar_Pasien)
        Me.listMenuItem.Controls.Add(Me.buttonDashboard)
        Me.listMenuItem.Dock = System.Windows.Forms.DockStyle.Left
        Me.listMenuItem.Location = New System.Drawing.Point(0, 48)
        Me.listMenuItem.Name = "listMenuItem"
        Me.listMenuItem.Size = New System.Drawing.Size(231, 614)
        Me.listMenuItem.TabIndex = 1
        '
        'pictureObat
        '
        Me.pictureObat.BackgroundImage = CType(resources.GetObject("pictureObat.BackgroundImage"), System.Drawing.Image)
        Me.pictureObat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureObat.Location = New System.Drawing.Point(13, 143)
        Me.pictureObat.Name = "pictureObat"
        Me.pictureObat.Size = New System.Drawing.Size(50, 50)
        Me.pictureObat.TabIndex = 0
        Me.pictureObat.TabStop = False
        '
        'pictureKeluar
        '
        Me.pictureKeluar.BackgroundImage = CType(resources.GetObject("pictureKeluar.BackgroundImage"), System.Drawing.Image)
        Me.pictureKeluar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureKeluar.Location = New System.Drawing.Point(13, 410)
        Me.pictureKeluar.Name = "pictureKeluar"
        Me.pictureKeluar.Size = New System.Drawing.Size(50, 50)
        Me.pictureKeluar.TabIndex = 4
        Me.pictureKeluar.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(66, 154)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(134, 29)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Daftar Obat"
        '
        'pictureAkun
        '
        Me.pictureAkun.BackgroundImage = CType(resources.GetObject("pictureAkun.BackgroundImage"), System.Drawing.Image)
        Me.pictureAkun.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureAkun.Location = New System.Drawing.Point(13, 343)
        Me.pictureAkun.Name = "pictureAkun"
        Me.pictureAkun.Size = New System.Drawing.Size(50, 50)
        Me.pictureAkun.TabIndex = 5
        Me.pictureAkun.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(66, 424)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 29)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "Keluar"
        '
        'pictureLaporan
        '
        Me.pictureLaporan.BackgroundImage = CType(resources.GetObject("pictureLaporan.BackgroundImage"), System.Drawing.Image)
        Me.pictureLaporan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureLaporan.Location = New System.Drawing.Point(13, 276)
        Me.pictureLaporan.Name = "pictureLaporan"
        Me.pictureLaporan.Size = New System.Drawing.Size(50, 50)
        Me.pictureLaporan.TabIndex = 6
        Me.pictureLaporan.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(66, 353)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 29)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Akun"
        '
        'pictureTransaksi
        '
        Me.pictureTransaksi.BackgroundImage = CType(resources.GetObject("pictureTransaksi.BackgroundImage"), System.Drawing.Image)
        Me.pictureTransaksi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureTransaksi.Location = New System.Drawing.Point(13, 209)
        Me.pictureTransaksi.Name = "pictureTransaksi"
        Me.pictureTransaksi.Size = New System.Drawing.Size(50, 50)
        Me.pictureTransaksi.TabIndex = 7
        Me.pictureTransaksi.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(66, 287)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(101, 29)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Laporan"
        '
        'picturePasien
        '
        Me.picturePasien.BackgroundImage = CType(resources.GetObject("picturePasien.BackgroundImage"), System.Drawing.Image)
        Me.picturePasien.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picturePasien.Location = New System.Drawing.Point(13, 78)
        Me.picturePasien.Name = "picturePasien"
        Me.picturePasien.Size = New System.Drawing.Size(50, 50)
        Me.picturePasien.TabIndex = 9
        Me.picturePasien.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(66, 219)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(118, 29)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Transaksi"
        '
        'pictureDashboard
        '
        Me.pictureDashboard.BackgroundImage = CType(resources.GetObject("pictureDashboard.BackgroundImage"), System.Drawing.Image)
        Me.pictureDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureDashboard.Location = New System.Drawing.Point(13, 10)
        Me.pictureDashboard.Name = "pictureDashboard"
        Me.pictureDashboard.Size = New System.Drawing.Size(50, 50)
        Me.pictureDashboard.TabIndex = 8
        Me.pictureDashboard.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(66, 90)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(156, 29)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Daftar Pasien"
        '
        'buttonKeluar
        '
        Me.buttonKeluar.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonKeluar.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonKeluar.Location = New System.Drawing.Point(0, 402)
        Me.buttonKeluar.Name = "buttonKeluar"
        Me.buttonKeluar.Size = New System.Drawing.Size(231, 67)
        Me.buttonKeluar.TabIndex = 16
        Me.buttonKeluar.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(66, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(131, 29)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Dashboard"
        '
        'buttonAkun
        '
        Me.buttonAkun.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonAkun.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonAkun.Location = New System.Drawing.Point(0, 335)
        Me.buttonAkun.Name = "buttonAkun"
        Me.buttonAkun.Size = New System.Drawing.Size(231, 67)
        Me.buttonAkun.TabIndex = 17
        Me.buttonAkun.UseVisualStyleBackColor = False
        '
        'buttonLaporan
        '
        Me.buttonLaporan.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonLaporan.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonLaporan.Location = New System.Drawing.Point(0, 268)
        Me.buttonLaporan.Name = "buttonLaporan"
        Me.buttonLaporan.Size = New System.Drawing.Size(231, 67)
        Me.buttonLaporan.TabIndex = 18
        Me.buttonLaporan.UseVisualStyleBackColor = False
        '
        'buttonTransaksi
        '
        Me.buttonTransaksi.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonTransaksi.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonTransaksi.Location = New System.Drawing.Point(0, 201)
        Me.buttonTransaksi.Name = "buttonTransaksi"
        Me.buttonTransaksi.Size = New System.Drawing.Size(231, 67)
        Me.buttonTransaksi.TabIndex = 19
        Me.buttonTransaksi.UseVisualStyleBackColor = False
        '
        'buttonDaftar_Obat
        '
        Me.buttonDaftar_Obat.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonDaftar_Obat.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonDaftar_Obat.Location = New System.Drawing.Point(0, 134)
        Me.buttonDaftar_Obat.Name = "buttonDaftar_Obat"
        Me.buttonDaftar_Obat.Size = New System.Drawing.Size(231, 67)
        Me.buttonDaftar_Obat.TabIndex = 22
        Me.buttonDaftar_Obat.UseVisualStyleBackColor = False
        '
        'buttonDaftar_Pasien
        '
        Me.buttonDaftar_Pasien.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonDaftar_Pasien.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonDaftar_Pasien.Location = New System.Drawing.Point(0, 67)
        Me.buttonDaftar_Pasien.Name = "buttonDaftar_Pasien"
        Me.buttonDaftar_Pasien.Size = New System.Drawing.Size(231, 67)
        Me.buttonDaftar_Pasien.TabIndex = 20
        Me.buttonDaftar_Pasien.UseVisualStyleBackColor = False
        '
        'buttonDashboard
        '
        Me.buttonDashboard.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonDashboard.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonDashboard.Location = New System.Drawing.Point(0, 0)
        Me.buttonDashboard.Name = "buttonDashboard"
        Me.buttonDashboard.Size = New System.Drawing.Size(231, 67)
        Me.buttonDashboard.TabIndex = 21
        Me.buttonDashboard.UseVisualStyleBackColor = False
        '
        'panelGrup
        '
        Me.panelGrup.Controls.Add(Me.panelDaftarPasien)
        Me.panelGrup.Controls.Add(Me.panelTransaksi)
        Me.panelGrup.Controls.Add(Me.panelDaftarObat)
        Me.panelGrup.Controls.Add(Me.panelDashboard)
        Me.panelGrup.Controls.Add(Me.panelLaporan)
        Me.panelGrup.Controls.Add(Me.panelAkun)
        Me.panelGrup.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelGrup.Location = New System.Drawing.Point(231, 48)
        Me.panelGrup.Name = "panelGrup"
        Me.panelGrup.Size = New System.Drawing.Size(1087, 614)
        Me.panelGrup.TabIndex = 2
        '
        'panelDaftarPasien
        '
        Me.panelDaftarPasien.Controls.Add(Me.panelTindakanDP)
        Me.panelDaftarPasien.Controls.Add(Me.panelBerandaDP)
        Me.panelDaftarPasien.Controls.Add(Me.panelRiwayatDP)
        Me.panelDaftarPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDaftarPasien.Location = New System.Drawing.Point(0, 0)
        Me.panelDaftarPasien.Name = "panelDaftarPasien"
        Me.panelDaftarPasien.Size = New System.Drawing.Size(1087, 614)
        Me.panelDaftarPasien.TabIndex = 3
        '
        'panelTindakanDP
        '
        Me.panelTindakanDP.Controls.Add(Me.Panel164)
        Me.panelTindakanDP.Controls.Add(Me.Panel25)
        Me.panelTindakanDP.Controls.Add(Me.Panel26)
        Me.panelTindakanDP.Controls.Add(Me.Panel38)
        Me.panelTindakanDP.Controls.Add(Me.Panel84)
        Me.panelTindakanDP.Controls.Add(Me.Panel240)
        Me.panelTindakanDP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelTindakanDP.Location = New System.Drawing.Point(0, 0)
        Me.panelTindakanDP.Name = "panelTindakanDP"
        Me.panelTindakanDP.Size = New System.Drawing.Size(1087, 614)
        Me.panelTindakanDP.TabIndex = 7
        '
        'Panel164
        '
        Me.Panel164.Controls.Add(Me.TableLayoutPanel2)
        Me.Panel164.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel164.Location = New System.Drawing.Point(0, 585)
        Me.Panel164.Name = "Panel164"
        Me.Panel164.Size = New System.Drawing.Size(1087, 41)
        Me.Panel164.TabIndex = 4
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 5
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.btn_IP_PengambilanObat, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.btn_IP_Batal, 3, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(1087, 41)
        Me.TableLayoutPanel2.TabIndex = 1
        '
        'btn_IP_PengambilanObat
        '
        Me.btn_IP_PengambilanObat.Location = New System.Drawing.Point(344, 3)
        Me.btn_IP_PengambilanObat.Name = "btn_IP_PengambilanObat"
        Me.btn_IP_PengambilanObat.Size = New System.Drawing.Size(194, 35)
        Me.btn_IP_PengambilanObat.TabIndex = 0
        Me.btn_IP_PengambilanObat.Text = "Pengambilan Obat"
        Me.btn_IP_PengambilanObat.UseVisualStyleBackColor = True
        '
        'btn_IP_Batal
        '
        Me.btn_IP_Batal.Location = New System.Drawing.Point(549, 3)
        Me.btn_IP_Batal.Name = "btn_IP_Batal"
        Me.btn_IP_Batal.Size = New System.Drawing.Size(194, 35)
        Me.btn_IP_Batal.TabIndex = 0
        Me.btn_IP_Batal.Text = "Batal"
        Me.btn_IP_Batal.UseVisualStyleBackColor = True
        '
        'Panel25
        '
        Me.Panel25.Controls.Add(Me.Panel28)
        Me.Panel25.Controls.Add(Me.Panel32)
        Me.Panel25.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel25.Location = New System.Drawing.Point(0, 527)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(1087, 58)
        Me.Panel25.TabIndex = 6
        '
        'Panel28
        '
        Me.Panel28.Controls.Add(Me.Panel29)
        Me.Panel28.Controls.Add(Me.Panel31)
        Me.Panel28.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel28.Location = New System.Drawing.Point(175, 0)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(912, 58)
        Me.Panel28.TabIndex = 0
        '
        'Panel29
        '
        Me.Panel29.Controls.Add(Me.TableLayoutPanel1)
        Me.Panel29.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel29.Location = New System.Drawing.Point(0, 15)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(912, 43)
        Me.Panel29.TabIndex = 4
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.txt_IP_Obat, 1, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(912, 43)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'txt_IP_Obat
        '
        Me.txt_IP_Obat.AutoSize = True
        Me.txt_IP_Obat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_IP_Obat.Location = New System.Drawing.Point(13, 10)
        Me.txt_IP_Obat.Name = "txt_IP_Obat"
        Me.txt_IP_Obat.Size = New System.Drawing.Size(886, 23)
        Me.txt_IP_Obat.TabIndex = 3
        Me.txt_IP_Obat.Text = "Harga Obat"
        '
        'Panel31
        '
        Me.Panel31.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel31.Location = New System.Drawing.Point(0, 0)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(912, 15)
        Me.Panel31.TabIndex = 2
        '
        'Panel32
        '
        Me.Panel32.Controls.Add(Me.Panel35)
        Me.Panel32.Controls.Add(Me.Panel36)
        Me.Panel32.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel32.Location = New System.Drawing.Point(0, 0)
        Me.Panel32.Name = "Panel32"
        Me.Panel32.Size = New System.Drawing.Size(175, 58)
        Me.Panel32.TabIndex = 0
        '
        'Panel35
        '
        Me.Panel35.Controls.Add(Me.Label14)
        Me.Panel35.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel35.Location = New System.Drawing.Point(0, 15)
        Me.Panel35.Name = "Panel35"
        Me.Panel35.Size = New System.Drawing.Size(175, 43)
        Me.Panel35.TabIndex = 3
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(0, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(82, 17)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Harga Obat"
        '
        'Panel36
        '
        Me.Panel36.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel36.Location = New System.Drawing.Point(0, 0)
        Me.Panel36.Name = "Panel36"
        Me.Panel36.Size = New System.Drawing.Size(175, 15)
        Me.Panel36.TabIndex = 0
        '
        'Panel26
        '
        Me.Panel26.Controls.Add(Me.Panel27)
        Me.Panel26.Controls.Add(Me.Panel34)
        Me.Panel26.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel26.Location = New System.Drawing.Point(0, 387)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(1087, 140)
        Me.Panel26.TabIndex = 5
        '
        'Panel27
        '
        Me.Panel27.Controls.Add(Me.panelPengajuanObat)
        Me.Panel27.Controls.Add(Me.Panel33)
        Me.Panel27.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel27.Location = New System.Drawing.Point(175, 0)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(912, 140)
        Me.Panel27.TabIndex = 0
        '
        'panelPengajuanObat
        '
        Me.panelPengajuanObat.Controls.Add(Me.TableLayoutPanel3)
        Me.panelPengajuanObat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelPengajuanObat.Location = New System.Drawing.Point(0, 15)
        Me.panelPengajuanObat.Name = "panelPengajuanObat"
        Me.panelPengajuanObat.Size = New System.Drawing.Size(912, 125)
        Me.panelPengajuanObat.TabIndex = 4
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.AutoScroll = True
        Me.TableLayoutPanel3.ColumnCount = 3
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.DaftarKeranjang, 1, 1)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 3
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(912, 125)
        Me.TableLayoutPanel3.TabIndex = 0
        '
        'DaftarKeranjang
        '
        Me.DaftarKeranjang.Controls.Add(Me.ItemKeranjang1)
        Me.DaftarKeranjang.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DaftarKeranjang.Location = New System.Drawing.Point(13, 13)
        Me.DaftarKeranjang.Name = "DaftarKeranjang"
        Me.DaftarKeranjang.Size = New System.Drawing.Size(886, 99)
        Me.DaftarKeranjang.TabIndex = 0
        '
        'ItemKeranjang1
        '
        Me.ItemKeranjang1.Dock = System.Windows.Forms.DockStyle.Top
        Me.ItemKeranjang1.ItemCount = 0
        Me.ItemKeranjang1.Location = New System.Drawing.Point(3, 3)
        Me.ItemKeranjang1.Name = "ItemKeranjang1"
        Me.ItemKeranjang1.Size = New System.Drawing.Size(789, 32)
        Me.ItemKeranjang1.TabIndex = 0
        Me.ItemKeranjang1.Title = Nothing
        '
        'Panel33
        '
        Me.Panel33.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel33.Location = New System.Drawing.Point(0, 0)
        Me.Panel33.Name = "Panel33"
        Me.Panel33.Size = New System.Drawing.Size(912, 15)
        Me.Panel33.TabIndex = 2
        '
        'Panel34
        '
        Me.Panel34.Controls.Add(Me.Panel37)
        Me.Panel34.Controls.Add(Me.Panel40)
        Me.Panel34.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel34.Location = New System.Drawing.Point(0, 0)
        Me.Panel34.Name = "Panel34"
        Me.Panel34.Size = New System.Drawing.Size(175, 140)
        Me.Panel34.TabIndex = 0
        '
        'Panel37
        '
        Me.Panel37.Controls.Add(Me.Label15)
        Me.Panel37.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel37.Location = New System.Drawing.Point(0, 15)
        Me.Panel37.Name = "Panel37"
        Me.Panel37.Size = New System.Drawing.Size(175, 125)
        Me.Panel37.TabIndex = 3
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(0, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(92, 17)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Terapi / Obat"
        '
        'Panel40
        '
        Me.Panel40.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel40.Location = New System.Drawing.Point(0, 0)
        Me.Panel40.Name = "Panel40"
        Me.Panel40.Size = New System.Drawing.Size(175, 15)
        Me.Panel40.TabIndex = 0
        '
        'Panel38
        '
        Me.Panel38.Controls.Add(Me.Panel39)
        Me.Panel38.Controls.Add(Me.Panel43)
        Me.Panel38.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel38.Location = New System.Drawing.Point(0, 329)
        Me.Panel38.Name = "Panel38"
        Me.Panel38.Size = New System.Drawing.Size(1087, 58)
        Me.Panel38.TabIndex = 7
        '
        'Panel39
        '
        Me.Panel39.Controls.Add(Me.Panel41)
        Me.Panel39.Controls.Add(Me.Panel42)
        Me.Panel39.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel39.Location = New System.Drawing.Point(175, 0)
        Me.Panel39.Name = "Panel39"
        Me.Panel39.Size = New System.Drawing.Size(912, 58)
        Me.Panel39.TabIndex = 0
        '
        'Panel41
        '
        Me.Panel41.Controls.Add(Me.TableLayoutPanel4)
        Me.Panel41.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel41.Location = New System.Drawing.Point(0, 15)
        Me.Panel41.Name = "Panel41"
        Me.Panel41.Size = New System.Drawing.Size(912, 43)
        Me.Panel41.TabIndex = 4
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 3
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.Label16, 1, 1)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 3
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(912, 43)
        Me.TableLayoutPanel4.TabIndex = 0
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label16.Location = New System.Drawing.Point(13, 10)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(886, 23)
        Me.Label16.TabIndex = 3
        Me.Label16.Text = "Resep Dokter"
        '
        'Panel42
        '
        Me.Panel42.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel42.Location = New System.Drawing.Point(0, 0)
        Me.Panel42.Name = "Panel42"
        Me.Panel42.Size = New System.Drawing.Size(912, 15)
        Me.Panel42.TabIndex = 2
        '
        'Panel43
        '
        Me.Panel43.Controls.Add(Me.Panel44)
        Me.Panel43.Controls.Add(Me.Panel45)
        Me.Panel43.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel43.Location = New System.Drawing.Point(0, 0)
        Me.Panel43.Name = "Panel43"
        Me.Panel43.Size = New System.Drawing.Size(175, 58)
        Me.Panel43.TabIndex = 0
        '
        'Panel44
        '
        Me.Panel44.Controls.Add(Me.Label17)
        Me.Panel44.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel44.Location = New System.Drawing.Point(0, 15)
        Me.Panel44.Name = "Panel44"
        Me.Panel44.Size = New System.Drawing.Size(175, 43)
        Me.Panel44.TabIndex = 3
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(0, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(95, 17)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "Resep Dokter"
        '
        'Panel45
        '
        Me.Panel45.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel45.Location = New System.Drawing.Point(0, 0)
        Me.Panel45.Name = "Panel45"
        Me.Panel45.Size = New System.Drawing.Size(175, 15)
        Me.Panel45.TabIndex = 0
        '
        'Panel84
        '
        Me.Panel84.Controls.Add(Me.Panel167)
        Me.Panel84.Controls.Add(Me.Panel185)
        Me.Panel84.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel84.Location = New System.Drawing.Point(0, 66)
        Me.Panel84.Name = "Panel84"
        Me.Panel84.Size = New System.Drawing.Size(1087, 263)
        Me.Panel84.TabIndex = 4
        '
        'Panel167
        '
        Me.Panel167.Controls.Add(Me.Panel170)
        Me.Panel167.Controls.Add(Me.Panel173)
        Me.Panel167.Controls.Add(Me.Panel174)
        Me.Panel167.Controls.Add(Me.Panel175)
        Me.Panel167.Controls.Add(Me.Panel176)
        Me.Panel167.Controls.Add(Me.Panel177)
        Me.Panel167.Controls.Add(Me.Panel178)
        Me.Panel167.Controls.Add(Me.Panel179)
        Me.Panel167.Controls.Add(Me.Panel180)
        Me.Panel167.Controls.Add(Me.Panel181)
        Me.Panel167.Controls.Add(Me.Panel182)
        Me.Panel167.Controls.Add(Me.Panel183)
        Me.Panel167.Controls.Add(Me.Panel86)
        Me.Panel167.Controls.Add(Me.Panel87)
        Me.Panel167.Controls.Add(Me.Panel184)
        Me.Panel167.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel167.Location = New System.Drawing.Point(175, 0)
        Me.Panel167.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel167.Name = "Panel167"
        Me.Panel167.Size = New System.Drawing.Size(912, 263)
        Me.Panel167.TabIndex = 1
        '
        'Panel170
        '
        Me.Panel170.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel170.Location = New System.Drawing.Point(0, 252)
        Me.Panel170.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel170.Name = "Panel170"
        Me.Panel170.Size = New System.Drawing.Size(912, 11)
        Me.Panel170.TabIndex = 30
        '
        'Panel173
        '
        Me.Panel173.Controls.Add(Me.txt_IP_Faskes)
        Me.Panel173.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel173.Location = New System.Drawing.Point(0, 227)
        Me.Panel173.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel173.Name = "Panel173"
        Me.Panel173.Size = New System.Drawing.Size(912, 25)
        Me.Panel173.TabIndex = 27
        '
        'txt_IP_Faskes
        '
        Me.txt_IP_Faskes.AutoSize = True
        Me.txt_IP_Faskes.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_Faskes.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_Faskes.Name = "txt_IP_Faskes"
        Me.txt_IP_Faskes.Size = New System.Drawing.Size(53, 17)
        Me.txt_IP_Faskes.TabIndex = 1
        Me.txt_IP_Faskes.Text = "Faskes"
        '
        'Panel174
        '
        Me.Panel174.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel174.Location = New System.Drawing.Point(0, 216)
        Me.Panel174.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel174.Name = "Panel174"
        Me.Panel174.Size = New System.Drawing.Size(912, 11)
        Me.Panel174.TabIndex = 25
        '
        'Panel175
        '
        Me.Panel175.Controls.Add(Me.txt_IP_Alamat)
        Me.Panel175.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel175.Location = New System.Drawing.Point(0, 191)
        Me.Panel175.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel175.Name = "Panel175"
        Me.Panel175.Size = New System.Drawing.Size(912, 25)
        Me.Panel175.TabIndex = 24
        '
        'txt_IP_Alamat
        '
        Me.txt_IP_Alamat.AutoSize = True
        Me.txt_IP_Alamat.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_Alamat.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_Alamat.Name = "txt_IP_Alamat"
        Me.txt_IP_Alamat.Size = New System.Drawing.Size(51, 17)
        Me.txt_IP_Alamat.TabIndex = 1
        Me.txt_IP_Alamat.Text = "Alamat"
        '
        'Panel176
        '
        Me.Panel176.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel176.Location = New System.Drawing.Point(0, 180)
        Me.Panel176.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel176.Name = "Panel176"
        Me.Panel176.Size = New System.Drawing.Size(912, 11)
        Me.Panel176.TabIndex = 23
        '
        'Panel177
        '
        Me.Panel177.Controls.Add(Me.txt_IP_JenisKelamin)
        Me.Panel177.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel177.Location = New System.Drawing.Point(0, 155)
        Me.Panel177.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel177.Name = "Panel177"
        Me.Panel177.Size = New System.Drawing.Size(912, 25)
        Me.Panel177.TabIndex = 22
        '
        'txt_IP_JenisKelamin
        '
        Me.txt_IP_JenisKelamin.AutoSize = True
        Me.txt_IP_JenisKelamin.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_JenisKelamin.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_JenisKelamin.Name = "txt_IP_JenisKelamin"
        Me.txt_IP_JenisKelamin.Size = New System.Drawing.Size(95, 17)
        Me.txt_IP_JenisKelamin.TabIndex = 1
        Me.txt_IP_JenisKelamin.Text = "Jenis Kelamin"
        '
        'Panel178
        '
        Me.Panel178.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel178.Location = New System.Drawing.Point(0, 144)
        Me.Panel178.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel178.Name = "Panel178"
        Me.Panel178.Size = New System.Drawing.Size(912, 11)
        Me.Panel178.TabIndex = 21
        '
        'Panel179
        '
        Me.Panel179.Controls.Add(Me.txt_IP_Umur)
        Me.Panel179.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel179.Location = New System.Drawing.Point(0, 119)
        Me.Panel179.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel179.Name = "Panel179"
        Me.Panel179.Size = New System.Drawing.Size(912, 25)
        Me.Panel179.TabIndex = 20
        '
        'txt_IP_Umur
        '
        Me.txt_IP_Umur.AutoSize = True
        Me.txt_IP_Umur.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_Umur.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_Umur.Name = "txt_IP_Umur"
        Me.txt_IP_Umur.Size = New System.Drawing.Size(42, 17)
        Me.txt_IP_Umur.TabIndex = 1
        Me.txt_IP_Umur.Text = "Umur"
        '
        'Panel180
        '
        Me.Panel180.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel180.Location = New System.Drawing.Point(0, 108)
        Me.Panel180.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel180.Name = "Panel180"
        Me.Panel180.Size = New System.Drawing.Size(912, 11)
        Me.Panel180.TabIndex = 19
        '
        'Panel181
        '
        Me.Panel181.Controls.Add(Me.txt_IP_NamaLengkap)
        Me.Panel181.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel181.Location = New System.Drawing.Point(0, 83)
        Me.Panel181.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel181.Name = "Panel181"
        Me.Panel181.Size = New System.Drawing.Size(912, 25)
        Me.Panel181.TabIndex = 18
        '
        'txt_IP_NamaLengkap
        '
        Me.txt_IP_NamaLengkap.AutoSize = True
        Me.txt_IP_NamaLengkap.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_NamaLengkap.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_NamaLengkap.Name = "txt_IP_NamaLengkap"
        Me.txt_IP_NamaLengkap.Size = New System.Drawing.Size(104, 17)
        Me.txt_IP_NamaLengkap.TabIndex = 2
        Me.txt_IP_NamaLengkap.Text = "Nama Lengkap"
        '
        'Panel182
        '
        Me.Panel182.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel182.Location = New System.Drawing.Point(0, 72)
        Me.Panel182.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel182.Name = "Panel182"
        Me.Panel182.Size = New System.Drawing.Size(912, 11)
        Me.Panel182.TabIndex = 17
        '
        'Panel183
        '
        Me.Panel183.Controls.Add(Me.txt_IP_UserName)
        Me.Panel183.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel183.Location = New System.Drawing.Point(0, 47)
        Me.Panel183.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel183.Name = "Panel183"
        Me.Panel183.Size = New System.Drawing.Size(912, 25)
        Me.Panel183.TabIndex = 16
        '
        'txt_IP_UserName
        '
        Me.txt_IP_UserName.AutoSize = True
        Me.txt_IP_UserName.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_UserName.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_UserName.Name = "txt_IP_UserName"
        Me.txt_IP_UserName.Size = New System.Drawing.Size(79, 17)
        Me.txt_IP_UserName.TabIndex = 3
        Me.txt_IP_UserName.Text = "User Name"
        '
        'Panel86
        '
        Me.Panel86.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel86.Location = New System.Drawing.Point(0, 36)
        Me.Panel86.Name = "Panel86"
        Me.Panel86.Size = New System.Drawing.Size(912, 11)
        Me.Panel86.TabIndex = 31
        '
        'Panel87
        '
        Me.Panel87.Controls.Add(Me.txt_IP_NIK)
        Me.Panel87.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel87.Location = New System.Drawing.Point(0, 11)
        Me.Panel87.Name = "Panel87"
        Me.Panel87.Size = New System.Drawing.Size(912, 25)
        Me.Panel87.TabIndex = 31
        '
        'txt_IP_NIK
        '
        Me.txt_IP_NIK.AutoSize = True
        Me.txt_IP_NIK.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_NIK.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_NIK.Name = "txt_IP_NIK"
        Me.txt_IP_NIK.Size = New System.Drawing.Size(30, 17)
        Me.txt_IP_NIK.TabIndex = 0
        Me.txt_IP_NIK.Text = "NIK"
        '
        'Panel184
        '
        Me.Panel184.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel184.Location = New System.Drawing.Point(0, 0)
        Me.Panel184.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel184.Name = "Panel184"
        Me.Panel184.Size = New System.Drawing.Size(912, 11)
        Me.Panel184.TabIndex = 15
        '
        'Panel185
        '
        Me.Panel185.Controls.Add(Me.Panel188)
        Me.Panel185.Controls.Add(Me.Panel191)
        Me.Panel185.Controls.Add(Me.Panel192)
        Me.Panel185.Controls.Add(Me.Panel193)
        Me.Panel185.Controls.Add(Me.Panel194)
        Me.Panel185.Controls.Add(Me.Panel195)
        Me.Panel185.Controls.Add(Me.Panel196)
        Me.Panel185.Controls.Add(Me.Panel197)
        Me.Panel185.Controls.Add(Me.Panel198)
        Me.Panel185.Controls.Add(Me.Panel199)
        Me.Panel185.Controls.Add(Me.Panel200)
        Me.Panel185.Controls.Add(Me.Panel201)
        Me.Panel185.Controls.Add(Me.Panel119)
        Me.Panel185.Controls.Add(Me.Panel118)
        Me.Panel185.Controls.Add(Me.Panel202)
        Me.Panel185.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel185.Location = New System.Drawing.Point(0, 0)
        Me.Panel185.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel185.Name = "Panel185"
        Me.Panel185.Size = New System.Drawing.Size(175, 263)
        Me.Panel185.TabIndex = 1
        '
        'Panel188
        '
        Me.Panel188.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel188.Location = New System.Drawing.Point(0, 252)
        Me.Panel188.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel188.Name = "Panel188"
        Me.Panel188.Size = New System.Drawing.Size(175, 11)
        Me.Panel188.TabIndex = 30
        '
        'Panel191
        '
        Me.Panel191.Controls.Add(Me.Label47)
        Me.Panel191.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel191.Location = New System.Drawing.Point(0, 227)
        Me.Panel191.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel191.Name = "Panel191"
        Me.Panel191.Size = New System.Drawing.Size(175, 25)
        Me.Panel191.TabIndex = 27
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label47.Location = New System.Drawing.Point(0, 0)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(53, 17)
        Me.Label47.TabIndex = 1
        Me.Label47.Text = "Faskes"
        '
        'Panel192
        '
        Me.Panel192.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel192.Location = New System.Drawing.Point(0, 216)
        Me.Panel192.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel192.Name = "Panel192"
        Me.Panel192.Size = New System.Drawing.Size(175, 11)
        Me.Panel192.TabIndex = 25
        '
        'Panel193
        '
        Me.Panel193.Controls.Add(Me.Label48)
        Me.Panel193.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel193.Location = New System.Drawing.Point(0, 191)
        Me.Panel193.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel193.Name = "Panel193"
        Me.Panel193.Size = New System.Drawing.Size(175, 25)
        Me.Panel193.TabIndex = 24
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label48.Location = New System.Drawing.Point(0, 0)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(51, 17)
        Me.Label48.TabIndex = 1
        Me.Label48.Text = "Alamat"
        '
        'Panel194
        '
        Me.Panel194.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel194.Location = New System.Drawing.Point(0, 180)
        Me.Panel194.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel194.Name = "Panel194"
        Me.Panel194.Size = New System.Drawing.Size(175, 11)
        Me.Panel194.TabIndex = 23
        '
        'Panel195
        '
        Me.Panel195.Controls.Add(Me.Label49)
        Me.Panel195.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel195.Location = New System.Drawing.Point(0, 155)
        Me.Panel195.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel195.Name = "Panel195"
        Me.Panel195.Size = New System.Drawing.Size(175, 25)
        Me.Panel195.TabIndex = 22
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label49.Location = New System.Drawing.Point(0, 0)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(95, 17)
        Me.Label49.TabIndex = 1
        Me.Label49.Text = "Jenis Kelamin"
        '
        'Panel196
        '
        Me.Panel196.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel196.Location = New System.Drawing.Point(0, 144)
        Me.Panel196.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel196.Name = "Panel196"
        Me.Panel196.Size = New System.Drawing.Size(175, 11)
        Me.Panel196.TabIndex = 21
        '
        'Panel197
        '
        Me.Panel197.Controls.Add(Me.Label50)
        Me.Panel197.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel197.Location = New System.Drawing.Point(0, 119)
        Me.Panel197.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel197.Name = "Panel197"
        Me.Panel197.Size = New System.Drawing.Size(175, 25)
        Me.Panel197.TabIndex = 20
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label50.Location = New System.Drawing.Point(0, 0)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(42, 17)
        Me.Label50.TabIndex = 1
        Me.Label50.Text = "Umur"
        '
        'Panel198
        '
        Me.Panel198.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel198.Location = New System.Drawing.Point(0, 108)
        Me.Panel198.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel198.Name = "Panel198"
        Me.Panel198.Size = New System.Drawing.Size(175, 11)
        Me.Panel198.TabIndex = 19
        '
        'Panel199
        '
        Me.Panel199.Controls.Add(Me.Label51)
        Me.Panel199.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel199.Location = New System.Drawing.Point(0, 83)
        Me.Panel199.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel199.Name = "Panel199"
        Me.Panel199.Size = New System.Drawing.Size(175, 25)
        Me.Panel199.TabIndex = 18
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label51.Location = New System.Drawing.Point(0, 0)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(104, 17)
        Me.Label51.TabIndex = 2
        Me.Label51.Text = "Nama Lengkap"
        '
        'Panel200
        '
        Me.Panel200.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel200.Location = New System.Drawing.Point(0, 72)
        Me.Panel200.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel200.Name = "Panel200"
        Me.Panel200.Size = New System.Drawing.Size(175, 11)
        Me.Panel200.TabIndex = 17
        '
        'Panel201
        '
        Me.Panel201.Controls.Add(Me.Label52)
        Me.Panel201.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel201.Location = New System.Drawing.Point(0, 47)
        Me.Panel201.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel201.Name = "Panel201"
        Me.Panel201.Size = New System.Drawing.Size(175, 25)
        Me.Panel201.TabIndex = 16
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label52.Location = New System.Drawing.Point(0, 0)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(79, 17)
        Me.Label52.TabIndex = 3
        Me.Label52.Text = "User Name"
        '
        'Panel119
        '
        Me.Panel119.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel119.Location = New System.Drawing.Point(0, 36)
        Me.Panel119.Name = "Panel119"
        Me.Panel119.Size = New System.Drawing.Size(175, 11)
        Me.Panel119.TabIndex = 32
        '
        'Panel118
        '
        Me.Panel118.Controls.Add(Me.Label22)
        Me.Panel118.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel118.Location = New System.Drawing.Point(0, 11)
        Me.Panel118.Name = "Panel118"
        Me.Panel118.Size = New System.Drawing.Size(175, 25)
        Me.Panel118.TabIndex = 31
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label22.Location = New System.Drawing.Point(0, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(30, 17)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "NIK"
        '
        'Panel202
        '
        Me.Panel202.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel202.Location = New System.Drawing.Point(0, 0)
        Me.Panel202.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel202.Name = "Panel202"
        Me.Panel202.Size = New System.Drawing.Size(175, 11)
        Me.Panel202.TabIndex = 15
        '
        'Panel240
        '
        Me.Panel240.Controls.Add(Me.Panel165)
        Me.Panel240.Controls.Add(Me.btn_IP_Kembali)
        Me.Panel240.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel240.Location = New System.Drawing.Point(0, 0)
        Me.Panel240.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel240.Name = "Panel240"
        Me.Panel240.Size = New System.Drawing.Size(1087, 66)
        Me.Panel240.TabIndex = 3
        '
        'Panel165
        '
        Me.Panel165.Controls.Add(Me.Label45)
        Me.Panel165.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel165.Location = New System.Drawing.Point(75, 0)
        Me.Panel165.Name = "Panel165"
        Me.Panel165.Size = New System.Drawing.Size(1012, 66)
        Me.Panel165.TabIndex = 3
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label45.Location = New System.Drawing.Point(16, 18)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(150, 29)
        Me.Label45.TabIndex = 2
        Me.Label45.Text = "Info Pasien"
        '
        'btn_IP_Kembali
        '
        Me.btn_IP_Kembali.BackgroundImage = CType(resources.GetObject("btn_IP_Kembali.BackgroundImage"), System.Drawing.Image)
        Me.btn_IP_Kembali.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btn_IP_Kembali.Dock = System.Windows.Forms.DockStyle.Left
        Me.btn_IP_Kembali.Location = New System.Drawing.Point(0, 0)
        Me.btn_IP_Kembali.Name = "btn_IP_Kembali"
        Me.btn_IP_Kembali.Size = New System.Drawing.Size(75, 66)
        Me.btn_IP_Kembali.TabIndex = 4
        Me.btn_IP_Kembali.UseVisualStyleBackColor = True
        '
        'panelBerandaDP
        '
        Me.panelBerandaDP.Controls.Add(Me.panelDatabaseDP)
        Me.panelBerandaDP.Controls.Add(Me.Panel145)
        Me.panelBerandaDP.Controls.Add(Me.panelKeteranganDP)
        Me.panelBerandaDP.Controls.Add(Me.VScrollBar1)
        Me.panelBerandaDP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelBerandaDP.Location = New System.Drawing.Point(0, 0)
        Me.panelBerandaDP.Name = "panelBerandaDP"
        Me.panelBerandaDP.Size = New System.Drawing.Size(1087, 614)
        Me.panelBerandaDP.TabIndex = 3
        '
        'panelDatabaseDP
        '
        Me.panelDatabaseDP.Controls.Add(Me.dgvDaftarPasien)
        Me.panelDatabaseDP.Controls.Add(Me.panelTab)
        Me.panelDatabaseDP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDatabaseDP.Location = New System.Drawing.Point(0, 129)
        Me.panelDatabaseDP.Name = "panelDatabaseDP"
        Me.panelDatabaseDP.Size = New System.Drawing.Size(1066, 485)
        Me.panelDatabaseDP.TabIndex = 5
        '
        'dgvDaftarPasien
        '
        Me.dgvDaftarPasien.AllowUserToAddRows = False
        Me.dgvDaftarPasien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDaftarPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvDaftarPasien.Location = New System.Drawing.Point(0, 61)
        Me.dgvDaftarPasien.Name = "dgvDaftarPasien"
        Me.dgvDaftarPasien.ReadOnly = True
        Me.dgvDaftarPasien.RowHeadersWidth = 51
        Me.dgvDaftarPasien.RowTemplate.Height = 24
        Me.dgvDaftarPasien.Size = New System.Drawing.Size(1066, 424)
        Me.dgvDaftarPasien.TabIndex = 1
        '
        'panelTab
        '
        Me.panelTab.Controls.Add(Me.panelTengah)
        Me.panelTab.Controls.Add(Me.panelKanan)
        Me.panelTab.Controls.Add(Me.panelKiri)
        Me.panelTab.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelTab.Location = New System.Drawing.Point(0, 0)
        Me.panelTab.Name = "panelTab"
        Me.panelTab.Size = New System.Drawing.Size(1066, 61)
        Me.panelTab.TabIndex = 0
        '
        'panelTengah
        '
        Me.panelTengah.Controls.Add(Me.btnBelumSelesai)
        Me.panelTengah.Controls.Add(Me.btnSemuaPasien)
        Me.panelTengah.Controls.Add(Me.panelAtas)
        Me.panelTengah.Controls.Add(Me.Panel1)
        Me.panelTengah.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelTengah.Location = New System.Drawing.Point(200, 0)
        Me.panelTengah.Name = "panelTengah"
        Me.panelTengah.Size = New System.Drawing.Size(666, 61)
        Me.panelTengah.TabIndex = 2
        '
        'btnBelumSelesai
        '
        Me.btnBelumSelesai.AutoSize = True
        Me.btnBelumSelesai.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnBelumSelesai.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnBelumSelesai.FlatAppearance.BorderSize = 2
        Me.btnBelumSelesai.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBelumSelesai.Location = New System.Drawing.Point(0, 15)
        Me.btnBelumSelesai.Name = "btnBelumSelesai"
        Me.btnBelumSelesai.Size = New System.Drawing.Size(131, 31)
        Me.btnBelumSelesai.TabIndex = 1
        Me.btnBelumSelesai.Text = "Belum Selesai"
        Me.btnBelumSelesai.UseVisualStyleBackColor = True
        '
        'btnSemuaPasien
        '
        Me.btnSemuaPasien.AutoSize = True
        Me.btnSemuaPasien.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnSemuaPasien.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnSemuaPasien.FlatAppearance.BorderSize = 2
        Me.btnSemuaPasien.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSemuaPasien.Location = New System.Drawing.Point(536, 15)
        Me.btnSemuaPasien.Name = "btnSemuaPasien"
        Me.btnSemuaPasien.Size = New System.Drawing.Size(130, 31)
        Me.btnSemuaPasien.TabIndex = 4
        Me.btnSemuaPasien.Text = "Semua"
        Me.btnSemuaPasien.UseVisualStyleBackColor = True
        '
        'panelAtas
        '
        Me.panelAtas.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelAtas.Location = New System.Drawing.Point(0, 0)
        Me.panelAtas.Name = "panelAtas"
        Me.panelAtas.Size = New System.Drawing.Size(666, 15)
        Me.panelAtas.TabIndex = 2
        '
        'Panel1
        '
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 46)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(666, 15)
        Me.Panel1.TabIndex = 3
        '
        'panelKanan
        '
        Me.panelKanan.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelKanan.Location = New System.Drawing.Point(866, 0)
        Me.panelKanan.Name = "panelKanan"
        Me.panelKanan.Size = New System.Drawing.Size(200, 61)
        Me.panelKanan.TabIndex = 1
        '
        'panelKiri
        '
        Me.panelKiri.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelKiri.Location = New System.Drawing.Point(0, 0)
        Me.panelKiri.Name = "panelKiri"
        Me.panelKiri.Size = New System.Drawing.Size(200, 61)
        Me.panelKiri.TabIndex = 0
        '
        'Panel145
        '
        Me.Panel145.Controls.Add(Me.Panel146)
        Me.Panel145.Controls.Add(Me.Panel150)
        Me.Panel145.Controls.Add(Me.Panel151)
        Me.Panel145.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel145.Location = New System.Drawing.Point(0, 67)
        Me.Panel145.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel145.Name = "Panel145"
        Me.Panel145.Size = New System.Drawing.Size(1066, 62)
        Me.Panel145.TabIndex = 6
        '
        'Panel146
        '
        Me.Panel146.Controls.Add(Me.txtCariPasien)
        Me.Panel146.Controls.Add(Me.Panel147)
        Me.Panel146.Controls.Add(Me.btnCariPasien)
        Me.Panel146.Controls.Add(Me.Panel148)
        Me.Panel146.Controls.Add(Me.Panel149)
        Me.Panel146.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel146.Location = New System.Drawing.Point(25, 0)
        Me.Panel146.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel146.Name = "Panel146"
        Me.Panel146.Size = New System.Drawing.Size(1016, 62)
        Me.Panel146.TabIndex = 2
        '
        'txtCariPasien
        '
        Me.txtCariPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtCariPasien.Location = New System.Drawing.Point(0, 15)
        Me.txtCariPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtCariPasien.Multiline = True
        Me.txtCariPasien.Name = "txtCariPasien"
        Me.txtCariPasien.Size = New System.Drawing.Size(856, 32)
        Me.txtCariPasien.TabIndex = 0
        '
        'Panel147
        '
        Me.Panel147.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel147.Location = New System.Drawing.Point(856, 15)
        Me.Panel147.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel147.Name = "Panel147"
        Me.Panel147.Size = New System.Drawing.Size(29, 32)
        Me.Panel147.TabIndex = 7
        '
        'btnCariPasien
        '
        Me.btnCariPasien.AutoSize = True
        Me.btnCariPasien.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnCariPasien.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnCariPasien.FlatAppearance.BorderSize = 2
        Me.btnCariPasien.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCariPasien.Location = New System.Drawing.Point(885, 15)
        Me.btnCariPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCariPasien.Name = "btnCariPasien"
        Me.btnCariPasien.Size = New System.Drawing.Size(131, 32)
        Me.btnCariPasien.TabIndex = 1
        Me.btnCariPasien.Text = "Cari"
        Me.btnCariPasien.UseVisualStyleBackColor = True
        '
        'Panel148
        '
        Me.Panel148.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel148.Location = New System.Drawing.Point(0, 0)
        Me.Panel148.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel148.Name = "Panel148"
        Me.Panel148.Size = New System.Drawing.Size(1016, 15)
        Me.Panel148.TabIndex = 2
        '
        'Panel149
        '
        Me.Panel149.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel149.Location = New System.Drawing.Point(0, 47)
        Me.Panel149.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel149.Name = "Panel149"
        Me.Panel149.Size = New System.Drawing.Size(1016, 15)
        Me.Panel149.TabIndex = 3
        '
        'Panel150
        '
        Me.Panel150.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel150.Location = New System.Drawing.Point(1041, 0)
        Me.Panel150.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel150.Name = "Panel150"
        Me.Panel150.Size = New System.Drawing.Size(25, 62)
        Me.Panel150.TabIndex = 1
        '
        'Panel151
        '
        Me.Panel151.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel151.Location = New System.Drawing.Point(0, 0)
        Me.Panel151.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel151.Name = "Panel151"
        Me.Panel151.Size = New System.Drawing.Size(25, 62)
        Me.Panel151.TabIndex = 0
        '
        'panelKeteranganDP
        '
        Me.panelKeteranganDP.Controls.Add(Me.textKeterangan)
        Me.panelKeteranganDP.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelKeteranganDP.Location = New System.Drawing.Point(0, 0)
        Me.panelKeteranganDP.Name = "panelKeteranganDP"
        Me.panelKeteranganDP.Size = New System.Drawing.Size(1066, 67)
        Me.panelKeteranganDP.TabIndex = 3
        '
        'textKeterangan
        '
        Me.textKeterangan.AutoSize = True
        Me.textKeterangan.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.textKeterangan.Location = New System.Drawing.Point(16, 19)
        Me.textKeterangan.Name = "textKeterangan"
        Me.textKeterangan.Size = New System.Drawing.Size(179, 29)
        Me.textKeterangan.TabIndex = 2
        Me.textKeterangan.Text = "Daftar Pasien"
        '
        'VScrollBar1
        '
        Me.VScrollBar1.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar1.Location = New System.Drawing.Point(1066, 0)
        Me.VScrollBar1.Name = "VScrollBar1"
        Me.VScrollBar1.Size = New System.Drawing.Size(21, 614)
        Me.VScrollBar1.TabIndex = 4
        '
        'panelRiwayatDP
        '
        Me.panelRiwayatDP.Controls.Add(Me.TableLayoutPanel5)
        Me.panelRiwayatDP.Controls.Add(Me.dgvRiwayatPasien)
        Me.panelRiwayatDP.Controls.Add(Me.Panel46)
        Me.panelRiwayatDP.Controls.Add(Me.Panel79)
        Me.panelRiwayatDP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelRiwayatDP.Location = New System.Drawing.Point(0, 0)
        Me.panelRiwayatDP.Name = "panelRiwayatDP"
        Me.panelRiwayatDP.Size = New System.Drawing.Size(1087, 614)
        Me.panelRiwayatDP.TabIndex = 8
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.ColumnCount = 1
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.Controls.Add(Me.Label18, 0, 0)
        Me.TableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(0, 329)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 1
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(1087, 285)
        Me.TableLayoutPanel5.TabIndex = 6
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label18.Location = New System.Drawing.Point(3, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(1081, 285)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "No Data"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'dgvRiwayatPasien
        '
        Me.dgvRiwayatPasien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvRiwayatPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvRiwayatPasien.Location = New System.Drawing.Point(0, 329)
        Me.dgvRiwayatPasien.Name = "dgvRiwayatPasien"
        Me.dgvRiwayatPasien.RowHeadersWidth = 51
        Me.dgvRiwayatPasien.RowTemplate.Height = 24
        Me.dgvRiwayatPasien.Size = New System.Drawing.Size(1087, 285)
        Me.dgvRiwayatPasien.TabIndex = 5
        '
        'Panel46
        '
        Me.Panel46.Controls.Add(Me.Panel47)
        Me.Panel46.Controls.Add(Me.Panel63)
        Me.Panel46.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel46.Location = New System.Drawing.Point(0, 66)
        Me.Panel46.Name = "Panel46"
        Me.Panel46.Size = New System.Drawing.Size(1087, 263)
        Me.Panel46.TabIndex = 4
        '
        'Panel47
        '
        Me.Panel47.Controls.Add(Me.Panel48)
        Me.Panel47.Controls.Add(Me.Panel49)
        Me.Panel47.Controls.Add(Me.Panel50)
        Me.Panel47.Controls.Add(Me.Panel51)
        Me.Panel47.Controls.Add(Me.Panel52)
        Me.Panel47.Controls.Add(Me.Panel53)
        Me.Panel47.Controls.Add(Me.Panel54)
        Me.Panel47.Controls.Add(Me.Panel55)
        Me.Panel47.Controls.Add(Me.Panel56)
        Me.Panel47.Controls.Add(Me.Panel57)
        Me.Panel47.Controls.Add(Me.Panel58)
        Me.Panel47.Controls.Add(Me.Panel59)
        Me.Panel47.Controls.Add(Me.Panel60)
        Me.Panel47.Controls.Add(Me.Panel61)
        Me.Panel47.Controls.Add(Me.Panel62)
        Me.Panel47.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel47.Location = New System.Drawing.Point(175, 0)
        Me.Panel47.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel47.Name = "Panel47"
        Me.Panel47.Size = New System.Drawing.Size(912, 263)
        Me.Panel47.TabIndex = 1
        '
        'Panel48
        '
        Me.Panel48.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel48.Location = New System.Drawing.Point(0, 252)
        Me.Panel48.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel48.Name = "Panel48"
        Me.Panel48.Size = New System.Drawing.Size(912, 11)
        Me.Panel48.TabIndex = 30
        '
        'Panel49
        '
        Me.Panel49.Controls.Add(Me.Label19)
        Me.Panel49.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel49.Location = New System.Drawing.Point(0, 227)
        Me.Panel49.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel49.Name = "Panel49"
        Me.Panel49.Size = New System.Drawing.Size(912, 25)
        Me.Panel49.TabIndex = 27
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label19.Location = New System.Drawing.Point(0, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(53, 17)
        Me.Label19.TabIndex = 1
        Me.Label19.Text = "Faskes"
        '
        'Panel50
        '
        Me.Panel50.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel50.Location = New System.Drawing.Point(0, 216)
        Me.Panel50.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel50.Name = "Panel50"
        Me.Panel50.Size = New System.Drawing.Size(912, 11)
        Me.Panel50.TabIndex = 25
        '
        'Panel51
        '
        Me.Panel51.Controls.Add(Me.Label20)
        Me.Panel51.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel51.Location = New System.Drawing.Point(0, 191)
        Me.Panel51.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel51.Name = "Panel51"
        Me.Panel51.Size = New System.Drawing.Size(912, 25)
        Me.Panel51.TabIndex = 24
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label20.Location = New System.Drawing.Point(0, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(51, 17)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "Alamat"
        '
        'Panel52
        '
        Me.Panel52.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel52.Location = New System.Drawing.Point(0, 180)
        Me.Panel52.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel52.Name = "Panel52"
        Me.Panel52.Size = New System.Drawing.Size(912, 11)
        Me.Panel52.TabIndex = 23
        '
        'Panel53
        '
        Me.Panel53.Controls.Add(Me.Label21)
        Me.Panel53.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel53.Location = New System.Drawing.Point(0, 155)
        Me.Panel53.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel53.Name = "Panel53"
        Me.Panel53.Size = New System.Drawing.Size(912, 25)
        Me.Panel53.TabIndex = 22
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label21.Location = New System.Drawing.Point(0, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(95, 17)
        Me.Label21.TabIndex = 1
        Me.Label21.Text = "Jenis Kelamin"
        '
        'Panel54
        '
        Me.Panel54.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel54.Location = New System.Drawing.Point(0, 144)
        Me.Panel54.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel54.Name = "Panel54"
        Me.Panel54.Size = New System.Drawing.Size(912, 11)
        Me.Panel54.TabIndex = 21
        '
        'Panel55
        '
        Me.Panel55.Controls.Add(Me.Label24)
        Me.Panel55.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel55.Location = New System.Drawing.Point(0, 119)
        Me.Panel55.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel55.Name = "Panel55"
        Me.Panel55.Size = New System.Drawing.Size(912, 25)
        Me.Panel55.TabIndex = 20
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label24.Location = New System.Drawing.Point(0, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(42, 17)
        Me.Label24.TabIndex = 1
        Me.Label24.Text = "Umur"
        '
        'Panel56
        '
        Me.Panel56.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel56.Location = New System.Drawing.Point(0, 108)
        Me.Panel56.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel56.Name = "Panel56"
        Me.Panel56.Size = New System.Drawing.Size(912, 11)
        Me.Panel56.TabIndex = 19
        '
        'Panel57
        '
        Me.Panel57.Controls.Add(Me.Label25)
        Me.Panel57.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel57.Location = New System.Drawing.Point(0, 83)
        Me.Panel57.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel57.Name = "Panel57"
        Me.Panel57.Size = New System.Drawing.Size(912, 25)
        Me.Panel57.TabIndex = 18
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label25.Location = New System.Drawing.Point(0, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(104, 17)
        Me.Label25.TabIndex = 2
        Me.Label25.Text = "Nama Lengkap"
        '
        'Panel58
        '
        Me.Panel58.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel58.Location = New System.Drawing.Point(0, 72)
        Me.Panel58.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel58.Name = "Panel58"
        Me.Panel58.Size = New System.Drawing.Size(912, 11)
        Me.Panel58.TabIndex = 17
        '
        'Panel59
        '
        Me.Panel59.Controls.Add(Me.Label26)
        Me.Panel59.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel59.Location = New System.Drawing.Point(0, 47)
        Me.Panel59.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel59.Name = "Panel59"
        Me.Panel59.Size = New System.Drawing.Size(912, 25)
        Me.Panel59.TabIndex = 16
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label26.Location = New System.Drawing.Point(0, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(79, 17)
        Me.Label26.TabIndex = 3
        Me.Label26.Text = "User Name"
        '
        'Panel60
        '
        Me.Panel60.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel60.Location = New System.Drawing.Point(0, 36)
        Me.Panel60.Name = "Panel60"
        Me.Panel60.Size = New System.Drawing.Size(912, 11)
        Me.Panel60.TabIndex = 31
        '
        'Panel61
        '
        Me.Panel61.Controls.Add(Me.Label27)
        Me.Panel61.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel61.Location = New System.Drawing.Point(0, 11)
        Me.Panel61.Name = "Panel61"
        Me.Panel61.Size = New System.Drawing.Size(912, 25)
        Me.Panel61.TabIndex = 31
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label27.Location = New System.Drawing.Point(0, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(30, 17)
        Me.Label27.TabIndex = 0
        Me.Label27.Text = "NIK"
        '
        'Panel62
        '
        Me.Panel62.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel62.Location = New System.Drawing.Point(0, 0)
        Me.Panel62.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel62.Name = "Panel62"
        Me.Panel62.Size = New System.Drawing.Size(912, 11)
        Me.Panel62.TabIndex = 15
        '
        'Panel63
        '
        Me.Panel63.Controls.Add(Me.Panel64)
        Me.Panel63.Controls.Add(Me.Panel65)
        Me.Panel63.Controls.Add(Me.Panel66)
        Me.Panel63.Controls.Add(Me.Panel67)
        Me.Panel63.Controls.Add(Me.Panel68)
        Me.Panel63.Controls.Add(Me.Panel69)
        Me.Panel63.Controls.Add(Me.Panel70)
        Me.Panel63.Controls.Add(Me.Panel71)
        Me.Panel63.Controls.Add(Me.Panel72)
        Me.Panel63.Controls.Add(Me.Panel73)
        Me.Panel63.Controls.Add(Me.Panel74)
        Me.Panel63.Controls.Add(Me.Panel75)
        Me.Panel63.Controls.Add(Me.Panel76)
        Me.Panel63.Controls.Add(Me.Panel77)
        Me.Panel63.Controls.Add(Me.Panel78)
        Me.Panel63.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel63.Location = New System.Drawing.Point(0, 0)
        Me.Panel63.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel63.Name = "Panel63"
        Me.Panel63.Size = New System.Drawing.Size(175, 263)
        Me.Panel63.TabIndex = 1
        '
        'Panel64
        '
        Me.Panel64.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel64.Location = New System.Drawing.Point(0, 252)
        Me.Panel64.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel64.Name = "Panel64"
        Me.Panel64.Size = New System.Drawing.Size(175, 11)
        Me.Panel64.TabIndex = 30
        '
        'Panel65
        '
        Me.Panel65.Controls.Add(Me.Label30)
        Me.Panel65.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel65.Location = New System.Drawing.Point(0, 227)
        Me.Panel65.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel65.Name = "Panel65"
        Me.Panel65.Size = New System.Drawing.Size(175, 25)
        Me.Panel65.TabIndex = 27
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label30.Location = New System.Drawing.Point(0, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(53, 17)
        Me.Label30.TabIndex = 1
        Me.Label30.Text = "Faskes"
        '
        'Panel66
        '
        Me.Panel66.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel66.Location = New System.Drawing.Point(0, 216)
        Me.Panel66.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel66.Name = "Panel66"
        Me.Panel66.Size = New System.Drawing.Size(175, 11)
        Me.Panel66.TabIndex = 25
        '
        'Panel67
        '
        Me.Panel67.Controls.Add(Me.Label31)
        Me.Panel67.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel67.Location = New System.Drawing.Point(0, 191)
        Me.Panel67.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel67.Name = "Panel67"
        Me.Panel67.Size = New System.Drawing.Size(175, 25)
        Me.Panel67.TabIndex = 24
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label31.Location = New System.Drawing.Point(0, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(51, 17)
        Me.Label31.TabIndex = 1
        Me.Label31.Text = "Alamat"
        '
        'Panel68
        '
        Me.Panel68.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel68.Location = New System.Drawing.Point(0, 180)
        Me.Panel68.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel68.Name = "Panel68"
        Me.Panel68.Size = New System.Drawing.Size(175, 11)
        Me.Panel68.TabIndex = 23
        '
        'Panel69
        '
        Me.Panel69.Controls.Add(Me.Label32)
        Me.Panel69.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel69.Location = New System.Drawing.Point(0, 155)
        Me.Panel69.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel69.Name = "Panel69"
        Me.Panel69.Size = New System.Drawing.Size(175, 25)
        Me.Panel69.TabIndex = 22
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label32.Location = New System.Drawing.Point(0, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(95, 17)
        Me.Label32.TabIndex = 1
        Me.Label32.Text = "Jenis Kelamin"
        '
        'Panel70
        '
        Me.Panel70.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel70.Location = New System.Drawing.Point(0, 144)
        Me.Panel70.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel70.Name = "Panel70"
        Me.Panel70.Size = New System.Drawing.Size(175, 11)
        Me.Panel70.TabIndex = 21
        '
        'Panel71
        '
        Me.Panel71.Controls.Add(Me.Label33)
        Me.Panel71.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel71.Location = New System.Drawing.Point(0, 119)
        Me.Panel71.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel71.Name = "Panel71"
        Me.Panel71.Size = New System.Drawing.Size(175, 25)
        Me.Panel71.TabIndex = 20
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label33.Location = New System.Drawing.Point(0, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(42, 17)
        Me.Label33.TabIndex = 1
        Me.Label33.Text = "Umur"
        '
        'Panel72
        '
        Me.Panel72.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel72.Location = New System.Drawing.Point(0, 108)
        Me.Panel72.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel72.Name = "Panel72"
        Me.Panel72.Size = New System.Drawing.Size(175, 11)
        Me.Panel72.TabIndex = 19
        '
        'Panel73
        '
        Me.Panel73.Controls.Add(Me.Label36)
        Me.Panel73.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel73.Location = New System.Drawing.Point(0, 83)
        Me.Panel73.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel73.Name = "Panel73"
        Me.Panel73.Size = New System.Drawing.Size(175, 25)
        Me.Panel73.TabIndex = 18
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label36.Location = New System.Drawing.Point(0, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(104, 17)
        Me.Label36.TabIndex = 2
        Me.Label36.Text = "Nama Lengkap"
        '
        'Panel74
        '
        Me.Panel74.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel74.Location = New System.Drawing.Point(0, 72)
        Me.Panel74.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel74.Name = "Panel74"
        Me.Panel74.Size = New System.Drawing.Size(175, 11)
        Me.Panel74.TabIndex = 17
        '
        'Panel75
        '
        Me.Panel75.Controls.Add(Me.Label37)
        Me.Panel75.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel75.Location = New System.Drawing.Point(0, 47)
        Me.Panel75.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel75.Name = "Panel75"
        Me.Panel75.Size = New System.Drawing.Size(175, 25)
        Me.Panel75.TabIndex = 16
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label37.Location = New System.Drawing.Point(0, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(79, 17)
        Me.Label37.TabIndex = 3
        Me.Label37.Text = "User Name"
        '
        'Panel76
        '
        Me.Panel76.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel76.Location = New System.Drawing.Point(0, 36)
        Me.Panel76.Name = "Panel76"
        Me.Panel76.Size = New System.Drawing.Size(175, 11)
        Me.Panel76.TabIndex = 32
        '
        'Panel77
        '
        Me.Panel77.Controls.Add(Me.Label38)
        Me.Panel77.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel77.Location = New System.Drawing.Point(0, 11)
        Me.Panel77.Name = "Panel77"
        Me.Panel77.Size = New System.Drawing.Size(175, 25)
        Me.Panel77.TabIndex = 31
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label38.Location = New System.Drawing.Point(0, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(30, 17)
        Me.Label38.TabIndex = 0
        Me.Label38.Text = "NIK"
        '
        'Panel78
        '
        Me.Panel78.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel78.Location = New System.Drawing.Point(0, 0)
        Me.Panel78.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel78.Name = "Panel78"
        Me.Panel78.Size = New System.Drawing.Size(175, 11)
        Me.Panel78.TabIndex = 15
        '
        'Panel79
        '
        Me.Panel79.Controls.Add(Me.Panel80)
        Me.Panel79.Controls.Add(Me.Button3)
        Me.Panel79.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel79.Location = New System.Drawing.Point(0, 0)
        Me.Panel79.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel79.Name = "Panel79"
        Me.Panel79.Size = New System.Drawing.Size(1087, 66)
        Me.Panel79.TabIndex = 3
        '
        'Panel80
        '
        Me.Panel80.Controls.Add(Me.Label39)
        Me.Panel80.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel80.Location = New System.Drawing.Point(75, 0)
        Me.Panel80.Name = "Panel80"
        Me.Panel80.Size = New System.Drawing.Size(1012, 66)
        Me.Panel80.TabIndex = 3
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label39.Location = New System.Drawing.Point(16, 18)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(202, 29)
        Me.Label39.TabIndex = 2
        Me.Label39.Text = "Riwayat Pasien"
        '
        'Button3
        '
        Me.Button3.BackgroundImage = CType(resources.GetObject("Button3.BackgroundImage"), System.Drawing.Image)
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button3.Dock = System.Windows.Forms.DockStyle.Left
        Me.Button3.Location = New System.Drawing.Point(0, 0)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 66)
        Me.Button3.TabIndex = 4
        Me.Button3.UseVisualStyleBackColor = True
        '
        'panelTransaksi
        '
        Me.panelTransaksi.Controls.Add(Me.panelDatabaseTransaksi)
        Me.panelTransaksi.Controls.Add(Me.panelKeteranganTransaksi)
        Me.panelTransaksi.Controls.Add(Me.VScrollBar2)
        Me.panelTransaksi.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelTransaksi.Location = New System.Drawing.Point(0, 0)
        Me.panelTransaksi.Name = "panelTransaksi"
        Me.panelTransaksi.Size = New System.Drawing.Size(1087, 614)
        Me.panelTransaksi.TabIndex = 6
        '
        'panelDatabaseTransaksi
        '
        Me.panelDatabaseTransaksi.Controls.Add(Me.TLPNoData)
        Me.panelDatabaseTransaksi.Controls.Add(Me.dgvTransaksiObat)
        Me.panelDatabaseTransaksi.Controls.Add(Me.Panel4)
        Me.panelDatabaseTransaksi.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDatabaseTransaksi.Location = New System.Drawing.Point(0, 67)
        Me.panelDatabaseTransaksi.Name = "panelDatabaseTransaksi"
        Me.panelDatabaseTransaksi.Size = New System.Drawing.Size(1066, 547)
        Me.panelDatabaseTransaksi.TabIndex = 5
        '
        'TLPNoData
        '
        Me.TLPNoData.ColumnCount = 1
        Me.TLPNoData.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLPNoData.Controls.Add(Me.Label35, 0, 0)
        Me.TLPNoData.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLPNoData.Location = New System.Drawing.Point(0, 61)
        Me.TLPNoData.Name = "TLPNoData"
        Me.TLPNoData.RowCount = 1
        Me.TLPNoData.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLPNoData.Size = New System.Drawing.Size(1066, 486)
        Me.TLPNoData.TabIndex = 3
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label35.Location = New System.Drawing.Point(3, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(1060, 486)
        Me.Label35.TabIndex = 0
        Me.Label35.Text = "No Data"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'dgvTransaksiObat
        '
        Me.dgvTransaksiObat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvTransaksiObat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvTransaksiObat.Location = New System.Drawing.Point(0, 61)
        Me.dgvTransaksiObat.Name = "dgvTransaksiObat"
        Me.dgvTransaksiObat.RowHeadersWidth = 51
        Me.dgvTransaksiObat.RowTemplate.Height = 24
        Me.dgvTransaksiObat.Size = New System.Drawing.Size(1066, 486)
        Me.dgvTransaksiObat.TabIndex = 1
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Panel5)
        Me.Panel4.Controls.Add(Me.Panel8)
        Me.Panel4.Controls.Add(Me.Panel9)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1066, 61)
        Me.Panel4.TabIndex = 0
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.btnBelumBayar)
        Me.Panel5.Controls.Add(Me.btnSemuaTransaksi)
        Me.Panel5.Controls.Add(Me.Panel6)
        Me.Panel5.Controls.Add(Me.Panel7)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel5.Location = New System.Drawing.Point(200, 0)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(666, 61)
        Me.Panel5.TabIndex = 2
        '
        'btnBelumBayar
        '
        Me.btnBelumBayar.AutoSize = True
        Me.btnBelumBayar.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnBelumBayar.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnBelumBayar.FlatAppearance.BorderSize = 2
        Me.btnBelumBayar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBelumBayar.Location = New System.Drawing.Point(0, 15)
        Me.btnBelumBayar.Name = "btnBelumBayar"
        Me.btnBelumBayar.Size = New System.Drawing.Size(131, 31)
        Me.btnBelumBayar.TabIndex = 1
        Me.btnBelumBayar.Text = "Belum Membayar"
        Me.btnBelumBayar.UseVisualStyleBackColor = True
        '
        'btnSemuaTransaksi
        '
        Me.btnSemuaTransaksi.AutoSize = True
        Me.btnSemuaTransaksi.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnSemuaTransaksi.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnSemuaTransaksi.FlatAppearance.BorderSize = 2
        Me.btnSemuaTransaksi.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSemuaTransaksi.Location = New System.Drawing.Point(536, 15)
        Me.btnSemuaTransaksi.Name = "btnSemuaTransaksi"
        Me.btnSemuaTransaksi.Size = New System.Drawing.Size(130, 31)
        Me.btnSemuaTransaksi.TabIndex = 4
        Me.btnSemuaTransaksi.Text = "Semua"
        Me.btnSemuaTransaksi.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel6.Location = New System.Drawing.Point(0, 0)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(666, 15)
        Me.Panel6.TabIndex = 2
        '
        'Panel7
        '
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel7.Location = New System.Drawing.Point(0, 46)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(666, 15)
        Me.Panel7.TabIndex = 3
        '
        'Panel8
        '
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel8.Location = New System.Drawing.Point(866, 0)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(200, 61)
        Me.Panel8.TabIndex = 1
        '
        'Panel9
        '
        Me.Panel9.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel9.Location = New System.Drawing.Point(0, 0)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(200, 61)
        Me.Panel9.TabIndex = 0
        '
        'panelKeteranganTransaksi
        '
        Me.panelKeteranganTransaksi.Controls.Add(Me.Label10)
        Me.panelKeteranganTransaksi.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelKeteranganTransaksi.Location = New System.Drawing.Point(0, 0)
        Me.panelKeteranganTransaksi.Name = "panelKeteranganTransaksi"
        Me.panelKeteranganTransaksi.Size = New System.Drawing.Size(1066, 67)
        Me.panelKeteranganTransaksi.TabIndex = 3
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label10.Location = New System.Drawing.Point(16, 19)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(132, 29)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Transaksi"
        '
        'VScrollBar2
        '
        Me.VScrollBar2.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar2.Location = New System.Drawing.Point(1066, 0)
        Me.VScrollBar2.Name = "VScrollBar2"
        Me.VScrollBar2.Size = New System.Drawing.Size(21, 614)
        Me.VScrollBar2.TabIndex = 4
        '
        'panelDaftarObat
        '
        Me.panelDaftarObat.Controls.Add(Me.Panel14)
        Me.panelDaftarObat.Controls.Add(Me.Panel22)
        Me.panelDaftarObat.Controls.Add(Me.VScrollBar6)
        Me.panelDaftarObat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDaftarObat.Location = New System.Drawing.Point(0, 0)
        Me.panelDaftarObat.Name = "panelDaftarObat"
        Me.panelDaftarObat.Size = New System.Drawing.Size(1087, 614)
        Me.panelDaftarObat.TabIndex = 0
        '
        'Panel14
        '
        Me.Panel14.Controls.Add(Me.dgvDaftarObat)
        Me.Panel14.Controls.Add(Me.panelFormulirObat)
        Me.Panel14.Controls.Add(Me.Panel136)
        Me.Panel14.Controls.Add(Me.Panel15)
        Me.Panel14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel14.Location = New System.Drawing.Point(0, 67)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(1066, 547)
        Me.Panel14.TabIndex = 5
        '
        'dgvDaftarObat
        '
        Me.dgvDaftarObat.AllowUserToAddRows = False
        Me.dgvDaftarObat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDaftarObat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvDaftarObat.Location = New System.Drawing.Point(0, 247)
        Me.dgvDaftarObat.Name = "dgvDaftarObat"
        Me.dgvDaftarObat.ReadOnly = True
        Me.dgvDaftarObat.RowHeadersWidth = 51
        Me.dgvDaftarObat.RowTemplate.Height = 24
        Me.dgvDaftarObat.Size = New System.Drawing.Size(1066, 300)
        Me.dgvDaftarObat.TabIndex = 1
        '
        'panelFormulirObat
        '
        Me.panelFormulirObat.Controls.Add(Me.Panel85)
        Me.panelFormulirObat.Controls.Add(Me.Panel103)
        Me.panelFormulirObat.Controls.Add(Me.Panel117)
        Me.panelFormulirObat.Controls.Add(Me.Panel135)
        Me.panelFormulirObat.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFormulirObat.Location = New System.Drawing.Point(0, 124)
        Me.panelFormulirObat.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelFormulirObat.Name = "panelFormulirObat"
        Me.panelFormulirObat.Size = New System.Drawing.Size(1066, 123)
        Me.panelFormulirObat.TabIndex = 7
        '
        'Panel85
        '
        Me.Panel85.Controls.Add(Me.Panel98)
        Me.Panel85.Controls.Add(Me.Panel99)
        Me.Panel85.Controls.Add(Me.Panel100)
        Me.Panel85.Controls.Add(Me.Panel101)
        Me.Panel85.Controls.Add(Me.Panel88)
        Me.Panel85.Controls.Add(Me.Panel89)
        Me.Panel85.Controls.Add(Me.Panel102)
        Me.Panel85.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel85.Location = New System.Drawing.Point(178, 0)
        Me.Panel85.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel85.Name = "Panel85"
        Me.Panel85.Size = New System.Drawing.Size(733, 123)
        Me.Panel85.TabIndex = 1
        '
        'Panel98
        '
        Me.Panel98.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel98.Location = New System.Drawing.Point(0, 108)
        Me.Panel98.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel98.Name = "Panel98"
        Me.Panel98.Size = New System.Drawing.Size(733, 11)
        Me.Panel98.TabIndex = 4
        '
        'Panel99
        '
        Me.Panel99.Controls.Add(Me.txtHargaObat)
        Me.Panel99.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel99.Location = New System.Drawing.Point(0, 83)
        Me.Panel99.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel99.Name = "Panel99"
        Me.Panel99.Size = New System.Drawing.Size(733, 25)
        Me.Panel99.TabIndex = 3
        '
        'txtHargaObat
        '
        Me.txtHargaObat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtHargaObat.Location = New System.Drawing.Point(0, 0)
        Me.txtHargaObat.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtHargaObat.Name = "txtHargaObat"
        Me.txtHargaObat.Size = New System.Drawing.Size(733, 22)
        Me.txtHargaObat.TabIndex = 3
        '
        'Panel100
        '
        Me.Panel100.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel100.Location = New System.Drawing.Point(0, 72)
        Me.Panel100.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel100.Name = "Panel100"
        Me.Panel100.Size = New System.Drawing.Size(733, 11)
        Me.Panel100.TabIndex = 2
        '
        'Panel101
        '
        Me.Panel101.Controls.Add(Me.txtJumlahObat)
        Me.Panel101.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel101.Location = New System.Drawing.Point(0, 47)
        Me.Panel101.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel101.Name = "Panel101"
        Me.Panel101.Size = New System.Drawing.Size(733, 25)
        Me.Panel101.TabIndex = 1
        '
        'txtJumlahObat
        '
        Me.txtJumlahObat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtJumlahObat.Location = New System.Drawing.Point(0, 0)
        Me.txtJumlahObat.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtJumlahObat.Name = "txtJumlahObat"
        Me.txtJumlahObat.Size = New System.Drawing.Size(733, 22)
        Me.txtJumlahObat.TabIndex = 2
        '
        'Panel88
        '
        Me.Panel88.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel88.Location = New System.Drawing.Point(0, 36)
        Me.Panel88.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel88.Name = "Panel88"
        Me.Panel88.Size = New System.Drawing.Size(733, 11)
        Me.Panel88.TabIndex = 14
        '
        'Panel89
        '
        Me.Panel89.Controls.Add(Me.txtNamaObat)
        Me.Panel89.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel89.Location = New System.Drawing.Point(0, 11)
        Me.Panel89.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel89.Name = "Panel89"
        Me.Panel89.Size = New System.Drawing.Size(733, 25)
        Me.Panel89.TabIndex = 12
        '
        'txtNamaObat
        '
        Me.txtNamaObat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtNamaObat.Location = New System.Drawing.Point(0, 0)
        Me.txtNamaObat.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtNamaObat.Name = "txtNamaObat"
        Me.txtNamaObat.Size = New System.Drawing.Size(733, 22)
        Me.txtNamaObat.TabIndex = 2
        '
        'Panel102
        '
        Me.Panel102.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel102.Location = New System.Drawing.Point(0, 0)
        Me.Panel102.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel102.Name = "Panel102"
        Me.Panel102.Size = New System.Drawing.Size(733, 11)
        Me.Panel102.TabIndex = 0
        '
        'Panel103
        '
        Me.Panel103.Controls.Add(Me.Panel105)
        Me.Panel103.Controls.Add(Me.Panel111)
        Me.Panel103.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel103.Location = New System.Drawing.Point(911, 0)
        Me.Panel103.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel103.Name = "Panel103"
        Me.Panel103.Size = New System.Drawing.Size(155, 123)
        Me.Panel103.TabIndex = 0
        '
        'Panel105
        '
        Me.Panel105.Controls.Add(Me.Panel106)
        Me.Panel105.Controls.Add(Me.Panel107)
        Me.Panel105.Controls.Add(Me.Panel108)
        Me.Panel105.Controls.Add(Me.Panel109)
        Me.Panel105.Controls.Add(Me.btnBatal)
        Me.Panel105.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel105.Location = New System.Drawing.Point(0, 55)
        Me.Panel105.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel105.Name = "Panel105"
        Me.Panel105.Size = New System.Drawing.Size(155, 55)
        Me.Panel105.TabIndex = 3
        '
        'Panel106
        '
        Me.Panel106.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel106.Location = New System.Drawing.Point(16, 0)
        Me.Panel106.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel106.Name = "Panel106"
        Me.Panel106.Size = New System.Drawing.Size(123, 10)
        Me.Panel106.TabIndex = 9
        '
        'Panel107
        '
        Me.Panel107.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel107.Location = New System.Drawing.Point(16, 45)
        Me.Panel107.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel107.Name = "Panel107"
        Me.Panel107.Size = New System.Drawing.Size(123, 10)
        Me.Panel107.TabIndex = 8
        '
        'Panel108
        '
        Me.Panel108.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel108.Location = New System.Drawing.Point(139, 0)
        Me.Panel108.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel108.Name = "Panel108"
        Me.Panel108.Size = New System.Drawing.Size(16, 55)
        Me.Panel108.TabIndex = 7
        '
        'Panel109
        '
        Me.Panel109.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel109.Location = New System.Drawing.Point(0, 0)
        Me.Panel109.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel109.Name = "Panel109"
        Me.Panel109.Size = New System.Drawing.Size(16, 55)
        Me.Panel109.TabIndex = 6
        '
        'btnBatal
        '
        Me.btnBatal.BackColor = System.Drawing.Color.LightGray
        Me.btnBatal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnBatal.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnBatal.FlatAppearance.BorderSize = 4
        Me.btnBatal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBatal.Location = New System.Drawing.Point(0, 0)
        Me.btnBatal.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(155, 55)
        Me.btnBatal.TabIndex = 5
        Me.btnBatal.Text = "Batal"
        Me.btnBatal.UseVisualStyleBackColor = False
        '
        'Panel111
        '
        Me.Panel111.Controls.Add(Me.Panel112)
        Me.Panel111.Controls.Add(Me.Panel113)
        Me.Panel111.Controls.Add(Me.Panel114)
        Me.Panel111.Controls.Add(Me.Panel115)
        Me.Panel111.Controls.Add(Me.btnSimpan)
        Me.Panel111.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel111.Location = New System.Drawing.Point(0, 0)
        Me.Panel111.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel111.Name = "Panel111"
        Me.Panel111.Size = New System.Drawing.Size(155, 55)
        Me.Panel111.TabIndex = 1
        '
        'Panel112
        '
        Me.Panel112.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel112.Location = New System.Drawing.Point(16, 0)
        Me.Panel112.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel112.Name = "Panel112"
        Me.Panel112.Size = New System.Drawing.Size(123, 10)
        Me.Panel112.TabIndex = 4
        '
        'Panel113
        '
        Me.Panel113.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel113.Location = New System.Drawing.Point(16, 45)
        Me.Panel113.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel113.Name = "Panel113"
        Me.Panel113.Size = New System.Drawing.Size(123, 10)
        Me.Panel113.TabIndex = 3
        '
        'Panel114
        '
        Me.Panel114.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel114.Location = New System.Drawing.Point(139, 0)
        Me.Panel114.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel114.Name = "Panel114"
        Me.Panel114.Size = New System.Drawing.Size(16, 55)
        Me.Panel114.TabIndex = 2
        '
        'Panel115
        '
        Me.Panel115.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel115.Location = New System.Drawing.Point(0, 0)
        Me.Panel115.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel115.Name = "Panel115"
        Me.Panel115.Size = New System.Drawing.Size(16, 55)
        Me.Panel115.TabIndex = 1
        '
        'btnSimpan
        '
        Me.btnSimpan.BackColor = System.Drawing.Color.LightGray
        Me.btnSimpan.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnSimpan.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnSimpan.FlatAppearance.BorderSize = 4
        Me.btnSimpan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSimpan.Location = New System.Drawing.Point(0, 0)
        Me.btnSimpan.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSimpan.Name = "btnSimpan"
        Me.btnSimpan.Size = New System.Drawing.Size(155, 55)
        Me.btnSimpan.TabIndex = 0
        Me.btnSimpan.Text = "Simpan"
        Me.btnSimpan.UseVisualStyleBackColor = False
        '
        'Panel117
        '
        Me.Panel117.Controls.Add(Me.Panel130)
        Me.Panel117.Controls.Add(Me.Panel131)
        Me.Panel117.Controls.Add(Me.Panel132)
        Me.Panel117.Controls.Add(Me.Panel133)
        Me.Panel117.Controls.Add(Me.Panel120)
        Me.Panel117.Controls.Add(Me.Panel121)
        Me.Panel117.Controls.Add(Me.Panel134)
        Me.Panel117.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel117.Location = New System.Drawing.Point(25, 0)
        Me.Panel117.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel117.Name = "Panel117"
        Me.Panel117.Size = New System.Drawing.Size(153, 123)
        Me.Panel117.TabIndex = 0
        '
        'Panel130
        '
        Me.Panel130.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel130.Location = New System.Drawing.Point(0, 108)
        Me.Panel130.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel130.Name = "Panel130"
        Me.Panel130.Size = New System.Drawing.Size(153, 11)
        Me.Panel130.TabIndex = 19
        '
        'Panel131
        '
        Me.Panel131.Controls.Add(Me.Label28)
        Me.Panel131.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel131.Location = New System.Drawing.Point(0, 83)
        Me.Panel131.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel131.Name = "Panel131"
        Me.Panel131.Size = New System.Drawing.Size(153, 25)
        Me.Panel131.TabIndex = 18
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label28.Location = New System.Drawing.Point(0, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(82, 17)
        Me.Label28.TabIndex = 2
        Me.Label28.Text = "Harga Obat"
        '
        'Panel132
        '
        Me.Panel132.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel132.Location = New System.Drawing.Point(0, 72)
        Me.Panel132.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel132.Name = "Panel132"
        Me.Panel132.Size = New System.Drawing.Size(153, 11)
        Me.Panel132.TabIndex = 17
        '
        'Panel133
        '
        Me.Panel133.Controls.Add(Me.Label29)
        Me.Panel133.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel133.Location = New System.Drawing.Point(0, 47)
        Me.Panel133.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel133.Name = "Panel133"
        Me.Panel133.Size = New System.Drawing.Size(153, 25)
        Me.Panel133.TabIndex = 16
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label29.Location = New System.Drawing.Point(0, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(88, 17)
        Me.Label29.TabIndex = 3
        Me.Label29.Text = "Jumlah Obat"
        '
        'Panel120
        '
        Me.Panel120.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel120.Location = New System.Drawing.Point(0, 36)
        Me.Panel120.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel120.Name = "Panel120"
        Me.Panel120.Size = New System.Drawing.Size(153, 11)
        Me.Panel120.TabIndex = 30
        '
        'Panel121
        '
        Me.Panel121.Controls.Add(Me.Label23)
        Me.Panel121.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel121.Location = New System.Drawing.Point(0, 11)
        Me.Panel121.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel121.Name = "Panel121"
        Me.Panel121.Size = New System.Drawing.Size(153, 25)
        Me.Panel121.TabIndex = 28
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label23.Location = New System.Drawing.Point(0, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(80, 17)
        Me.Label23.TabIndex = 1
        Me.Label23.Text = "Nama Obat"
        '
        'Panel134
        '
        Me.Panel134.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel134.Location = New System.Drawing.Point(0, 0)
        Me.Panel134.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel134.Name = "Panel134"
        Me.Panel134.Size = New System.Drawing.Size(153, 11)
        Me.Panel134.TabIndex = 15
        '
        'Panel135
        '
        Me.Panel135.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel135.Location = New System.Drawing.Point(0, 0)
        Me.Panel135.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel135.Name = "Panel135"
        Me.Panel135.Size = New System.Drawing.Size(25, 123)
        Me.Panel135.TabIndex = 0
        '
        'Panel136
        '
        Me.Panel136.Controls.Add(Me.Panel137)
        Me.Panel136.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel136.Location = New System.Drawing.Point(0, 61)
        Me.Panel136.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel136.Name = "Panel136"
        Me.Panel136.Size = New System.Drawing.Size(1066, 63)
        Me.Panel136.TabIndex = 6
        '
        'Panel137
        '
        Me.Panel137.Controls.Add(Me.btnTambah)
        Me.Panel137.Controls.Add(Me.Panel138)
        Me.Panel137.Controls.Add(Me.btnEdit)
        Me.Panel137.Controls.Add(Me.Panel139)
        Me.Panel137.Controls.Add(Me.btnHapus)
        Me.Panel137.Controls.Add(Me.Panel140)
        Me.Panel137.Controls.Add(Me.btnRefresh)
        Me.Panel137.Controls.Add(Me.Panel141)
        Me.Panel137.Controls.Add(Me.Panel142)
        Me.Panel137.Controls.Add(Me.Panel143)
        Me.Panel137.Controls.Add(Me.Panel144)
        Me.Panel137.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel137.Location = New System.Drawing.Point(0, 0)
        Me.Panel137.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel137.Name = "Panel137"
        Me.Panel137.Size = New System.Drawing.Size(1066, 63)
        Me.Panel137.TabIndex = 3
        '
        'btnTambah
        '
        Me.btnTambah.AutoSize = True
        Me.btnTambah.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnTambah.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnTambah.FlatAppearance.BorderSize = 2
        Me.btnTambah.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTambah.Location = New System.Drawing.Point(430, 15)
        Me.btnTambah.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnTambah.Name = "btnTambah"
        Me.btnTambah.Size = New System.Drawing.Size(131, 33)
        Me.btnTambah.TabIndex = 10
        Me.btnTambah.Text = "Tambah"
        Me.btnTambah.UseVisualStyleBackColor = True
        '
        'Panel138
        '
        Me.Panel138.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel138.Location = New System.Drawing.Point(561, 15)
        Me.Panel138.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel138.Name = "Panel138"
        Me.Panel138.Size = New System.Drawing.Size(29, 33)
        Me.Panel138.TabIndex = 8
        '
        'btnEdit
        '
        Me.btnEdit.AutoSize = True
        Me.btnEdit.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnEdit.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnEdit.FlatAppearance.BorderSize = 2
        Me.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEdit.Location = New System.Drawing.Point(590, 15)
        Me.btnEdit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(131, 33)
        Me.btnEdit.TabIndex = 9
        Me.btnEdit.Text = "Edit"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'Panel139
        '
        Me.Panel139.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel139.Location = New System.Drawing.Point(721, 15)
        Me.Panel139.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel139.Name = "Panel139"
        Me.Panel139.Size = New System.Drawing.Size(29, 33)
        Me.Panel139.TabIndex = 7
        '
        'btnHapus
        '
        Me.btnHapus.AutoSize = True
        Me.btnHapus.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnHapus.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnHapus.FlatAppearance.BorderSize = 2
        Me.btnHapus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHapus.Location = New System.Drawing.Point(750, 15)
        Me.btnHapus.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnHapus.Name = "btnHapus"
        Me.btnHapus.Size = New System.Drawing.Size(131, 33)
        Me.btnHapus.TabIndex = 1
        Me.btnHapus.Text = "Hapus"
        Me.btnHapus.UseVisualStyleBackColor = True
        '
        'Panel140
        '
        Me.Panel140.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel140.Location = New System.Drawing.Point(881, 15)
        Me.Panel140.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel140.Name = "Panel140"
        Me.Panel140.Size = New System.Drawing.Size(29, 33)
        Me.Panel140.TabIndex = 8
        '
        'btnRefresh
        '
        Me.btnRefresh.AutoSize = True
        Me.btnRefresh.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnRefresh.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnRefresh.FlatAppearance.BorderSize = 2
        Me.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRefresh.Location = New System.Drawing.Point(910, 15)
        Me.btnRefresh.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(131, 33)
        Me.btnRefresh.TabIndex = 4
        Me.btnRefresh.Text = "Refresh"
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'Panel141
        '
        Me.Panel141.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel141.Location = New System.Drawing.Point(0, 15)
        Me.Panel141.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel141.Name = "Panel141"
        Me.Panel141.Size = New System.Drawing.Size(25, 33)
        Me.Panel141.TabIndex = 5
        '
        'Panel142
        '
        Me.Panel142.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel142.Location = New System.Drawing.Point(1041, 15)
        Me.Panel142.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel142.Name = "Panel142"
        Me.Panel142.Size = New System.Drawing.Size(25, 33)
        Me.Panel142.TabIndex = 6
        '
        'Panel143
        '
        Me.Panel143.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel143.Location = New System.Drawing.Point(0, 0)
        Me.Panel143.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel143.Name = "Panel143"
        Me.Panel143.Size = New System.Drawing.Size(1066, 15)
        Me.Panel143.TabIndex = 2
        '
        'Panel144
        '
        Me.Panel144.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel144.Location = New System.Drawing.Point(0, 48)
        Me.Panel144.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel144.Name = "Panel144"
        Me.Panel144.Size = New System.Drawing.Size(1066, 15)
        Me.Panel144.TabIndex = 3
        '
        'Panel15
        '
        Me.Panel15.Controls.Add(Me.Panel17)
        Me.Panel15.Controls.Add(Me.Panel20)
        Me.Panel15.Controls.Add(Me.Panel21)
        Me.Panel15.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel15.Location = New System.Drawing.Point(0, 0)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(1066, 61)
        Me.Panel15.TabIndex = 0
        '
        'Panel17
        '
        Me.Panel17.Controls.Add(Me.txtCariNamaObat)
        Me.Panel17.Controls.Add(Me.Panel24)
        Me.Panel17.Controls.Add(Me.btnCariObat)
        Me.Panel17.Controls.Add(Me.Panel2)
        Me.Panel17.Controls.Add(Me.Panel23)
        Me.Panel17.Controls.Add(Me.Panel18)
        Me.Panel17.Controls.Add(Me.Panel19)
        Me.Panel17.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel17.Location = New System.Drawing.Point(25, 0)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(1016, 61)
        Me.Panel17.TabIndex = 2
        '
        'txtCariNamaObat
        '
        Me.txtCariNamaObat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtCariNamaObat.Location = New System.Drawing.Point(25, 15)
        Me.txtCariNamaObat.Multiline = True
        Me.txtCariNamaObat.Name = "txtCariNamaObat"
        Me.txtCariNamaObat.Size = New System.Drawing.Size(806, 31)
        Me.txtCariNamaObat.TabIndex = 0
        '
        'Panel24
        '
        Me.Panel24.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel24.Location = New System.Drawing.Point(831, 15)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(30, 31)
        Me.Panel24.TabIndex = 7
        '
        'btnCariObat
        '
        Me.btnCariObat.AutoSize = True
        Me.btnCariObat.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnCariObat.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnCariObat.FlatAppearance.BorderSize = 2
        Me.btnCariObat.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCariObat.Location = New System.Drawing.Point(861, 15)
        Me.btnCariObat.Name = "btnCariObat"
        Me.btnCariObat.Size = New System.Drawing.Size(130, 31)
        Me.btnCariObat.TabIndex = 1
        Me.btnCariObat.Text = "Cari"
        Me.btnCariObat.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel2.Location = New System.Drawing.Point(0, 15)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(25, 31)
        Me.Panel2.TabIndex = 5
        '
        'Panel23
        '
        Me.Panel23.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel23.Location = New System.Drawing.Point(991, 15)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(25, 31)
        Me.Panel23.TabIndex = 6
        '
        'Panel18
        '
        Me.Panel18.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel18.Location = New System.Drawing.Point(0, 0)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(1016, 15)
        Me.Panel18.TabIndex = 2
        '
        'Panel19
        '
        Me.Panel19.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel19.Location = New System.Drawing.Point(0, 46)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(1016, 15)
        Me.Panel19.TabIndex = 3
        '
        'Panel20
        '
        Me.Panel20.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel20.Location = New System.Drawing.Point(1041, 0)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(25, 61)
        Me.Panel20.TabIndex = 1
        '
        'Panel21
        '
        Me.Panel21.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel21.Location = New System.Drawing.Point(0, 0)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(25, 61)
        Me.Panel21.TabIndex = 0
        '
        'Panel22
        '
        Me.Panel22.Controls.Add(Me.Label13)
        Me.Panel22.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel22.Location = New System.Drawing.Point(0, 0)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(1066, 67)
        Me.Panel22.TabIndex = 3
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label13.Location = New System.Drawing.Point(16, 19)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(153, 29)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Daftar Obat"
        '
        'VScrollBar6
        '
        Me.VScrollBar6.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar6.Location = New System.Drawing.Point(1066, 0)
        Me.VScrollBar6.Name = "VScrollBar6"
        Me.VScrollBar6.Size = New System.Drawing.Size(21, 614)
        Me.VScrollBar6.TabIndex = 4
        '
        'panelDashboard
        '
        Me.panelDashboard.Controls.Add(Me.Panel3)
        Me.panelDashboard.Controls.Add(Me.Panel16)
        Me.panelDashboard.Controls.Add(Me.VScrollBar3)
        Me.panelDashboard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDashboard.Location = New System.Drawing.Point(0, 0)
        Me.panelDashboard.Name = "panelDashboard"
        Me.panelDashboard.Size = New System.Drawing.Size(1087, 614)
        Me.panelDashboard.TabIndex = 7
        '
        'Panel3
        '
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(0, 67)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1066, 547)
        Me.Panel3.TabIndex = 5
        '
        'Panel16
        '
        Me.Panel16.Controls.Add(Me.Label9)
        Me.Panel16.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel16.Location = New System.Drawing.Point(0, 0)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(1066, 67)
        Me.Panel16.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label9.Location = New System.Drawing.Point(16, 19)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(145, 29)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Dashboard"
        '
        'VScrollBar3
        '
        Me.VScrollBar3.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar3.Location = New System.Drawing.Point(1066, 0)
        Me.VScrollBar3.Name = "VScrollBar3"
        Me.VScrollBar3.Size = New System.Drawing.Size(21, 614)
        Me.VScrollBar3.TabIndex = 4
        '
        'panelLaporan
        '
        Me.panelLaporan.Controls.Add(Me.Panel10)
        Me.panelLaporan.Controls.Add(Me.Panel11)
        Me.panelLaporan.Controls.Add(Me.VScrollBar4)
        Me.panelLaporan.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelLaporan.Location = New System.Drawing.Point(0, 0)
        Me.panelLaporan.Name = "panelLaporan"
        Me.panelLaporan.Size = New System.Drawing.Size(1087, 614)
        Me.panelLaporan.TabIndex = 8
        '
        'Panel10
        '
        Me.Panel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel10.Location = New System.Drawing.Point(0, 67)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(1066, 547)
        Me.Panel10.TabIndex = 5
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.Label11)
        Me.Panel11.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel11.Location = New System.Drawing.Point(0, 0)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(1066, 67)
        Me.Panel11.TabIndex = 3
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label11.Location = New System.Drawing.Point(16, 19)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(112, 29)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "Laporan"
        '
        'VScrollBar4
        '
        Me.VScrollBar4.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar4.Location = New System.Drawing.Point(1066, 0)
        Me.VScrollBar4.Name = "VScrollBar4"
        Me.VScrollBar4.Size = New System.Drawing.Size(21, 614)
        Me.VScrollBar4.TabIndex = 4
        '
        'panelAkun
        '
        Me.panelAkun.Controls.Add(Me.Panel12)
        Me.panelAkun.Controls.Add(Me.Panel13)
        Me.panelAkun.Controls.Add(Me.VScrollBar5)
        Me.panelAkun.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelAkun.Location = New System.Drawing.Point(0, 0)
        Me.panelAkun.Name = "panelAkun"
        Me.panelAkun.Size = New System.Drawing.Size(1087, 614)
        Me.panelAkun.TabIndex = 9
        '
        'Panel12
        '
        Me.Panel12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel12.Location = New System.Drawing.Point(0, 67)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(1066, 547)
        Me.Panel12.TabIndex = 5
        '
        'Panel13
        '
        Me.Panel13.Controls.Add(Me.Label12)
        Me.Panel13.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel13.Location = New System.Drawing.Point(0, 0)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(1066, 67)
        Me.Panel13.TabIndex = 3
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label12.Location = New System.Drawing.Point(16, 19)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(75, 29)
        Me.Label12.TabIndex = 2
        Me.Label12.Text = "Akun"
        '
        'VScrollBar5
        '
        Me.VScrollBar5.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar5.Location = New System.Drawing.Point(1066, 0)
        Me.VScrollBar5.Name = "VScrollBar5"
        Me.VScrollBar5.Size = New System.Drawing.Size(21, 614)
        Me.VScrollBar5.TabIndex = 4
        '
        'jadwal
        '
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoScroll = True
        Me.FlowLayoutPanel1.Controls.Add(Me.ItemKeranjang2)
        Me.FlowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(231, 48)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(1087, 614)
        Me.FlowLayoutPanel1.TabIndex = 3
        '
        'ItemKeranjang2
        '
        Me.ItemKeranjang2.Dock = System.Windows.Forms.DockStyle.Top
        Me.ItemKeranjang2.ItemCount = 0
        Me.ItemKeranjang2.Location = New System.Drawing.Point(3, 3)
        Me.ItemKeranjang2.Name = "ItemKeranjang2"
        Me.ItemKeranjang2.Size = New System.Drawing.Size(789, 32)
        Me.ItemKeranjang2.TabIndex = 0
        Me.ItemKeranjang2.Title = Nothing
        '
        'ApotekerDashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1318, 662)
        Me.Controls.Add(Me.panelGrup)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Controls.Add(Me.listMenuItem)
        Me.Controls.Add(Me.appBar)
        Me.Name = "ApotekerDashboard"
        Me.Text = "ApotekerDashboard"
        Me.appBar.ResumeLayout(False)
        Me.appBar.PerformLayout()
        CType(Me.showMenuItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.listMenuItem.ResumeLayout(False)
        Me.listMenuItem.PerformLayout()
        CType(Me.pictureObat, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureKeluar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureAkun, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureLaporan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureTransaksi, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picturePasien, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureDashboard, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelGrup.ResumeLayout(False)
        Me.panelDaftarPasien.ResumeLayout(False)
        Me.panelTindakanDP.ResumeLayout(False)
        Me.Panel164.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.Panel25.ResumeLayout(False)
        Me.Panel28.ResumeLayout(False)
        Me.Panel29.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.Panel32.ResumeLayout(False)
        Me.Panel35.ResumeLayout(False)
        Me.Panel35.PerformLayout()
        Me.Panel26.ResumeLayout(False)
        Me.Panel27.ResumeLayout(False)
        Me.panelPengajuanObat.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.DaftarKeranjang.ResumeLayout(False)
        Me.Panel34.ResumeLayout(False)
        Me.Panel37.ResumeLayout(False)
        Me.Panel37.PerformLayout()
        Me.Panel38.ResumeLayout(False)
        Me.Panel39.ResumeLayout(False)
        Me.Panel41.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.Panel43.ResumeLayout(False)
        Me.Panel44.ResumeLayout(False)
        Me.Panel44.PerformLayout()
        Me.Panel84.ResumeLayout(False)
        Me.Panel167.ResumeLayout(False)
        Me.Panel173.ResumeLayout(False)
        Me.Panel173.PerformLayout()
        Me.Panel175.ResumeLayout(False)
        Me.Panel175.PerformLayout()
        Me.Panel177.ResumeLayout(False)
        Me.Panel177.PerformLayout()
        Me.Panel179.ResumeLayout(False)
        Me.Panel179.PerformLayout()
        Me.Panel181.ResumeLayout(False)
        Me.Panel181.PerformLayout()
        Me.Panel183.ResumeLayout(False)
        Me.Panel183.PerformLayout()
        Me.Panel87.ResumeLayout(False)
        Me.Panel87.PerformLayout()
        Me.Panel185.ResumeLayout(False)
        Me.Panel191.ResumeLayout(False)
        Me.Panel191.PerformLayout()
        Me.Panel193.ResumeLayout(False)
        Me.Panel193.PerformLayout()
        Me.Panel195.ResumeLayout(False)
        Me.Panel195.PerformLayout()
        Me.Panel197.ResumeLayout(False)
        Me.Panel197.PerformLayout()
        Me.Panel199.ResumeLayout(False)
        Me.Panel199.PerformLayout()
        Me.Panel201.ResumeLayout(False)
        Me.Panel201.PerformLayout()
        Me.Panel118.ResumeLayout(False)
        Me.Panel118.PerformLayout()
        Me.Panel240.ResumeLayout(False)
        Me.Panel165.ResumeLayout(False)
        Me.Panel165.PerformLayout()
        Me.panelBerandaDP.ResumeLayout(False)
        Me.panelDatabaseDP.ResumeLayout(False)
        CType(Me.dgvDaftarPasien, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelTab.ResumeLayout(False)
        Me.panelTengah.ResumeLayout(False)
        Me.panelTengah.PerformLayout()
        Me.Panel145.ResumeLayout(False)
        Me.Panel146.ResumeLayout(False)
        Me.Panel146.PerformLayout()
        Me.panelKeteranganDP.ResumeLayout(False)
        Me.panelKeteranganDP.PerformLayout()
        Me.panelRiwayatDP.ResumeLayout(False)
        Me.TableLayoutPanel5.ResumeLayout(False)
        Me.TableLayoutPanel5.PerformLayout()
        CType(Me.dgvRiwayatPasien, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel46.ResumeLayout(False)
        Me.Panel47.ResumeLayout(False)
        Me.Panel49.ResumeLayout(False)
        Me.Panel49.PerformLayout()
        Me.Panel51.ResumeLayout(False)
        Me.Panel51.PerformLayout()
        Me.Panel53.ResumeLayout(False)
        Me.Panel53.PerformLayout()
        Me.Panel55.ResumeLayout(False)
        Me.Panel55.PerformLayout()
        Me.Panel57.ResumeLayout(False)
        Me.Panel57.PerformLayout()
        Me.Panel59.ResumeLayout(False)
        Me.Panel59.PerformLayout()
        Me.Panel61.ResumeLayout(False)
        Me.Panel61.PerformLayout()
        Me.Panel63.ResumeLayout(False)
        Me.Panel65.ResumeLayout(False)
        Me.Panel65.PerformLayout()
        Me.Panel67.ResumeLayout(False)
        Me.Panel67.PerformLayout()
        Me.Panel69.ResumeLayout(False)
        Me.Panel69.PerformLayout()
        Me.Panel71.ResumeLayout(False)
        Me.Panel71.PerformLayout()
        Me.Panel73.ResumeLayout(False)
        Me.Panel73.PerformLayout()
        Me.Panel75.ResumeLayout(False)
        Me.Panel75.PerformLayout()
        Me.Panel77.ResumeLayout(False)
        Me.Panel77.PerformLayout()
        Me.Panel79.ResumeLayout(False)
        Me.Panel80.ResumeLayout(False)
        Me.Panel80.PerformLayout()
        Me.panelTransaksi.ResumeLayout(False)
        Me.panelDatabaseTransaksi.ResumeLayout(False)
        Me.TLPNoData.ResumeLayout(False)
        Me.TLPNoData.PerformLayout()
        CType(Me.dgvTransaksiObat, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.panelKeteranganTransaksi.ResumeLayout(False)
        Me.panelKeteranganTransaksi.PerformLayout()
        Me.panelDaftarObat.ResumeLayout(False)
        Me.Panel14.ResumeLayout(False)
        CType(Me.dgvDaftarObat, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFormulirObat.ResumeLayout(False)
        Me.Panel85.ResumeLayout(False)
        Me.Panel99.ResumeLayout(False)
        Me.Panel99.PerformLayout()
        Me.Panel101.ResumeLayout(False)
        Me.Panel101.PerformLayout()
        Me.Panel89.ResumeLayout(False)
        Me.Panel89.PerformLayout()
        Me.Panel103.ResumeLayout(False)
        Me.Panel105.ResumeLayout(False)
        Me.Panel111.ResumeLayout(False)
        Me.Panel117.ResumeLayout(False)
        Me.Panel131.ResumeLayout(False)
        Me.Panel131.PerformLayout()
        Me.Panel133.ResumeLayout(False)
        Me.Panel133.PerformLayout()
        Me.Panel121.ResumeLayout(False)
        Me.Panel121.PerformLayout()
        Me.Panel136.ResumeLayout(False)
        Me.Panel137.ResumeLayout(False)
        Me.Panel137.PerformLayout()
        Me.Panel15.ResumeLayout(False)
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout()
        Me.Panel22.ResumeLayout(False)
        Me.Panel22.PerformLayout()
        Me.panelDashboard.ResumeLayout(False)
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.panelLaporan.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.panelAkun.ResumeLayout(False)
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents appBar As Panel
    Friend WithEvents showMenuItem As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label8 As Label
    Friend WithEvents listMenuItem As Panel
    Friend WithEvents pictureObat As PictureBox
    Friend WithEvents pictureKeluar As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents pictureAkun As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents pictureLaporan As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents pictureTransaksi As PictureBox
    Friend WithEvents Label7 As Label
    Friend WithEvents picturePasien As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents pictureDashboard As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents buttonKeluar As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents buttonAkun As Button
    Friend WithEvents buttonLaporan As Button
    Friend WithEvents buttonTransaksi As Button
    Friend WithEvents buttonDaftar_Pasien As Button
    Friend WithEvents buttonDashboard As Button
    Friend WithEvents buttonDaftar_Obat As Button
    Friend WithEvents panelGrup As Panel
    Friend WithEvents panelDashboard As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel16 As Panel
    Friend WithEvents Label9 As Label
    Friend WithEvents VScrollBar3 As VScrollBar
    Friend WithEvents panelDaftarPasien As Panel
    Friend WithEvents panelDatabaseDP As Panel
    Friend WithEvents dgvDaftarPasien As DataGridView
    Friend WithEvents panelTab As Panel
    Friend WithEvents panelTengah As Panel
    Friend WithEvents btnBelumSelesai As Button
    Friend WithEvents btnSemuaPasien As Button
    Friend WithEvents panelAtas As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents panelKanan As Panel
    Friend WithEvents panelKiri As Panel
    Friend WithEvents panelKeteranganDP As Panel
    Friend WithEvents textKeterangan As Label
    Friend WithEvents VScrollBar1 As VScrollBar
    Friend WithEvents panelTransaksi As Panel
    Friend WithEvents panelDatabaseTransaksi As Panel
    Friend WithEvents dgvTransaksiObat As DataGridView
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents btnBelumBayar As Button
    Friend WithEvents btnSemuaTransaksi As Button
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Panel9 As Panel
    Friend WithEvents panelKeteranganTransaksi As Panel
    Friend WithEvents Label10 As Label
    Friend WithEvents VScrollBar2 As VScrollBar
    Friend WithEvents panelLaporan As Panel
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Label11 As Label
    Friend WithEvents VScrollBar4 As VScrollBar
    Friend WithEvents panelAkun As Panel
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Label12 As Label
    Friend WithEvents VScrollBar5 As VScrollBar
    Friend WithEvents panelDaftarObat As Panel
    Friend WithEvents Panel14 As Panel
    Friend WithEvents dgvDaftarObat As DataGridView
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Panel17 As Panel
    Friend WithEvents btnCariObat As Button
    Friend WithEvents Panel24 As Panel
    Friend WithEvents txtCariNamaObat As TextBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel23 As Panel
    Friend WithEvents Panel18 As Panel
    Friend WithEvents Panel19 As Panel
    Friend WithEvents Panel20 As Panel
    Friend WithEvents Panel21 As Panel
    Friend WithEvents Panel22 As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents VScrollBar6 As VScrollBar
    Friend WithEvents Panel145 As Panel
    Friend WithEvents Panel146 As Panel
    Friend WithEvents txtCariPasien As TextBox
    Friend WithEvents Panel147 As Panel
    Friend WithEvents btnCariPasien As Button
    Friend WithEvents Panel148 As Panel
    Friend WithEvents Panel149 As Panel
    Friend WithEvents Panel150 As Panel
    Friend WithEvents Panel151 As Panel
    Friend WithEvents panelTindakanDP As Panel
    Friend WithEvents Panel164 As Panel
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents btn_IP_PengambilanObat As Button
    Friend WithEvents btn_IP_Batal As Button
    Friend WithEvents Panel26 As Panel
    Friend WithEvents Panel27 As Panel
    Friend WithEvents panelPengajuanObat As Panel
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents Panel33 As Panel
    Friend WithEvents Panel84 As Panel
    Friend WithEvents Panel167 As Panel
    Friend WithEvents Panel170 As Panel
    Friend WithEvents Panel173 As Panel
    Friend WithEvents txt_IP_Faskes As Label
    Friend WithEvents Panel174 As Panel
    Friend WithEvents Panel175 As Panel
    Friend WithEvents txt_IP_Alamat As Label
    Friend WithEvents Panel176 As Panel
    Friend WithEvents Panel177 As Panel
    Friend WithEvents txt_IP_JenisKelamin As Label
    Friend WithEvents Panel178 As Panel
    Friend WithEvents Panel179 As Panel
    Friend WithEvents txt_IP_Umur As Label
    Friend WithEvents Panel180 As Panel
    Friend WithEvents Panel181 As Panel
    Friend WithEvents txt_IP_NamaLengkap As Label
    Friend WithEvents Panel182 As Panel
    Friend WithEvents Panel183 As Panel
    Friend WithEvents txt_IP_UserName As Label
    Friend WithEvents Panel86 As Panel
    Friend WithEvents Panel87 As Panel
    Friend WithEvents txt_IP_NIK As Label
    Friend WithEvents Panel184 As Panel
    Friend WithEvents Panel185 As Panel
    Friend WithEvents Panel188 As Panel
    Friend WithEvents Panel191 As Panel
    Friend WithEvents Label47 As Label
    Friend WithEvents Panel192 As Panel
    Friend WithEvents Panel193 As Panel
    Friend WithEvents Label48 As Label
    Friend WithEvents Panel194 As Panel
    Friend WithEvents Panel195 As Panel
    Friend WithEvents Label49 As Label
    Friend WithEvents Panel196 As Panel
    Friend WithEvents Panel197 As Panel
    Friend WithEvents Label50 As Label
    Friend WithEvents Panel198 As Panel
    Friend WithEvents Panel199 As Panel
    Friend WithEvents Label51 As Label
    Friend WithEvents Panel200 As Panel
    Friend WithEvents Panel201 As Panel
    Friend WithEvents Label52 As Label
    Friend WithEvents Panel119 As Panel
    Friend WithEvents Panel118 As Panel
    Friend WithEvents Label22 As Label
    Friend WithEvents Panel202 As Panel
    Friend WithEvents Panel240 As Panel
    Friend WithEvents Panel165 As Panel
    Friend WithEvents Label45 As Label
    Friend WithEvents btn_IP_Kembali As Button
    Friend WithEvents panelBerandaDP As Panel
    Friend WithEvents txtJadwal As Label
    Friend WithEvents jadwal As Timer
    Friend WithEvents Panel136 As Panel
    Friend WithEvents Panel137 As Panel
    Friend WithEvents btnTambah As Button
    Friend WithEvents Panel138 As Panel
    Friend WithEvents btnEdit As Button
    Friend WithEvents Panel139 As Panel
    Friend WithEvents btnHapus As Button
    Friend WithEvents Panel140 As Panel
    Friend WithEvents btnRefresh As Button
    Friend WithEvents Panel141 As Panel
    Friend WithEvents Panel142 As Panel
    Friend WithEvents Panel143 As Panel
    Friend WithEvents Panel144 As Panel
    Friend WithEvents panelFormulirObat As Panel
    Friend WithEvents Panel85 As Panel
    Friend WithEvents Panel98 As Panel
    Friend WithEvents Panel99 As Panel
    Friend WithEvents txtHargaObat As TextBox
    Friend WithEvents Panel100 As Panel
    Friend WithEvents Panel101 As Panel
    Friend WithEvents txtJumlahObat As TextBox
    Friend WithEvents Panel88 As Panel
    Friend WithEvents Panel89 As Panel
    Friend WithEvents txtNamaObat As TextBox
    Friend WithEvents Panel102 As Panel
    Friend WithEvents Panel103 As Panel
    Friend WithEvents Panel105 As Panel
    Friend WithEvents Panel106 As Panel
    Friend WithEvents Panel107 As Panel
    Friend WithEvents Panel108 As Panel
    Friend WithEvents Panel109 As Panel
    Friend WithEvents btnBatal As Button
    Friend WithEvents Panel111 As Panel
    Friend WithEvents Panel112 As Panel
    Friend WithEvents Panel113 As Panel
    Friend WithEvents Panel114 As Panel
    Friend WithEvents Panel115 As Panel
    Friend WithEvents btnSimpan As Button
    Friend WithEvents Panel117 As Panel
    Friend WithEvents Panel130 As Panel
    Friend WithEvents Panel131 As Panel
    Friend WithEvents Label28 As Label
    Friend WithEvents Panel132 As Panel
    Friend WithEvents Panel133 As Panel
    Friend WithEvents Label29 As Label
    Friend WithEvents Panel120 As Panel
    Friend WithEvents Panel121 As Panel
    Friend WithEvents Label23 As Label
    Friend WithEvents Panel134 As Panel
    Friend WithEvents Panel135 As Panel
    Friend WithEvents Panel25 As Panel
    Friend WithEvents Panel28 As Panel
    Friend WithEvents Panel29 As Panel
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents txt_IP_Obat As Label
    Friend WithEvents Panel31 As Panel
    Friend WithEvents Panel32 As Panel
    Friend WithEvents Panel35 As Panel
    Friend WithEvents Label14 As Label
    Friend WithEvents Panel36 As Panel
    Friend WithEvents Panel34 As Panel
    Friend WithEvents Panel37 As Panel
    Friend WithEvents Label15 As Label
    Friend WithEvents Panel40 As Panel
    Friend WithEvents Panel38 As Panel
    Friend WithEvents Panel39 As Panel
    Friend WithEvents Panel41 As Panel
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents Label16 As Label
    Friend WithEvents Panel42 As Panel
    Friend WithEvents Panel43 As Panel
    Friend WithEvents Panel44 As Panel
    Friend WithEvents Label17 As Label
    Friend WithEvents Panel45 As Panel
    Friend WithEvents TLPNoData As TableLayoutPanel
    Friend WithEvents Label35 As Label
    Friend WithEvents panelRiwayatDP As Panel
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents Label18 As Label
    Friend WithEvents dgvRiwayatPasien As DataGridView
    Friend WithEvents Panel46 As Panel
    Friend WithEvents Panel47 As Panel
    Friend WithEvents Panel48 As Panel
    Friend WithEvents Panel49 As Panel
    Friend WithEvents Label19 As Label
    Friend WithEvents Panel50 As Panel
    Friend WithEvents Panel51 As Panel
    Friend WithEvents Label20 As Label
    Friend WithEvents Panel52 As Panel
    Friend WithEvents Panel53 As Panel
    Friend WithEvents Label21 As Label
    Friend WithEvents Panel54 As Panel
    Friend WithEvents Panel55 As Panel
    Friend WithEvents Label24 As Label
    Friend WithEvents Panel56 As Panel
    Friend WithEvents Panel57 As Panel
    Friend WithEvents Label25 As Label
    Friend WithEvents Panel58 As Panel
    Friend WithEvents Panel59 As Panel
    Friend WithEvents Label26 As Label
    Friend WithEvents Panel60 As Panel
    Friend WithEvents Panel61 As Panel
    Friend WithEvents Label27 As Label
    Friend WithEvents Panel62 As Panel
    Friend WithEvents Panel63 As Panel
    Friend WithEvents Panel64 As Panel
    Friend WithEvents Panel65 As Panel
    Friend WithEvents Label30 As Label
    Friend WithEvents Panel66 As Panel
    Friend WithEvents Panel67 As Panel
    Friend WithEvents Label31 As Label
    Friend WithEvents Panel68 As Panel
    Friend WithEvents Panel69 As Panel
    Friend WithEvents Label32 As Label
    Friend WithEvents Panel70 As Panel
    Friend WithEvents Panel71 As Panel
    Friend WithEvents Label33 As Label
    Friend WithEvents Panel72 As Panel
    Friend WithEvents Panel73 As Panel
    Friend WithEvents Label36 As Label
    Friend WithEvents Panel74 As Panel
    Friend WithEvents Panel75 As Panel
    Friend WithEvents Label37 As Label
    Friend WithEvents Panel76 As Panel
    Friend WithEvents Panel77 As Panel
    Friend WithEvents Label38 As Label
    Friend WithEvents Panel78 As Panel
    Friend WithEvents Panel79 As Panel
    Friend WithEvents Panel80 As Panel
    Friend WithEvents Label39 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents DaftarKeranjang As FlowLayoutPanel
    Friend WithEvents ItemKeranjang1 As ItemKeranjang
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents ItemKeranjang2 As ItemKeranjang
End Class
