﻿Imports System.Data.Odbc
Public Class CustomListViewIK
#Region "Add Items to Table"
    Public Function AddItemsToTable(title As String, itemvalue As Integer) As Boolean
        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If
        'dari Dim readresponseDGV As Object = New Object ke Dim readresponseDGV As String = ""
        Dim readresponseDGV As String = ""
        Dim AddCustomList = New ItemKeranjang()
        Try
            Using cmdd As New OdbcCommand(readresponseDGV, conn)
                cmdd.Parameters.AddWithValue(dr.Item(1), title.Trim())
                cmdd.Parameters.AddWithValue(AddCustomList.ItemObat.Text, itemvalue.ToString().Trim())
                cmdd.ExecuteNonQuery()
            End Using
        Catch
            Throw
        End Try
        Return False
    End Function
#End Region
#Region "Read Items Table"
    Public Function ReadItemsTable() As DataTable
        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If
        Dim cmdi As New OdbcCommand(dr.Item(1), conn)
        Try
            Using sda As New OdbcDataAdapter(cmdi)
                Dim dt As New DataTable()
                sda.Fill(dt)
                Return dt
            End Using
        Catch
            Throw
        End Try
    End Function
#End Region
End Class
