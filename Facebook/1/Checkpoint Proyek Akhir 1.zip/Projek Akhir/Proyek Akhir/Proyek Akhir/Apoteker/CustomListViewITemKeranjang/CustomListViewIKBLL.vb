﻿Public Class CustomListViewIKBLL
#Region "Save Items"
    Public Function SaveItems(title As String, description As String) As Boolean
        Try
            Dim objdal As CustomListViewIK = New CustomListViewIK()
            Return objdal.AddItemsToTable(title, description)
        Catch e As Exception
            Dim result As DialogResult = MessageBox.Show(e.Message.ToString())
            Return False
        End Try
    End Function
#End Region
#Region "Get Items"
    Public Function GetItems() As DataTable
        Try
            Dim objdal As CustomListViewIK = New CustomListViewIK()
            Return objdal.ReadItemsTable()
        Catch e As Exception
            Dim result As DialogResult = MessageBox.Show(e.Message.ToString())
            Return Nothing
        End Try
    End Function
#End Region
End Class
