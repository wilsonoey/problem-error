﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ItemKeranjang
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.NamaItemObat = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.ItemObat = New System.Windows.Forms.DomainUpDown()
        Me.txtAmbangBatas = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'NamaItemObat
        '
        Me.NamaItemObat.AutoSize = True
        Me.NamaItemObat.Location = New System.Drawing.Point(24, 8)
        Me.NamaItemObat.Name = "NamaItemObat"
        Me.NamaItemObat.Size = New System.Drawing.Size(51, 17)
        Me.NamaItemObat.TabIndex = 0
        Me.NamaItemObat.Text = "Label1"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.NamaItemObat)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(465, 32)
        Me.Panel1.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.txtAmbangBatas)
        Me.Panel2.Controls.Add(Me.ItemObat)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(465, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(222, 32)
        Me.Panel2.TabIndex = 3
        '
        'ItemObat
        '
        Me.ItemObat.Location = New System.Drawing.Point(46, 6)
        Me.ItemObat.Name = "ItemObat"
        Me.ItemObat.Size = New System.Drawing.Size(82, 22)
        Me.ItemObat.TabIndex = 0
        '
        'txtAmbangBatas
        '
        Me.txtAmbangBatas.AutoSize = True
        Me.txtAmbangBatas.Location = New System.Drawing.Point(144, 8)
        Me.txtAmbangBatas.Name = "txtAmbangBatas"
        Me.txtAmbangBatas.Size = New System.Drawing.Size(44, 17)
        Me.txtAmbangBatas.TabIndex = 1
        Me.txtAmbangBatas.Text = "Batas"
        Me.txtAmbangBatas.Visible = False
        '
        'ItemKeranjang
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.Name = "ItemKeranjang"
        Me.Size = New System.Drawing.Size(687, 32)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents NamaItemObat As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents ItemObat As DomainUpDown
    Friend WithEvents txtAmbangBatas As Label
End Class
