﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PilihObat
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnPilih = New System.Windows.Forms.Button()
        Me.dgvPilihDaftarObat = New System.Windows.Forms.DataGridView()
        Me.txtCariPilihObat = New System.Windows.Forms.TextBox()
        CType(Me.dgvPilihDaftarObat, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnPilih
        '
        Me.btnPilih.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnPilih.Location = New System.Drawing.Point(0, 347)
        Me.btnPilih.Name = "btnPilih"
        Me.btnPilih.Size = New System.Drawing.Size(858, 33)
        Me.btnPilih.TabIndex = 3
        Me.btnPilih.Text = "Pilih"
        Me.btnPilih.UseVisualStyleBackColor = True
        '
        'dgvPilihDaftarObat
        '
        Me.dgvPilihDaftarObat.AllowUserToAddRows = False
        Me.dgvPilihDaftarObat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvPilihDaftarObat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvPilihDaftarObat.Location = New System.Drawing.Point(0, 22)
        Me.dgvPilihDaftarObat.Name = "dgvPilihDaftarObat"
        Me.dgvPilihDaftarObat.ReadOnly = True
        Me.dgvPilihDaftarObat.RowHeadersWidth = 51
        Me.dgvPilihDaftarObat.RowTemplate.Height = 24
        Me.dgvPilihDaftarObat.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvPilihDaftarObat.Size = New System.Drawing.Size(858, 325)
        Me.dgvPilihDaftarObat.TabIndex = 2
        '
        'txtCariPilihObat
        '
        Me.txtCariPilihObat.Dock = System.Windows.Forms.DockStyle.Top
        Me.txtCariPilihObat.Location = New System.Drawing.Point(0, 0)
        Me.txtCariPilihObat.Name = "txtCariPilihObat"
        Me.txtCariPilihObat.Size = New System.Drawing.Size(858, 22)
        Me.txtCariPilihObat.TabIndex = 1
        '
        'PilihObat
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(858, 380)
        Me.Controls.Add(Me.dgvPilihDaftarObat)
        Me.Controls.Add(Me.txtCariPilihObat)
        Me.Controls.Add(Me.btnPilih)
        Me.Name = "PilihObat"
        Me.Text = "Pilih"
        CType(Me.dgvPilihDaftarObat, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnPilih As Button
    Friend WithEvents dgvPilihDaftarObat As DataGridView
    Friend WithEvents txtCariPilihObat As TextBox
End Class
