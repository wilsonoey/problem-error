﻿Imports System.Data.Odbc

Public Class PilihObat
    Dim id_users As Integer
    Private Sub TampilDataGrid()
        Dim strtampil As String = "SELECT id,namaobat,jumlahobat,hargaobat FROM tb_obat AS a ORDER By namaobat"
        Dim strtabel As String = "tb_obat"
        Call TampilData(strtampil, strtabel)
        dgvPilihDaftarObat.DataSource = (ds.Tables("tb_obat"))
        dgvPilihDaftarObat.ReadOnly = True
    End Sub
    Private Sub JudulGrid()
        dgvPilihDaftarObat.Columns(0).HeaderText = "ID"
        dgvPilihDaftarObat.Columns(1).HeaderText = "Nama Obat"
        dgvPilihDaftarObat.Columns(2).HeaderText = "Jumlah Obat"
        dgvPilihDaftarObat.Columns(3).HeaderText = "Harga Obat"
        dgvPilihDaftarObat.Columns(0).Width = 50
        dgvPilihDaftarObat.Columns(1).Width = 250
        dgvPilihDaftarObat.Columns(2).Width = 150
        dgvPilihDaftarObat.Columns(3).Width = 150
    End Sub
    Private Sub RefreshForm()
        Call Me.TampilDataGrid()
        Call Me.JudulGrid()
        dgvPilihDaftarObat.Focus()
    End Sub

    Private Sub TindakanDaftarObat_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Me.RefreshForm()
    End Sub

    Private Sub txtCariPilihObat_TextChanged(sender As Object, e As EventArgs) Handles txtCariPilihObat.TextChanged
        Dim strtampil As String = "SELECT id,namaobat,jumlahobat,hargaobat FROM tb_obat WHERE namaobat like '%" & txtCariPilihObat.Text & "%' ORDER By namaobat"
        Dim strtabel As String = "tb_obat"
        Call TampilData(strtampil, strtabel)
        dgvPilihDaftarObat.DataSource = (ds.Tables("tb_obat"))
        dgvPilihDaftarObat.ReadOnly = True
    End Sub

    'Public Class Obat
    '    Property Id As Integer
    '    Property Nama As String
    '    Property Jumlahobat As String
    '    Property Hargaobat As Decimal
    'End Class

    'Private Sub btnPilih_Click(sender As Object, e As EventArgs) Handles btnPilih.Click
    '    Dim id = dgvPilihDaftarObat.Rows.Item(dgvPilihDaftarObat.CurrentRow.Index).Cells(0).Value.ToString()

    '    If id = "" Then
    '        MsgBox("Data kosong!", vbInformation, "Pilih Data")

    '    Else
    '        Dim id_barang = CInt(id)
    '        Dim sql = "SELECT namaobat, jumlahobat, hargaobat FROM tb_obat WHERE id = '" & id_barang & "'"

    '        Using conn As New OdbcConnection, cmd As New OdbcCommand(sql, conn)

    '            cmd.Parameters.Add("@id", OdbcType.Int).Value = id_barang
    '            conn.Open()
    '            Dim rdr = cmd.ExecuteReader()

    '            If rdr.Read() Then
    '                Dim d As New Obat() With {.Id = id_barang,
    '                                          .Nama = rdr.GetString(0),
    '                                          .Jumlahobat = rdr.GetString(1),
    '                                          .Hargaobat = rdr.GetDecimal(2)}

    '                'TODO: Add d to whatever collection contains the list of drugs.
    '                Dim listItems As ItemKeranjang() = New ItemKeranjang(sql.Length) {d.Id}
    '                Dim judul As Object() = New Object(sql.Length - 1) {}
    '                Dim i As Integer
    '                For i = 0 To listItems.Length - 1
    '                    If i < judul.Length Then
    '                        listItems(i) = New ItemKeranjang()
    '                        listItems(i).Title = judul(i)
    '                        If i <> 0 Then
    '                            ApotekerDashboard.DaftarKeranjang.Controls.Add(listItems(i))
    '                        End If
    '                    End If
    '                Next
    '                Me.Close()
    '            End If

    '        End Using

    '    End If

    'End Sub

    Private Sub btnpilih_click(sender As Object, e As EventArgs) Handles btnPilih.Click
        Dim sqlcari, sqlnama As String
        Dim id_barang As Integer
        If dgvPilihDaftarObat.Rows.Item(dgvPilihDaftarObat.CurrentRow.Index).Cells(0).Value.ToString = "" Then
            MsgBox("data kosong!", vbInformation, "pilih data")
        Else
            id_barang = dgvPilihDaftarObat.Rows.Item(dgvPilihDaftarObat.CurrentRow.Index).Cells(0).Value
            sqlcari = "SELECT id,namaobat,jumlahobat,hargaobat FROM tb_obat WHERE id = '" & id_barang & "'"
            cmd = New Odbc.OdbcCommand
            cmd.CommandType = CommandType.Text
            cmd.Connection = conn
            cmd.CommandText = sqlcari
            dr = cmd.ExecuteReader()

            If dr.Read Then
                ApotekerDashboard.DaftarKeranjang.Controls.Clear()
                Dim objbll As CustomListViewIKBLL = New CustomListViewIKBLL()
                Dim dta As DataTable = objbll.getitems()
                If dta IsNot Nothing Then
                    If dta.Rows.Count > 0 Then
                        Dim listitems As ItemKeranjang() = New ItemKeranjang(dta.Rows.Count - 1) {}
                        Dim i As Integer
                        For Each row As DataRow In dta.Rows
                            listitems(i) = New ItemKeranjang()
                            listitems(i).title = row(1).ToString()
                            'listitems(i).message = row(2).ToString()
                            If i <> 0 Then ApotekerDashboard.DaftarKeranjang.Controls.Add(listitems(i))
                            i += 1
                        Next
                    End If
                End If
                Me.Close()
            End If
        End If
    End Sub
End Class