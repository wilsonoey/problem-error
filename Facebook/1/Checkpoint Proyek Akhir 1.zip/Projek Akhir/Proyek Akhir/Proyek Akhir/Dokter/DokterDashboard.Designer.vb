﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class DokterDashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(DokterDashboard))
        Me.appBar = New System.Windows.Forms.Panel()
        Me.txtJadwal = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.showMenuItem = New System.Windows.Forms.PictureBox()
        Me.hideMenuItem = New System.Windows.Forms.PictureBox()
        Me.pictureAkun = New System.Windows.Forms.PictureBox()
        Me.listMenuItem = New System.Windows.Forms.Panel()
        Me.pictureKeluar = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pictureLaporan = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.pictureTransaksi = New System.Windows.Forms.PictureBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.picturePasien = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.pictureDashboard = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.buttonKeluar = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.buttonAkun = New System.Windows.Forms.Button()
        Me.buttonLaporan = New System.Windows.Forms.Button()
        Me.buttonTransaksi = New System.Windows.Forms.Button()
        Me.buttonDaftar_Pasien = New System.Windows.Forms.Button()
        Me.buttonDashboard = New System.Windows.Forms.Button()
        Me.panelGrup = New System.Windows.Forms.Panel()
        Me.panelDaftarPasien = New System.Windows.Forms.Panel()
        Me.panelTindakanDP = New System.Windows.Forms.Panel()
        Me.Panel164 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.btn_IP_AjukanApoteker = New System.Windows.Forms.Button()
        Me.btn_IP_Batal = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.txt_IP_Harga = New System.Windows.Forms.TextBox()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.txt_IP_Terapi = New System.Windows.Forms.TextBox()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.txt_IP_Diagnosa = New System.Windows.Forms.TextBox()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel26 = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Panel84 = New System.Windows.Forms.Panel()
        Me.Panel167 = New System.Windows.Forms.Panel()
        Me.Panel170 = New System.Windows.Forms.Panel()
        Me.Panel173 = New System.Windows.Forms.Panel()
        Me.txt_IP_Faskes = New System.Windows.Forms.Label()
        Me.Panel174 = New System.Windows.Forms.Panel()
        Me.Panel175 = New System.Windows.Forms.Panel()
        Me.txt_IP_Alamat = New System.Windows.Forms.Label()
        Me.Panel176 = New System.Windows.Forms.Panel()
        Me.Panel177 = New System.Windows.Forms.Panel()
        Me.txt_IP_JenisKelamin = New System.Windows.Forms.Label()
        Me.Panel178 = New System.Windows.Forms.Panel()
        Me.Panel179 = New System.Windows.Forms.Panel()
        Me.txt_IP_Umur = New System.Windows.Forms.Label()
        Me.Panel180 = New System.Windows.Forms.Panel()
        Me.Panel181 = New System.Windows.Forms.Panel()
        Me.txt_IP_NamaLengkap = New System.Windows.Forms.Label()
        Me.Panel182 = New System.Windows.Forms.Panel()
        Me.Panel183 = New System.Windows.Forms.Panel()
        Me.txt_IP_UserName = New System.Windows.Forms.Label()
        Me.Panel86 = New System.Windows.Forms.Panel()
        Me.Panel87 = New System.Windows.Forms.Panel()
        Me.txt_IP_NIK = New System.Windows.Forms.Label()
        Me.Panel184 = New System.Windows.Forms.Panel()
        Me.Panel185 = New System.Windows.Forms.Panel()
        Me.Panel188 = New System.Windows.Forms.Panel()
        Me.Panel191 = New System.Windows.Forms.Panel()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Panel192 = New System.Windows.Forms.Panel()
        Me.Panel193 = New System.Windows.Forms.Panel()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Panel194 = New System.Windows.Forms.Panel()
        Me.Panel195 = New System.Windows.Forms.Panel()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Panel196 = New System.Windows.Forms.Panel()
        Me.Panel197 = New System.Windows.Forms.Panel()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Panel198 = New System.Windows.Forms.Panel()
        Me.Panel199 = New System.Windows.Forms.Panel()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Panel200 = New System.Windows.Forms.Panel()
        Me.Panel201 = New System.Windows.Forms.Panel()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Panel119 = New System.Windows.Forms.Panel()
        Me.Panel118 = New System.Windows.Forms.Panel()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Panel202 = New System.Windows.Forms.Panel()
        Me.Panel240 = New System.Windows.Forms.Panel()
        Me.Panel165 = New System.Windows.Forms.Panel()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.btn_IP_Kembali = New System.Windows.Forms.Button()
        Me.panelBerandaDP = New System.Windows.Forms.Panel()
        Me.panelDatabaseDP = New System.Windows.Forms.Panel()
        Me.TLPNoData = New System.Windows.Forms.TableLayoutPanel()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.dgvDaftarPasien = New System.Windows.Forms.DataGridView()
        Me.Panel145 = New System.Windows.Forms.Panel()
        Me.Panel146 = New System.Windows.Forms.Panel()
        Me.txtCariPasien = New System.Windows.Forms.TextBox()
        Me.Panel147 = New System.Windows.Forms.Panel()
        Me.btnCariPasien = New System.Windows.Forms.Button()
        Me.Panel148 = New System.Windows.Forms.Panel()
        Me.Panel149 = New System.Windows.Forms.Panel()
        Me.Panel150 = New System.Windows.Forms.Panel()
        Me.Panel151 = New System.Windows.Forms.Panel()
        Me.panelKeteranganDP = New System.Windows.Forms.Panel()
        Me.textKeterangan = New System.Windows.Forms.Label()
        Me.VScrollBar1 = New System.Windows.Forms.VScrollBar()
        Me.panelDashboard = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel35 = New System.Windows.Forms.Panel()
        Me.Panel156 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Panel155 = New System.Windows.Forms.Panel()
        Me.Panel154 = New System.Windows.Forms.Panel()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Panel153 = New System.Windows.Forms.Panel()
        Me.Panel152 = New System.Windows.Forms.Panel()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.VScrollBar3 = New System.Windows.Forms.VScrollBar()
        Me.panelTransaksi = New System.Windows.Forms.Panel()
        Me.panelDatabaseTransaksi = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.btnBelumBayar = New System.Windows.Forms.Button()
        Me.btnSemuaTransaksi = New System.Windows.Forms.Button()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Panel157 = New System.Windows.Forms.Panel()
        Me.Panel158 = New System.Windows.Forms.Panel()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Panel159 = New System.Windows.Forms.Panel()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Panel160 = New System.Windows.Forms.Panel()
        Me.Panel161 = New System.Windows.Forms.Panel()
        Me.Panel162 = New System.Windows.Forms.Panel()
        Me.Panel163 = New System.Windows.Forms.Panel()
        Me.panelKeteranganTransaksi = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.VScrollBar2 = New System.Windows.Forms.VScrollBar()
        Me.panelLaporan = New System.Windows.Forms.Panel()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.VScrollBar4 = New System.Windows.Forms.VScrollBar()
        Me.panelAkun = New System.Windows.Forms.Panel()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.txtNamaPengguna = New System.Windows.Forms.Label()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.VScrollBar5 = New System.Windows.Forms.VScrollBar()
        Me.jadwal = New System.Windows.Forms.Timer(Me.components)
        Me.panelRiwayatDP = New System.Windows.Forms.Panel()
        Me.Panel79 = New System.Windows.Forms.Panel()
        Me.Panel80 = New System.Windows.Forms.Panel()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Panel63 = New System.Windows.Forms.Panel()
        Me.Panel78 = New System.Windows.Forms.Panel()
        Me.Panel77 = New System.Windows.Forms.Panel()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Panel76 = New System.Windows.Forms.Panel()
        Me.Panel75 = New System.Windows.Forms.Panel()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Panel74 = New System.Windows.Forms.Panel()
        Me.Panel73 = New System.Windows.Forms.Panel()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Panel72 = New System.Windows.Forms.Panel()
        Me.Panel71 = New System.Windows.Forms.Panel()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Panel70 = New System.Windows.Forms.Panel()
        Me.Panel69 = New System.Windows.Forms.Panel()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Panel68 = New System.Windows.Forms.Panel()
        Me.Panel67 = New System.Windows.Forms.Panel()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Panel66 = New System.Windows.Forms.Panel()
        Me.Panel65 = New System.Windows.Forms.Panel()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Panel64 = New System.Windows.Forms.Panel()
        Me.Panel47 = New System.Windows.Forms.Panel()
        Me.Panel62 = New System.Windows.Forms.Panel()
        Me.Panel61 = New System.Windows.Forms.Panel()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Panel60 = New System.Windows.Forms.Panel()
        Me.Panel59 = New System.Windows.Forms.Panel()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Panel58 = New System.Windows.Forms.Panel()
        Me.Panel57 = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Panel56 = New System.Windows.Forms.Panel()
        Me.Panel55 = New System.Windows.Forms.Panel()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Panel54 = New System.Windows.Forms.Panel()
        Me.Panel53 = New System.Windows.Forms.Panel()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Panel52 = New System.Windows.Forms.Panel()
        Me.Panel51 = New System.Windows.Forms.Panel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Panel50 = New System.Windows.Forms.Panel()
        Me.Panel49 = New System.Windows.Forms.Panel()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Panel48 = New System.Windows.Forms.Panel()
        Me.Panel46 = New System.Windows.Forms.Panel()
        Me.dgvRiwayatPasien = New System.Windows.Forms.DataGridView()
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.appBar.SuspendLayout()
        CType(Me.showMenuItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.hideMenuItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureAkun, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.listMenuItem.SuspendLayout()
        CType(Me.pictureKeluar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureLaporan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureTransaksi, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picturePasien, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureDashboard, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelGrup.SuspendLayout()
        Me.panelDaftarPasien.SuspendLayout()
        Me.panelTindakanDP.SuspendLayout()
        Me.Panel164.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.Panel27.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.Panel23.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.Panel22.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel26.SuspendLayout()
        Me.Panel20.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.Panel84.SuspendLayout()
        Me.Panel167.SuspendLayout()
        Me.Panel173.SuspendLayout()
        Me.Panel175.SuspendLayout()
        Me.Panel177.SuspendLayout()
        Me.Panel179.SuspendLayout()
        Me.Panel181.SuspendLayout()
        Me.Panel183.SuspendLayout()
        Me.Panel87.SuspendLayout()
        Me.Panel185.SuspendLayout()
        Me.Panel191.SuspendLayout()
        Me.Panel193.SuspendLayout()
        Me.Panel195.SuspendLayout()
        Me.Panel197.SuspendLayout()
        Me.Panel199.SuspendLayout()
        Me.Panel201.SuspendLayout()
        Me.Panel118.SuspendLayout()
        Me.Panel240.SuspendLayout()
        Me.Panel165.SuspendLayout()
        Me.panelBerandaDP.SuspendLayout()
        Me.panelDatabaseDP.SuspendLayout()
        Me.TLPNoData.SuspendLayout()
        CType(Me.dgvDaftarPasien, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel145.SuspendLayout()
        Me.Panel146.SuspendLayout()
        Me.panelKeteranganDP.SuspendLayout()
        Me.panelDashboard.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel35.SuspendLayout()
        Me.Panel156.SuspendLayout()
        Me.Panel154.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.panelTransaksi.SuspendLayout()
        Me.panelDatabaseTransaksi.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel157.SuspendLayout()
        Me.Panel158.SuspendLayout()
        Me.panelKeteranganTransaksi.SuspendLayout()
        Me.panelLaporan.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.panelAkun.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.panelRiwayatDP.SuspendLayout()
        Me.Panel79.SuspendLayout()
        Me.Panel80.SuspendLayout()
        Me.Panel63.SuspendLayout()
        Me.Panel77.SuspendLayout()
        Me.Panel75.SuspendLayout()
        Me.Panel73.SuspendLayout()
        Me.Panel71.SuspendLayout()
        Me.Panel69.SuspendLayout()
        Me.Panel67.SuspendLayout()
        Me.Panel65.SuspendLayout()
        Me.Panel47.SuspendLayout()
        Me.Panel61.SuspendLayout()
        Me.Panel59.SuspendLayout()
        Me.Panel57.SuspendLayout()
        Me.Panel55.SuspendLayout()
        Me.Panel53.SuspendLayout()
        Me.Panel51.SuspendLayout()
        Me.Panel49.SuspendLayout()
        Me.Panel46.SuspendLayout()
        CType(Me.dgvRiwayatPasien, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel5.SuspendLayout()
        Me.SuspendLayout()
        '
        'appBar
        '
        Me.appBar.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.appBar.Controls.Add(Me.txtJadwal)
        Me.appBar.Controls.Add(Me.Label8)
        Me.appBar.Controls.Add(Me.showMenuItem)
        Me.appBar.Controls.Add(Me.hideMenuItem)
        Me.appBar.Dock = System.Windows.Forms.DockStyle.Top
        Me.appBar.Location = New System.Drawing.Point(0, 0)
        Me.appBar.Name = "appBar"
        Me.appBar.Size = New System.Drawing.Size(911, 48)
        Me.appBar.TabIndex = 0
        '
        'txtJadwal
        '
        Me.txtJadwal.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtJadwal.AutoSize = True
        Me.txtJadwal.Location = New System.Drawing.Point(750, 15)
        Me.txtJadwal.Name = "txtJadwal"
        Me.txtJadwal.Size = New System.Drawing.Size(108, 17)
        Me.txtJadwal.TabIndex = 4
        Me.txtJadwal.Text = "Tanggal, Waktu"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(65, 8)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(104, 32)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Dokter"
        '
        'showMenuItem
        '
        Me.showMenuItem.BackgroundImage = CType(resources.GetObject("showMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.showMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.showMenuItem.Location = New System.Drawing.Point(12, 6)
        Me.showMenuItem.Name = "showMenuItem"
        Me.showMenuItem.Size = New System.Drawing.Size(38, 33)
        Me.showMenuItem.TabIndex = 0
        Me.showMenuItem.TabStop = False
        '
        'hideMenuItem
        '
        Me.hideMenuItem.BackgroundImage = CType(resources.GetObject("hideMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.hideMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.hideMenuItem.Location = New System.Drawing.Point(12, 6)
        Me.hideMenuItem.Name = "hideMenuItem"
        Me.hideMenuItem.Size = New System.Drawing.Size(38, 33)
        Me.hideMenuItem.TabIndex = 0
        Me.hideMenuItem.TabStop = False
        '
        'pictureAkun
        '
        Me.pictureAkun.BackgroundImage = CType(resources.GetObject("pictureAkun.BackgroundImage"), System.Drawing.Image)
        Me.pictureAkun.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureAkun.Location = New System.Drawing.Point(13, 275)
        Me.pictureAkun.Name = "pictureAkun"
        Me.pictureAkun.Size = New System.Drawing.Size(50, 50)
        Me.pictureAkun.TabIndex = 0
        Me.pictureAkun.TabStop = False
        '
        'listMenuItem
        '
        Me.listMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.listMenuItem.Controls.Add(Me.pictureKeluar)
        Me.listMenuItem.Controls.Add(Me.pictureAkun)
        Me.listMenuItem.Controls.Add(Me.Label3)
        Me.listMenuItem.Controls.Add(Me.pictureLaporan)
        Me.listMenuItem.Controls.Add(Me.Label5)
        Me.listMenuItem.Controls.Add(Me.pictureTransaksi)
        Me.listMenuItem.Controls.Add(Me.Label7)
        Me.listMenuItem.Controls.Add(Me.picturePasien)
        Me.listMenuItem.Controls.Add(Me.Label6)
        Me.listMenuItem.Controls.Add(Me.pictureDashboard)
        Me.listMenuItem.Controls.Add(Me.Label2)
        Me.listMenuItem.Controls.Add(Me.buttonKeluar)
        Me.listMenuItem.Controls.Add(Me.Label1)
        Me.listMenuItem.Controls.Add(Me.buttonAkun)
        Me.listMenuItem.Controls.Add(Me.buttonLaporan)
        Me.listMenuItem.Controls.Add(Me.buttonTransaksi)
        Me.listMenuItem.Controls.Add(Me.buttonDaftar_Pasien)
        Me.listMenuItem.Controls.Add(Me.buttonDashboard)
        Me.listMenuItem.Dock = System.Windows.Forms.DockStyle.Left
        Me.listMenuItem.Location = New System.Drawing.Point(0, 48)
        Me.listMenuItem.Name = "listMenuItem"
        Me.listMenuItem.Size = New System.Drawing.Size(231, 581)
        Me.listMenuItem.TabIndex = 1
        '
        'pictureKeluar
        '
        Me.pictureKeluar.BackgroundImage = CType(resources.GetObject("pictureKeluar.BackgroundImage"), System.Drawing.Image)
        Me.pictureKeluar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureKeluar.Location = New System.Drawing.Point(13, 342)
        Me.pictureKeluar.Name = "pictureKeluar"
        Me.pictureKeluar.Size = New System.Drawing.Size(50, 50)
        Me.pictureKeluar.TabIndex = 0
        Me.pictureKeluar.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(66, 356)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 29)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Keluar"
        '
        'pictureLaporan
        '
        Me.pictureLaporan.BackgroundImage = CType(resources.GetObject("pictureLaporan.BackgroundImage"), System.Drawing.Image)
        Me.pictureLaporan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureLaporan.Location = New System.Drawing.Point(13, 208)
        Me.pictureLaporan.Name = "pictureLaporan"
        Me.pictureLaporan.Size = New System.Drawing.Size(50, 50)
        Me.pictureLaporan.TabIndex = 0
        Me.pictureLaporan.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(66, 285)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 29)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Akun"
        '
        'pictureTransaksi
        '
        Me.pictureTransaksi.BackgroundImage = CType(resources.GetObject("pictureTransaksi.BackgroundImage"), System.Drawing.Image)
        Me.pictureTransaksi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureTransaksi.Location = New System.Drawing.Point(13, 141)
        Me.pictureTransaksi.Name = "pictureTransaksi"
        Me.pictureTransaksi.Size = New System.Drawing.Size(50, 50)
        Me.pictureTransaksi.TabIndex = 0
        Me.pictureTransaksi.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(66, 219)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(101, 29)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Laporan"
        '
        'picturePasien
        '
        Me.picturePasien.BackgroundImage = CType(resources.GetObject("picturePasien.BackgroundImage"), System.Drawing.Image)
        Me.picturePasien.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picturePasien.Location = New System.Drawing.Point(13, 76)
        Me.picturePasien.Name = "picturePasien"
        Me.picturePasien.Size = New System.Drawing.Size(50, 50)
        Me.picturePasien.TabIndex = 0
        Me.picturePasien.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(66, 151)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(118, 29)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Transaksi"
        '
        'pictureDashboard
        '
        Me.pictureDashboard.BackgroundImage = CType(resources.GetObject("pictureDashboard.BackgroundImage"), System.Drawing.Image)
        Me.pictureDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureDashboard.Location = New System.Drawing.Point(13, 8)
        Me.pictureDashboard.Name = "pictureDashboard"
        Me.pictureDashboard.Size = New System.Drawing.Size(50, 50)
        Me.pictureDashboard.TabIndex = 0
        Me.pictureDashboard.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(66, 88)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(156, 29)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Daftar Pasien"
        '
        'buttonKeluar
        '
        Me.buttonKeluar.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonKeluar.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonKeluar.Location = New System.Drawing.Point(0, 335)
        Me.buttonKeluar.Name = "buttonKeluar"
        Me.buttonKeluar.Size = New System.Drawing.Size(231, 67)
        Me.buttonKeluar.TabIndex = 3
        Me.buttonKeluar.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(66, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(131, 29)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Dashboard"
        '
        'buttonAkun
        '
        Me.buttonAkun.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonAkun.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonAkun.Location = New System.Drawing.Point(0, 268)
        Me.buttonAkun.Name = "buttonAkun"
        Me.buttonAkun.Size = New System.Drawing.Size(231, 67)
        Me.buttonAkun.TabIndex = 3
        Me.buttonAkun.UseVisualStyleBackColor = False
        '
        'buttonLaporan
        '
        Me.buttonLaporan.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonLaporan.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonLaporan.Location = New System.Drawing.Point(0, 201)
        Me.buttonLaporan.Name = "buttonLaporan"
        Me.buttonLaporan.Size = New System.Drawing.Size(231, 67)
        Me.buttonLaporan.TabIndex = 3
        Me.buttonLaporan.UseVisualStyleBackColor = False
        '
        'buttonTransaksi
        '
        Me.buttonTransaksi.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonTransaksi.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonTransaksi.Location = New System.Drawing.Point(0, 134)
        Me.buttonTransaksi.Name = "buttonTransaksi"
        Me.buttonTransaksi.Size = New System.Drawing.Size(231, 67)
        Me.buttonTransaksi.TabIndex = 3
        Me.buttonTransaksi.UseVisualStyleBackColor = False
        '
        'buttonDaftar_Pasien
        '
        Me.buttonDaftar_Pasien.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonDaftar_Pasien.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonDaftar_Pasien.Location = New System.Drawing.Point(0, 67)
        Me.buttonDaftar_Pasien.Name = "buttonDaftar_Pasien"
        Me.buttonDaftar_Pasien.Size = New System.Drawing.Size(231, 67)
        Me.buttonDaftar_Pasien.TabIndex = 3
        Me.buttonDaftar_Pasien.UseVisualStyleBackColor = False
        '
        'buttonDashboard
        '
        Me.buttonDashboard.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonDashboard.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonDashboard.Location = New System.Drawing.Point(0, 0)
        Me.buttonDashboard.Name = "buttonDashboard"
        Me.buttonDashboard.Size = New System.Drawing.Size(231, 67)
        Me.buttonDashboard.TabIndex = 3
        Me.buttonDashboard.UseVisualStyleBackColor = False
        '
        'panelGrup
        '
        Me.panelGrup.Controls.Add(Me.panelDaftarPasien)
        Me.panelGrup.Controls.Add(Me.panelDashboard)
        Me.panelGrup.Controls.Add(Me.panelTransaksi)
        Me.panelGrup.Controls.Add(Me.panelLaporan)
        Me.panelGrup.Controls.Add(Me.panelAkun)
        Me.panelGrup.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelGrup.Location = New System.Drawing.Point(231, 48)
        Me.panelGrup.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelGrup.Name = "panelGrup"
        Me.panelGrup.Size = New System.Drawing.Size(680, 581)
        Me.panelGrup.TabIndex = 2
        '
        'panelDaftarPasien
        '
        Me.panelDaftarPasien.Controls.Add(Me.panelBerandaDP)
        Me.panelDaftarPasien.Controls.Add(Me.panelTindakanDP)
        Me.panelDaftarPasien.Controls.Add(Me.panelRiwayatDP)
        Me.panelDaftarPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDaftarPasien.Location = New System.Drawing.Point(0, 0)
        Me.panelDaftarPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDaftarPasien.Name = "panelDaftarPasien"
        Me.panelDaftarPasien.Size = New System.Drawing.Size(680, 581)
        Me.panelDaftarPasien.TabIndex = 3
        '
        'panelTindakanDP
        '
        Me.panelTindakanDP.Controls.Add(Me.Panel164)
        Me.panelTindakanDP.Controls.Add(Me.Panel1)
        Me.panelTindakanDP.Controls.Add(Me.Panel84)
        Me.panelTindakanDP.Controls.Add(Me.Panel240)
        Me.panelTindakanDP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelTindakanDP.Location = New System.Drawing.Point(0, 0)
        Me.panelTindakanDP.Name = "panelTindakanDP"
        Me.panelTindakanDP.Size = New System.Drawing.Size(680, 581)
        Me.panelTindakanDP.TabIndex = 4
        '
        'Panel164
        '
        Me.Panel164.Controls.Add(Me.TableLayoutPanel2)
        Me.Panel164.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel164.Location = New System.Drawing.Point(0, 534)
        Me.Panel164.Name = "Panel164"
        Me.Panel164.Size = New System.Drawing.Size(680, 41)
        Me.Panel164.TabIndex = 4
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 5
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.btn_IP_AjukanApoteker, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.btn_IP_Batal, 3, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(680, 41)
        Me.TableLayoutPanel2.TabIndex = 1
        '
        'btn_IP_AjukanApoteker
        '
        Me.btn_IP_AjukanApoteker.Location = New System.Drawing.Point(140, 3)
        Me.btn_IP_AjukanApoteker.Name = "btn_IP_AjukanApoteker"
        Me.btn_IP_AjukanApoteker.Size = New System.Drawing.Size(194, 35)
        Me.btn_IP_AjukanApoteker.TabIndex = 0
        Me.btn_IP_AjukanApoteker.Text = "Ajukan ke Apoteker"
        Me.btn_IP_AjukanApoteker.UseVisualStyleBackColor = True
        '
        'btn_IP_Batal
        '
        Me.btn_IP_Batal.Location = New System.Drawing.Point(345, 3)
        Me.btn_IP_Batal.Name = "btn_IP_Batal"
        Me.btn_IP_Batal.Size = New System.Drawing.Size(194, 35)
        Me.btn_IP_Batal.TabIndex = 0
        Me.btn_IP_Batal.Text = "Batal"
        Me.btn_IP_Batal.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Panel14)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 329)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(680, 205)
        Me.Panel1.TabIndex = 5
        '
        'Panel14
        '
        Me.Panel14.Controls.Add(Me.Panel27)
        Me.Panel14.Controls.Add(Me.Panel25)
        Me.Panel14.Controls.Add(Me.Panel23)
        Me.Panel14.Controls.Add(Me.Panel21)
        Me.Panel14.Controls.Add(Me.Panel22)
        Me.Panel14.Controls.Add(Me.Panel19)
        Me.Panel14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel14.Location = New System.Drawing.Point(175, 0)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(505, 205)
        Me.Panel14.TabIndex = 0
        '
        'Panel27
        '
        Me.Panel27.Controls.Add(Me.TableLayoutPanel4)
        Me.Panel27.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel27.Location = New System.Drawing.Point(0, 165)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(505, 30)
        Me.Panel27.TabIndex = 6
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 3
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.txt_IP_Harga, 1, 0)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 1
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(505, 30)
        Me.TableLayoutPanel4.TabIndex = 1
        '
        'txt_IP_Harga
        '
        Me.txt_IP_Harga.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_IP_Harga.Location = New System.Drawing.Point(13, 3)
        Me.txt_IP_Harga.Multiline = True
        Me.txt_IP_Harga.Name = "txt_IP_Harga"
        Me.txt_IP_Harga.Size = New System.Drawing.Size(479, 24)
        Me.txt_IP_Harga.TabIndex = 0
        '
        'Panel25
        '
        Me.Panel25.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel25.Location = New System.Drawing.Point(0, 150)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(505, 15)
        Me.Panel25.TabIndex = 5
        '
        'Panel23
        '
        Me.Panel23.Controls.Add(Me.TableLayoutPanel3)
        Me.Panel23.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel23.Location = New System.Drawing.Point(0, 90)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(505, 60)
        Me.Panel23.TabIndex = 4
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 3
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.txt_IP_Terapi, 1, 1)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 3
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(505, 60)
        Me.TableLayoutPanel3.TabIndex = 0
        '
        'txt_IP_Terapi
        '
        Me.txt_IP_Terapi.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_IP_Terapi.Location = New System.Drawing.Point(13, 13)
        Me.txt_IP_Terapi.Multiline = True
        Me.txt_IP_Terapi.Name = "txt_IP_Terapi"
        Me.txt_IP_Terapi.Size = New System.Drawing.Size(479, 34)
        Me.txt_IP_Terapi.TabIndex = 0
        '
        'Panel21
        '
        Me.Panel21.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel21.Location = New System.Drawing.Point(0, 75)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(505, 15)
        Me.Panel21.TabIndex = 3
        '
        'Panel22
        '
        Me.Panel22.Controls.Add(Me.TableLayoutPanel1)
        Me.Panel22.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel22.Location = New System.Drawing.Point(0, 15)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(505, 60)
        Me.Panel22.TabIndex = 3
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.txt_IP_Diagnosa, 1, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(505, 60)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'txt_IP_Diagnosa
        '
        Me.txt_IP_Diagnosa.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_IP_Diagnosa.Location = New System.Drawing.Point(13, 13)
        Me.txt_IP_Diagnosa.Multiline = True
        Me.txt_IP_Diagnosa.Name = "txt_IP_Diagnosa"
        Me.txt_IP_Diagnosa.Size = New System.Drawing.Size(479, 34)
        Me.txt_IP_Diagnosa.TabIndex = 0
        '
        'Panel19
        '
        Me.Panel19.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel19.Location = New System.Drawing.Point(0, 0)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(505, 15)
        Me.Panel19.TabIndex = 2
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Panel26)
        Me.Panel2.Controls.Add(Me.Panel24)
        Me.Panel2.Controls.Add(Me.Panel20)
        Me.Panel2.Controls.Add(Me.Panel18)
        Me.Panel2.Controls.Add(Me.Panel17)
        Me.Panel2.Controls.Add(Me.Panel15)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(175, 205)
        Me.Panel2.TabIndex = 0
        '
        'Panel26
        '
        Me.Panel26.Controls.Add(Me.Label14)
        Me.Panel26.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel26.Location = New System.Drawing.Point(0, 165)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(175, 30)
        Me.Panel26.TabIndex = 5
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label14.Location = New System.Drawing.Point(0, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(116, 17)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Harga Konsultasi"
        '
        'Panel24
        '
        Me.Panel24.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel24.Location = New System.Drawing.Point(0, 150)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(175, 15)
        Me.Panel24.TabIndex = 4
        '
        'Panel20
        '
        Me.Panel20.Controls.Add(Me.Label13)
        Me.Panel20.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel20.Location = New System.Drawing.Point(0, 90)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(175, 60)
        Me.Panel20.TabIndex = 3
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(0, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(92, 17)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Terapi / Obat"
        '
        'Panel18
        '
        Me.Panel18.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel18.Location = New System.Drawing.Point(0, 75)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(175, 15)
        Me.Panel18.TabIndex = 2
        '
        'Panel17
        '
        Me.Panel17.Controls.Add(Me.Label12)
        Me.Panel17.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel17.Location = New System.Drawing.Point(0, 15)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(175, 60)
        Me.Panel17.TabIndex = 1
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label12.Location = New System.Drawing.Point(0, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(68, 17)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Diagnosa"
        '
        'Panel15
        '
        Me.Panel15.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel15.Location = New System.Drawing.Point(0, 0)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(175, 15)
        Me.Panel15.TabIndex = 0
        '
        'Panel84
        '
        Me.Panel84.Controls.Add(Me.Panel167)
        Me.Panel84.Controls.Add(Me.Panel185)
        Me.Panel84.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel84.Location = New System.Drawing.Point(0, 66)
        Me.Panel84.Name = "Panel84"
        Me.Panel84.Size = New System.Drawing.Size(680, 263)
        Me.Panel84.TabIndex = 4
        '
        'Panel167
        '
        Me.Panel167.Controls.Add(Me.Panel170)
        Me.Panel167.Controls.Add(Me.Panel173)
        Me.Panel167.Controls.Add(Me.Panel174)
        Me.Panel167.Controls.Add(Me.Panel175)
        Me.Panel167.Controls.Add(Me.Panel176)
        Me.Panel167.Controls.Add(Me.Panel177)
        Me.Panel167.Controls.Add(Me.Panel178)
        Me.Panel167.Controls.Add(Me.Panel179)
        Me.Panel167.Controls.Add(Me.Panel180)
        Me.Panel167.Controls.Add(Me.Panel181)
        Me.Panel167.Controls.Add(Me.Panel182)
        Me.Panel167.Controls.Add(Me.Panel183)
        Me.Panel167.Controls.Add(Me.Panel86)
        Me.Panel167.Controls.Add(Me.Panel87)
        Me.Panel167.Controls.Add(Me.Panel184)
        Me.Panel167.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel167.Location = New System.Drawing.Point(175, 0)
        Me.Panel167.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel167.Name = "Panel167"
        Me.Panel167.Size = New System.Drawing.Size(505, 263)
        Me.Panel167.TabIndex = 1
        '
        'Panel170
        '
        Me.Panel170.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel170.Location = New System.Drawing.Point(0, 252)
        Me.Panel170.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel170.Name = "Panel170"
        Me.Panel170.Size = New System.Drawing.Size(505, 11)
        Me.Panel170.TabIndex = 30
        '
        'Panel173
        '
        Me.Panel173.Controls.Add(Me.txt_IP_Faskes)
        Me.Panel173.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel173.Location = New System.Drawing.Point(0, 227)
        Me.Panel173.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel173.Name = "Panel173"
        Me.Panel173.Size = New System.Drawing.Size(505, 25)
        Me.Panel173.TabIndex = 27
        '
        'txt_IP_Faskes
        '
        Me.txt_IP_Faskes.AutoSize = True
        Me.txt_IP_Faskes.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_Faskes.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_Faskes.Name = "txt_IP_Faskes"
        Me.txt_IP_Faskes.Size = New System.Drawing.Size(53, 17)
        Me.txt_IP_Faskes.TabIndex = 1
        Me.txt_IP_Faskes.Text = "Faskes"
        '
        'Panel174
        '
        Me.Panel174.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel174.Location = New System.Drawing.Point(0, 216)
        Me.Panel174.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel174.Name = "Panel174"
        Me.Panel174.Size = New System.Drawing.Size(505, 11)
        Me.Panel174.TabIndex = 25
        '
        'Panel175
        '
        Me.Panel175.Controls.Add(Me.txt_IP_Alamat)
        Me.Panel175.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel175.Location = New System.Drawing.Point(0, 191)
        Me.Panel175.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel175.Name = "Panel175"
        Me.Panel175.Size = New System.Drawing.Size(505, 25)
        Me.Panel175.TabIndex = 24
        '
        'txt_IP_Alamat
        '
        Me.txt_IP_Alamat.AutoSize = True
        Me.txt_IP_Alamat.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_Alamat.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_Alamat.Name = "txt_IP_Alamat"
        Me.txt_IP_Alamat.Size = New System.Drawing.Size(51, 17)
        Me.txt_IP_Alamat.TabIndex = 1
        Me.txt_IP_Alamat.Text = "Alamat"
        '
        'Panel176
        '
        Me.Panel176.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel176.Location = New System.Drawing.Point(0, 180)
        Me.Panel176.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel176.Name = "Panel176"
        Me.Panel176.Size = New System.Drawing.Size(505, 11)
        Me.Panel176.TabIndex = 23
        '
        'Panel177
        '
        Me.Panel177.Controls.Add(Me.txt_IP_JenisKelamin)
        Me.Panel177.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel177.Location = New System.Drawing.Point(0, 155)
        Me.Panel177.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel177.Name = "Panel177"
        Me.Panel177.Size = New System.Drawing.Size(505, 25)
        Me.Panel177.TabIndex = 22
        '
        'txt_IP_JenisKelamin
        '
        Me.txt_IP_JenisKelamin.AutoSize = True
        Me.txt_IP_JenisKelamin.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_JenisKelamin.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_JenisKelamin.Name = "txt_IP_JenisKelamin"
        Me.txt_IP_JenisKelamin.Size = New System.Drawing.Size(95, 17)
        Me.txt_IP_JenisKelamin.TabIndex = 1
        Me.txt_IP_JenisKelamin.Text = "Jenis Kelamin"
        '
        'Panel178
        '
        Me.Panel178.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel178.Location = New System.Drawing.Point(0, 144)
        Me.Panel178.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel178.Name = "Panel178"
        Me.Panel178.Size = New System.Drawing.Size(505, 11)
        Me.Panel178.TabIndex = 21
        '
        'Panel179
        '
        Me.Panel179.Controls.Add(Me.txt_IP_Umur)
        Me.Panel179.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel179.Location = New System.Drawing.Point(0, 119)
        Me.Panel179.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel179.Name = "Panel179"
        Me.Panel179.Size = New System.Drawing.Size(505, 25)
        Me.Panel179.TabIndex = 20
        '
        'txt_IP_Umur
        '
        Me.txt_IP_Umur.AutoSize = True
        Me.txt_IP_Umur.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_Umur.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_Umur.Name = "txt_IP_Umur"
        Me.txt_IP_Umur.Size = New System.Drawing.Size(42, 17)
        Me.txt_IP_Umur.TabIndex = 1
        Me.txt_IP_Umur.Text = "Umur"
        '
        'Panel180
        '
        Me.Panel180.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel180.Location = New System.Drawing.Point(0, 108)
        Me.Panel180.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel180.Name = "Panel180"
        Me.Panel180.Size = New System.Drawing.Size(505, 11)
        Me.Panel180.TabIndex = 19
        '
        'Panel181
        '
        Me.Panel181.Controls.Add(Me.txt_IP_NamaLengkap)
        Me.Panel181.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel181.Location = New System.Drawing.Point(0, 83)
        Me.Panel181.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel181.Name = "Panel181"
        Me.Panel181.Size = New System.Drawing.Size(505, 25)
        Me.Panel181.TabIndex = 18
        '
        'txt_IP_NamaLengkap
        '
        Me.txt_IP_NamaLengkap.AutoSize = True
        Me.txt_IP_NamaLengkap.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_NamaLengkap.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_NamaLengkap.Name = "txt_IP_NamaLengkap"
        Me.txt_IP_NamaLengkap.Size = New System.Drawing.Size(104, 17)
        Me.txt_IP_NamaLengkap.TabIndex = 2
        Me.txt_IP_NamaLengkap.Text = "Nama Lengkap"
        '
        'Panel182
        '
        Me.Panel182.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel182.Location = New System.Drawing.Point(0, 72)
        Me.Panel182.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel182.Name = "Panel182"
        Me.Panel182.Size = New System.Drawing.Size(505, 11)
        Me.Panel182.TabIndex = 17
        '
        'Panel183
        '
        Me.Panel183.Controls.Add(Me.txt_IP_UserName)
        Me.Panel183.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel183.Location = New System.Drawing.Point(0, 47)
        Me.Panel183.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel183.Name = "Panel183"
        Me.Panel183.Size = New System.Drawing.Size(505, 25)
        Me.Panel183.TabIndex = 16
        '
        'txt_IP_UserName
        '
        Me.txt_IP_UserName.AutoSize = True
        Me.txt_IP_UserName.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_UserName.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_UserName.Name = "txt_IP_UserName"
        Me.txt_IP_UserName.Size = New System.Drawing.Size(79, 17)
        Me.txt_IP_UserName.TabIndex = 3
        Me.txt_IP_UserName.Text = "User Name"
        '
        'Panel86
        '
        Me.Panel86.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel86.Location = New System.Drawing.Point(0, 36)
        Me.Panel86.Name = "Panel86"
        Me.Panel86.Size = New System.Drawing.Size(505, 11)
        Me.Panel86.TabIndex = 31
        '
        'Panel87
        '
        Me.Panel87.Controls.Add(Me.txt_IP_NIK)
        Me.Panel87.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel87.Location = New System.Drawing.Point(0, 11)
        Me.Panel87.Name = "Panel87"
        Me.Panel87.Size = New System.Drawing.Size(505, 25)
        Me.Panel87.TabIndex = 31
        '
        'txt_IP_NIK
        '
        Me.txt_IP_NIK.AutoSize = True
        Me.txt_IP_NIK.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_NIK.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_NIK.Name = "txt_IP_NIK"
        Me.txt_IP_NIK.Size = New System.Drawing.Size(30, 17)
        Me.txt_IP_NIK.TabIndex = 0
        Me.txt_IP_NIK.Text = "NIK"
        '
        'Panel184
        '
        Me.Panel184.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel184.Location = New System.Drawing.Point(0, 0)
        Me.Panel184.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel184.Name = "Panel184"
        Me.Panel184.Size = New System.Drawing.Size(505, 11)
        Me.Panel184.TabIndex = 15
        '
        'Panel185
        '
        Me.Panel185.Controls.Add(Me.Panel188)
        Me.Panel185.Controls.Add(Me.Panel191)
        Me.Panel185.Controls.Add(Me.Panel192)
        Me.Panel185.Controls.Add(Me.Panel193)
        Me.Panel185.Controls.Add(Me.Panel194)
        Me.Panel185.Controls.Add(Me.Panel195)
        Me.Panel185.Controls.Add(Me.Panel196)
        Me.Panel185.Controls.Add(Me.Panel197)
        Me.Panel185.Controls.Add(Me.Panel198)
        Me.Panel185.Controls.Add(Me.Panel199)
        Me.Panel185.Controls.Add(Me.Panel200)
        Me.Panel185.Controls.Add(Me.Panel201)
        Me.Panel185.Controls.Add(Me.Panel119)
        Me.Panel185.Controls.Add(Me.Panel118)
        Me.Panel185.Controls.Add(Me.Panel202)
        Me.Panel185.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel185.Location = New System.Drawing.Point(0, 0)
        Me.Panel185.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel185.Name = "Panel185"
        Me.Panel185.Size = New System.Drawing.Size(175, 263)
        Me.Panel185.TabIndex = 1
        '
        'Panel188
        '
        Me.Panel188.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel188.Location = New System.Drawing.Point(0, 252)
        Me.Panel188.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel188.Name = "Panel188"
        Me.Panel188.Size = New System.Drawing.Size(175, 11)
        Me.Panel188.TabIndex = 30
        '
        'Panel191
        '
        Me.Panel191.Controls.Add(Me.Label47)
        Me.Panel191.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel191.Location = New System.Drawing.Point(0, 227)
        Me.Panel191.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel191.Name = "Panel191"
        Me.Panel191.Size = New System.Drawing.Size(175, 25)
        Me.Panel191.TabIndex = 27
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label47.Location = New System.Drawing.Point(0, 0)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(53, 17)
        Me.Label47.TabIndex = 1
        Me.Label47.Text = "Faskes"
        '
        'Panel192
        '
        Me.Panel192.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel192.Location = New System.Drawing.Point(0, 216)
        Me.Panel192.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel192.Name = "Panel192"
        Me.Panel192.Size = New System.Drawing.Size(175, 11)
        Me.Panel192.TabIndex = 25
        '
        'Panel193
        '
        Me.Panel193.Controls.Add(Me.Label48)
        Me.Panel193.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel193.Location = New System.Drawing.Point(0, 191)
        Me.Panel193.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel193.Name = "Panel193"
        Me.Panel193.Size = New System.Drawing.Size(175, 25)
        Me.Panel193.TabIndex = 24
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label48.Location = New System.Drawing.Point(0, 0)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(51, 17)
        Me.Label48.TabIndex = 1
        Me.Label48.Text = "Alamat"
        '
        'Panel194
        '
        Me.Panel194.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel194.Location = New System.Drawing.Point(0, 180)
        Me.Panel194.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel194.Name = "Panel194"
        Me.Panel194.Size = New System.Drawing.Size(175, 11)
        Me.Panel194.TabIndex = 23
        '
        'Panel195
        '
        Me.Panel195.Controls.Add(Me.Label49)
        Me.Panel195.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel195.Location = New System.Drawing.Point(0, 155)
        Me.Panel195.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel195.Name = "Panel195"
        Me.Panel195.Size = New System.Drawing.Size(175, 25)
        Me.Panel195.TabIndex = 22
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label49.Location = New System.Drawing.Point(0, 0)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(95, 17)
        Me.Label49.TabIndex = 1
        Me.Label49.Text = "Jenis Kelamin"
        '
        'Panel196
        '
        Me.Panel196.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel196.Location = New System.Drawing.Point(0, 144)
        Me.Panel196.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel196.Name = "Panel196"
        Me.Panel196.Size = New System.Drawing.Size(175, 11)
        Me.Panel196.TabIndex = 21
        '
        'Panel197
        '
        Me.Panel197.Controls.Add(Me.Label50)
        Me.Panel197.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel197.Location = New System.Drawing.Point(0, 119)
        Me.Panel197.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel197.Name = "Panel197"
        Me.Panel197.Size = New System.Drawing.Size(175, 25)
        Me.Panel197.TabIndex = 20
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label50.Location = New System.Drawing.Point(0, 0)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(42, 17)
        Me.Label50.TabIndex = 1
        Me.Label50.Text = "Umur"
        '
        'Panel198
        '
        Me.Panel198.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel198.Location = New System.Drawing.Point(0, 108)
        Me.Panel198.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel198.Name = "Panel198"
        Me.Panel198.Size = New System.Drawing.Size(175, 11)
        Me.Panel198.TabIndex = 19
        '
        'Panel199
        '
        Me.Panel199.Controls.Add(Me.Label51)
        Me.Panel199.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel199.Location = New System.Drawing.Point(0, 83)
        Me.Panel199.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel199.Name = "Panel199"
        Me.Panel199.Size = New System.Drawing.Size(175, 25)
        Me.Panel199.TabIndex = 18
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label51.Location = New System.Drawing.Point(0, 0)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(104, 17)
        Me.Label51.TabIndex = 2
        Me.Label51.Text = "Nama Lengkap"
        '
        'Panel200
        '
        Me.Panel200.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel200.Location = New System.Drawing.Point(0, 72)
        Me.Panel200.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel200.Name = "Panel200"
        Me.Panel200.Size = New System.Drawing.Size(175, 11)
        Me.Panel200.TabIndex = 17
        '
        'Panel201
        '
        Me.Panel201.Controls.Add(Me.Label52)
        Me.Panel201.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel201.Location = New System.Drawing.Point(0, 47)
        Me.Panel201.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel201.Name = "Panel201"
        Me.Panel201.Size = New System.Drawing.Size(175, 25)
        Me.Panel201.TabIndex = 16
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label52.Location = New System.Drawing.Point(0, 0)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(79, 17)
        Me.Label52.TabIndex = 3
        Me.Label52.Text = "User Name"
        '
        'Panel119
        '
        Me.Panel119.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel119.Location = New System.Drawing.Point(0, 36)
        Me.Panel119.Name = "Panel119"
        Me.Panel119.Size = New System.Drawing.Size(175, 11)
        Me.Panel119.TabIndex = 32
        '
        'Panel118
        '
        Me.Panel118.Controls.Add(Me.Label22)
        Me.Panel118.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel118.Location = New System.Drawing.Point(0, 11)
        Me.Panel118.Name = "Panel118"
        Me.Panel118.Size = New System.Drawing.Size(175, 25)
        Me.Panel118.TabIndex = 31
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label22.Location = New System.Drawing.Point(0, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(30, 17)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "NIK"
        '
        'Panel202
        '
        Me.Panel202.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel202.Location = New System.Drawing.Point(0, 0)
        Me.Panel202.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel202.Name = "Panel202"
        Me.Panel202.Size = New System.Drawing.Size(175, 11)
        Me.Panel202.TabIndex = 15
        '
        'Panel240
        '
        Me.Panel240.Controls.Add(Me.Panel165)
        Me.Panel240.Controls.Add(Me.btn_IP_Kembali)
        Me.Panel240.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel240.Location = New System.Drawing.Point(0, 0)
        Me.Panel240.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel240.Name = "Panel240"
        Me.Panel240.Size = New System.Drawing.Size(680, 66)
        Me.Panel240.TabIndex = 3
        '
        'Panel165
        '
        Me.Panel165.Controls.Add(Me.Label45)
        Me.Panel165.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel165.Location = New System.Drawing.Point(75, 0)
        Me.Panel165.Name = "Panel165"
        Me.Panel165.Size = New System.Drawing.Size(605, 66)
        Me.Panel165.TabIndex = 3
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label45.Location = New System.Drawing.Point(16, 18)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(150, 29)
        Me.Label45.TabIndex = 2
        Me.Label45.Text = "Info Pasien"
        '
        'btn_IP_Kembali
        '
        Me.btn_IP_Kembali.BackgroundImage = CType(resources.GetObject("btn_IP_Kembali.BackgroundImage"), System.Drawing.Image)
        Me.btn_IP_Kembali.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btn_IP_Kembali.Dock = System.Windows.Forms.DockStyle.Left
        Me.btn_IP_Kembali.Location = New System.Drawing.Point(0, 0)
        Me.btn_IP_Kembali.Name = "btn_IP_Kembali"
        Me.btn_IP_Kembali.Size = New System.Drawing.Size(75, 66)
        Me.btn_IP_Kembali.TabIndex = 4
        Me.btn_IP_Kembali.UseVisualStyleBackColor = True
        '
        'panelBerandaDP
        '
        Me.panelBerandaDP.Controls.Add(Me.panelDatabaseDP)
        Me.panelBerandaDP.Controls.Add(Me.Panel145)
        Me.panelBerandaDP.Controls.Add(Me.panelKeteranganDP)
        Me.panelBerandaDP.Controls.Add(Me.VScrollBar1)
        Me.panelBerandaDP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelBerandaDP.Location = New System.Drawing.Point(0, 0)
        Me.panelBerandaDP.Name = "panelBerandaDP"
        Me.panelBerandaDP.Size = New System.Drawing.Size(680, 581)
        Me.panelBerandaDP.TabIndex = 3
        '
        'panelDatabaseDP
        '
        Me.panelDatabaseDP.Controls.Add(Me.TLPNoData)
        Me.panelDatabaseDP.Controls.Add(Me.dgvDaftarPasien)
        Me.panelDatabaseDP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDatabaseDP.Location = New System.Drawing.Point(0, 128)
        Me.panelDatabaseDP.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDatabaseDP.Name = "panelDatabaseDP"
        Me.panelDatabaseDP.Size = New System.Drawing.Size(659, 453)
        Me.panelDatabaseDP.TabIndex = 5
        '
        'TLPNoData
        '
        Me.TLPNoData.ColumnCount = 1
        Me.TLPNoData.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLPNoData.Controls.Add(Me.Label35, 0, 0)
        Me.TLPNoData.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLPNoData.Location = New System.Drawing.Point(0, 0)
        Me.TLPNoData.Name = "TLPNoData"
        Me.TLPNoData.RowCount = 1
        Me.TLPNoData.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLPNoData.Size = New System.Drawing.Size(659, 453)
        Me.TLPNoData.TabIndex = 2
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label35.Location = New System.Drawing.Point(3, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(653, 453)
        Me.Label35.TabIndex = 0
        Me.Label35.Text = "No Data"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'dgvDaftarPasien
        '
        Me.dgvDaftarPasien.AllowUserToAddRows = False
        Me.dgvDaftarPasien.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgvDaftarPasien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDaftarPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvDaftarPasien.GridColor = System.Drawing.SystemColors.Control
        Me.dgvDaftarPasien.Location = New System.Drawing.Point(0, 0)
        Me.dgvDaftarPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgvDaftarPasien.Name = "dgvDaftarPasien"
        Me.dgvDaftarPasien.ReadOnly = True
        Me.dgvDaftarPasien.RowHeadersWidth = 51
        Me.dgvDaftarPasien.RowTemplate.Height = 24
        Me.dgvDaftarPasien.Size = New System.Drawing.Size(659, 453)
        Me.dgvDaftarPasien.TabIndex = 1
        '
        'Panel145
        '
        Me.Panel145.Controls.Add(Me.Panel146)
        Me.Panel145.Controls.Add(Me.Panel150)
        Me.Panel145.Controls.Add(Me.Panel151)
        Me.Panel145.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel145.Location = New System.Drawing.Point(0, 66)
        Me.Panel145.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel145.Name = "Panel145"
        Me.Panel145.Size = New System.Drawing.Size(659, 62)
        Me.Panel145.TabIndex = 0
        '
        'Panel146
        '
        Me.Panel146.Controls.Add(Me.txtCariPasien)
        Me.Panel146.Controls.Add(Me.Panel147)
        Me.Panel146.Controls.Add(Me.btnCariPasien)
        Me.Panel146.Controls.Add(Me.Panel148)
        Me.Panel146.Controls.Add(Me.Panel149)
        Me.Panel146.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel146.Location = New System.Drawing.Point(25, 0)
        Me.Panel146.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel146.Name = "Panel146"
        Me.Panel146.Size = New System.Drawing.Size(609, 62)
        Me.Panel146.TabIndex = 2
        '
        'txtCariPasien
        '
        Me.txtCariPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtCariPasien.Location = New System.Drawing.Point(0, 15)
        Me.txtCariPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtCariPasien.Multiline = True
        Me.txtCariPasien.Name = "txtCariPasien"
        Me.txtCariPasien.Size = New System.Drawing.Size(449, 32)
        Me.txtCariPasien.TabIndex = 0
        '
        'Panel147
        '
        Me.Panel147.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel147.Location = New System.Drawing.Point(449, 15)
        Me.Panel147.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel147.Name = "Panel147"
        Me.Panel147.Size = New System.Drawing.Size(29, 32)
        Me.Panel147.TabIndex = 7
        '
        'btnCariPasien
        '
        Me.btnCariPasien.AutoSize = True
        Me.btnCariPasien.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnCariPasien.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnCariPasien.FlatAppearance.BorderSize = 2
        Me.btnCariPasien.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCariPasien.Location = New System.Drawing.Point(478, 15)
        Me.btnCariPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCariPasien.Name = "btnCariPasien"
        Me.btnCariPasien.Size = New System.Drawing.Size(131, 32)
        Me.btnCariPasien.TabIndex = 1
        Me.btnCariPasien.Text = "Cari"
        Me.btnCariPasien.UseVisualStyleBackColor = True
        '
        'Panel148
        '
        Me.Panel148.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel148.Location = New System.Drawing.Point(0, 0)
        Me.Panel148.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel148.Name = "Panel148"
        Me.Panel148.Size = New System.Drawing.Size(609, 15)
        Me.Panel148.TabIndex = 2
        '
        'Panel149
        '
        Me.Panel149.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel149.Location = New System.Drawing.Point(0, 47)
        Me.Panel149.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel149.Name = "Panel149"
        Me.Panel149.Size = New System.Drawing.Size(609, 15)
        Me.Panel149.TabIndex = 3
        '
        'Panel150
        '
        Me.Panel150.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel150.Location = New System.Drawing.Point(634, 0)
        Me.Panel150.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel150.Name = "Panel150"
        Me.Panel150.Size = New System.Drawing.Size(25, 62)
        Me.Panel150.TabIndex = 1
        '
        'Panel151
        '
        Me.Panel151.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel151.Location = New System.Drawing.Point(0, 0)
        Me.Panel151.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel151.Name = "Panel151"
        Me.Panel151.Size = New System.Drawing.Size(25, 62)
        Me.Panel151.TabIndex = 0
        '
        'panelKeteranganDP
        '
        Me.panelKeteranganDP.Controls.Add(Me.textKeterangan)
        Me.panelKeteranganDP.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelKeteranganDP.Location = New System.Drawing.Point(0, 0)
        Me.panelKeteranganDP.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelKeteranganDP.Name = "panelKeteranganDP"
        Me.panelKeteranganDP.Size = New System.Drawing.Size(659, 66)
        Me.panelKeteranganDP.TabIndex = 3
        '
        'textKeterangan
        '
        Me.textKeterangan.AutoSize = True
        Me.textKeterangan.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.textKeterangan.Location = New System.Drawing.Point(16, 18)
        Me.textKeterangan.Name = "textKeterangan"
        Me.textKeterangan.Size = New System.Drawing.Size(179, 29)
        Me.textKeterangan.TabIndex = 2
        Me.textKeterangan.Text = "Daftar Pasien"
        '
        'VScrollBar1
        '
        Me.VScrollBar1.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar1.Location = New System.Drawing.Point(659, 0)
        Me.VScrollBar1.Name = "VScrollBar1"
        Me.VScrollBar1.Size = New System.Drawing.Size(21, 581)
        Me.VScrollBar1.TabIndex = 4
        '
        'panelDashboard
        '
        Me.panelDashboard.Controls.Add(Me.Panel3)
        Me.panelDashboard.Controls.Add(Me.Panel16)
        Me.panelDashboard.Controls.Add(Me.VScrollBar3)
        Me.panelDashboard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDashboard.Location = New System.Drawing.Point(0, 0)
        Me.panelDashboard.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDashboard.Name = "panelDashboard"
        Me.panelDashboard.Size = New System.Drawing.Size(680, 581)
        Me.panelDashboard.TabIndex = 7
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Panel35)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(0, 66)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(659, 515)
        Me.Panel3.TabIndex = 5
        '
        'Panel35
        '
        Me.Panel35.Controls.Add(Me.Panel156)
        Me.Panel35.Controls.Add(Me.Panel155)
        Me.Panel35.Controls.Add(Me.Panel154)
        Me.Panel35.Controls.Add(Me.Panel153)
        Me.Panel35.Controls.Add(Me.Panel152)
        Me.Panel35.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel35.Location = New System.Drawing.Point(0, 0)
        Me.Panel35.Name = "Panel35"
        Me.Panel35.Size = New System.Drawing.Size(659, 105)
        Me.Panel35.TabIndex = 1
        '
        'Panel156
        '
        Me.Panel156.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel156.Controls.Add(Me.Label33)
        Me.Panel156.Controls.Add(Me.Label32)
        Me.Panel156.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel156.Location = New System.Drawing.Point(365, 0)
        Me.Panel156.Name = "Panel156"
        Me.Panel156.Size = New System.Drawing.Size(180, 105)
        Me.Panel156.TabIndex = 3
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(28, 62)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(127, 29)
        Me.Label33.TabIndex = 0
        Me.Label33.Text = "Kunjungan"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(75, 7)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(42, 46)
        Me.Label32.TabIndex = 0
        Me.Label32.Text = "0"
        '
        'Panel155
        '
        Me.Panel155.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel155.Location = New System.Drawing.Point(295, 0)
        Me.Panel155.Name = "Panel155"
        Me.Panel155.Size = New System.Drawing.Size(70, 105)
        Me.Panel155.TabIndex = 2
        '
        'Panel154
        '
        Me.Panel154.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel154.Controls.Add(Me.Label31)
        Me.Panel154.Controls.Add(Me.Label30)
        Me.Panel154.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel154.Location = New System.Drawing.Point(115, 0)
        Me.Panel154.Name = "Panel154"
        Me.Panel154.Size = New System.Drawing.Size(180, 105)
        Me.Panel154.TabIndex = 2
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(43, 64)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(87, 29)
        Me.Label31.TabIndex = 0
        Me.Label31.Text = "Pasien"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(66, 9)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(42, 46)
        Me.Label30.TabIndex = 0
        Me.Label30.Text = "0"
        '
        'Panel153
        '
        Me.Panel153.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel153.Location = New System.Drawing.Point(544, 0)
        Me.Panel153.Name = "Panel153"
        Me.Panel153.Size = New System.Drawing.Size(115, 105)
        Me.Panel153.TabIndex = 1
        '
        'Panel152
        '
        Me.Panel152.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel152.Location = New System.Drawing.Point(0, 0)
        Me.Panel152.Name = "Panel152"
        Me.Panel152.Size = New System.Drawing.Size(115, 105)
        Me.Panel152.TabIndex = 0
        '
        'Panel16
        '
        Me.Panel16.Controls.Add(Me.Label9)
        Me.Panel16.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel16.Location = New System.Drawing.Point(0, 0)
        Me.Panel16.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(659, 66)
        Me.Panel16.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label9.Location = New System.Drawing.Point(16, 18)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(145, 29)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Dashboard"
        '
        'VScrollBar3
        '
        Me.VScrollBar3.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar3.Location = New System.Drawing.Point(659, 0)
        Me.VScrollBar3.Name = "VScrollBar3"
        Me.VScrollBar3.Size = New System.Drawing.Size(21, 581)
        Me.VScrollBar3.TabIndex = 4
        '
        'panelTransaksi
        '
        Me.panelTransaksi.Controls.Add(Me.panelDatabaseTransaksi)
        Me.panelTransaksi.Controls.Add(Me.panelKeteranganTransaksi)
        Me.panelTransaksi.Controls.Add(Me.VScrollBar2)
        Me.panelTransaksi.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelTransaksi.Location = New System.Drawing.Point(0, 0)
        Me.panelTransaksi.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelTransaksi.Name = "panelTransaksi"
        Me.panelTransaksi.Size = New System.Drawing.Size(680, 581)
        Me.panelTransaksi.TabIndex = 6
        '
        'panelDatabaseTransaksi
        '
        Me.panelDatabaseTransaksi.Controls.Add(Me.DataGridView1)
        Me.panelDatabaseTransaksi.Controls.Add(Me.Panel4)
        Me.panelDatabaseTransaksi.Controls.Add(Me.Panel157)
        Me.panelDatabaseTransaksi.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDatabaseTransaksi.Location = New System.Drawing.Point(0, 66)
        Me.panelDatabaseTransaksi.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDatabaseTransaksi.Name = "panelDatabaseTransaksi"
        Me.panelDatabaseTransaksi.Size = New System.Drawing.Size(659, 515)
        Me.panelDatabaseTransaksi.TabIndex = 5
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.Location = New System.Drawing.Point(0, 124)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(659, 391)
        Me.DataGridView1.TabIndex = 1
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Panel5)
        Me.Panel4.Controls.Add(Me.Panel8)
        Me.Panel4.Controls.Add(Me.Panel9)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 62)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(659, 62)
        Me.Panel4.TabIndex = 0
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.btnBelumBayar)
        Me.Panel5.Controls.Add(Me.btnSemuaTransaksi)
        Me.Panel5.Controls.Add(Me.Panel6)
        Me.Panel5.Controls.Add(Me.Panel7)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel5.Location = New System.Drawing.Point(200, 0)
        Me.Panel5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(259, 62)
        Me.Panel5.TabIndex = 2
        '
        'btnBelumBayar
        '
        Me.btnBelumBayar.AutoSize = True
        Me.btnBelumBayar.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnBelumBayar.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnBelumBayar.FlatAppearance.BorderSize = 2
        Me.btnBelumBayar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBelumBayar.Location = New System.Drawing.Point(0, 15)
        Me.btnBelumBayar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBelumBayar.Name = "btnBelumBayar"
        Me.btnBelumBayar.Size = New System.Drawing.Size(131, 32)
        Me.btnBelumBayar.TabIndex = 1
        Me.btnBelumBayar.Text = "Belum Membayar"
        Me.btnBelumBayar.UseVisualStyleBackColor = True
        '
        'btnSemuaTransaksi
        '
        Me.btnSemuaTransaksi.AutoSize = True
        Me.btnSemuaTransaksi.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnSemuaTransaksi.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnSemuaTransaksi.FlatAppearance.BorderSize = 2
        Me.btnSemuaTransaksi.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSemuaTransaksi.Location = New System.Drawing.Point(128, 15)
        Me.btnSemuaTransaksi.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSemuaTransaksi.Name = "btnSemuaTransaksi"
        Me.btnSemuaTransaksi.Size = New System.Drawing.Size(131, 32)
        Me.btnSemuaTransaksi.TabIndex = 4
        Me.btnSemuaTransaksi.Text = "Semua"
        Me.btnSemuaTransaksi.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel6.Location = New System.Drawing.Point(0, 0)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(259, 15)
        Me.Panel6.TabIndex = 2
        '
        'Panel7
        '
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel7.Location = New System.Drawing.Point(0, 47)
        Me.Panel7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(259, 15)
        Me.Panel7.TabIndex = 3
        '
        'Panel8
        '
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel8.Location = New System.Drawing.Point(459, 0)
        Me.Panel8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(200, 62)
        Me.Panel8.TabIndex = 1
        '
        'Panel9
        '
        Me.Panel9.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel9.Location = New System.Drawing.Point(0, 0)
        Me.Panel9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(200, 62)
        Me.Panel9.TabIndex = 0
        '
        'Panel157
        '
        Me.Panel157.Controls.Add(Me.Panel158)
        Me.Panel157.Controls.Add(Me.Panel162)
        Me.Panel157.Controls.Add(Me.Panel163)
        Me.Panel157.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel157.Location = New System.Drawing.Point(0, 0)
        Me.Panel157.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel157.Name = "Panel157"
        Me.Panel157.Size = New System.Drawing.Size(659, 62)
        Me.Panel157.TabIndex = 2
        '
        'Panel158
        '
        Me.Panel158.Controls.Add(Me.TextBox8)
        Me.Panel158.Controls.Add(Me.Panel159)
        Me.Panel158.Controls.Add(Me.Button8)
        Me.Panel158.Controls.Add(Me.Panel160)
        Me.Panel158.Controls.Add(Me.Panel161)
        Me.Panel158.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel158.Location = New System.Drawing.Point(25, 0)
        Me.Panel158.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel158.Name = "Panel158"
        Me.Panel158.Size = New System.Drawing.Size(609, 62)
        Me.Panel158.TabIndex = 2
        '
        'TextBox8
        '
        Me.TextBox8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox8.Location = New System.Drawing.Point(0, 15)
        Me.TextBox8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox8.Multiline = True
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(449, 32)
        Me.TextBox8.TabIndex = 0
        '
        'Panel159
        '
        Me.Panel159.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel159.Location = New System.Drawing.Point(449, 15)
        Me.Panel159.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel159.Name = "Panel159"
        Me.Panel159.Size = New System.Drawing.Size(29, 32)
        Me.Panel159.TabIndex = 7
        '
        'Button8
        '
        Me.Button8.AutoSize = True
        Me.Button8.Dock = System.Windows.Forms.DockStyle.Right
        Me.Button8.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.Button8.FlatAppearance.BorderSize = 2
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Location = New System.Drawing.Point(478, 15)
        Me.Button8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(131, 32)
        Me.Button8.TabIndex = 1
        Me.Button8.Text = "Cari"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Panel160
        '
        Me.Panel160.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel160.Location = New System.Drawing.Point(0, 0)
        Me.Panel160.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel160.Name = "Panel160"
        Me.Panel160.Size = New System.Drawing.Size(609, 15)
        Me.Panel160.TabIndex = 2
        '
        'Panel161
        '
        Me.Panel161.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel161.Location = New System.Drawing.Point(0, 47)
        Me.Panel161.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel161.Name = "Panel161"
        Me.Panel161.Size = New System.Drawing.Size(609, 15)
        Me.Panel161.TabIndex = 3
        '
        'Panel162
        '
        Me.Panel162.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel162.Location = New System.Drawing.Point(634, 0)
        Me.Panel162.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel162.Name = "Panel162"
        Me.Panel162.Size = New System.Drawing.Size(25, 62)
        Me.Panel162.TabIndex = 1
        '
        'Panel163
        '
        Me.Panel163.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel163.Location = New System.Drawing.Point(0, 0)
        Me.Panel163.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel163.Name = "Panel163"
        Me.Panel163.Size = New System.Drawing.Size(25, 62)
        Me.Panel163.TabIndex = 0
        '
        'panelKeteranganTransaksi
        '
        Me.panelKeteranganTransaksi.Controls.Add(Me.Label4)
        Me.panelKeteranganTransaksi.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelKeteranganTransaksi.Location = New System.Drawing.Point(0, 0)
        Me.panelKeteranganTransaksi.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelKeteranganTransaksi.Name = "panelKeteranganTransaksi"
        Me.panelKeteranganTransaksi.Size = New System.Drawing.Size(659, 66)
        Me.panelKeteranganTransaksi.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label4.Location = New System.Drawing.Point(16, 18)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(132, 29)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Transaksi"
        '
        'VScrollBar2
        '
        Me.VScrollBar2.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar2.Location = New System.Drawing.Point(659, 0)
        Me.VScrollBar2.Name = "VScrollBar2"
        Me.VScrollBar2.Size = New System.Drawing.Size(21, 581)
        Me.VScrollBar2.TabIndex = 4
        '
        'panelLaporan
        '
        Me.panelLaporan.Controls.Add(Me.Panel10)
        Me.panelLaporan.Controls.Add(Me.Panel11)
        Me.panelLaporan.Controls.Add(Me.VScrollBar4)
        Me.panelLaporan.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelLaporan.Location = New System.Drawing.Point(0, 0)
        Me.panelLaporan.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelLaporan.Name = "panelLaporan"
        Me.panelLaporan.Size = New System.Drawing.Size(680, 581)
        Me.panelLaporan.TabIndex = 8
        '
        'Panel10
        '
        Me.Panel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel10.Location = New System.Drawing.Point(0, 66)
        Me.Panel10.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(659, 515)
        Me.Panel10.TabIndex = 5
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.Label10)
        Me.Panel11.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel11.Location = New System.Drawing.Point(0, 0)
        Me.Panel11.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(659, 66)
        Me.Panel11.TabIndex = 3
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label10.Location = New System.Drawing.Point(16, 18)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(112, 29)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Laporan"
        '
        'VScrollBar4
        '
        Me.VScrollBar4.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar4.Location = New System.Drawing.Point(659, 0)
        Me.VScrollBar4.Name = "VScrollBar4"
        Me.VScrollBar4.Size = New System.Drawing.Size(21, 581)
        Me.VScrollBar4.TabIndex = 4
        '
        'panelAkun
        '
        Me.panelAkun.Controls.Add(Me.Panel12)
        Me.panelAkun.Controls.Add(Me.Panel13)
        Me.panelAkun.Controls.Add(Me.VScrollBar5)
        Me.panelAkun.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelAkun.Location = New System.Drawing.Point(0, 0)
        Me.panelAkun.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelAkun.Name = "panelAkun"
        Me.panelAkun.Size = New System.Drawing.Size(680, 581)
        Me.panelAkun.TabIndex = 9
        '
        'Panel12
        '
        Me.Panel12.Controls.Add(Me.Label34)
        Me.Panel12.Controls.Add(Me.txtNamaPengguna)
        Me.Panel12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel12.Location = New System.Drawing.Point(0, 66)
        Me.Panel12.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(659, 515)
        Me.Panel12.TabIndex = 5
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(20, 75)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(178, 29)
        Me.Label34.TabIndex = 0
        Me.Label34.Text = "Kota Pengguna"
        '
        'txtNamaPengguna
        '
        Me.txtNamaPengguna.AutoSize = True
        Me.txtNamaPengguna.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNamaPengguna.Location = New System.Drawing.Point(16, 21)
        Me.txtNamaPengguna.Name = "txtNamaPengguna"
        Me.txtNamaPengguna.Size = New System.Drawing.Size(193, 29)
        Me.txtNamaPengguna.TabIndex = 0
        Me.txtNamaPengguna.Text = "Nama Pengguna"
        '
        'Panel13
        '
        Me.Panel13.Controls.Add(Me.Label11)
        Me.Panel13.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel13.Location = New System.Drawing.Point(0, 0)
        Me.Panel13.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(659, 66)
        Me.Panel13.TabIndex = 3
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label11.Location = New System.Drawing.Point(16, 18)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(75, 29)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "Akun"
        '
        'VScrollBar5
        '
        Me.VScrollBar5.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar5.Location = New System.Drawing.Point(659, 0)
        Me.VScrollBar5.Name = "VScrollBar5"
        Me.VScrollBar5.Size = New System.Drawing.Size(21, 581)
        Me.VScrollBar5.TabIndex = 4
        '
        'jadwal
        '
        '
        'panelRiwayatDP
        '
        Me.panelRiwayatDP.Controls.Add(Me.TableLayoutPanel5)
        Me.panelRiwayatDP.Controls.Add(Me.dgvRiwayatPasien)
        Me.panelRiwayatDP.Controls.Add(Me.Panel46)
        Me.panelRiwayatDP.Controls.Add(Me.Panel79)
        Me.panelRiwayatDP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelRiwayatDP.Location = New System.Drawing.Point(0, 0)
        Me.panelRiwayatDP.Name = "panelRiwayatDP"
        Me.panelRiwayatDP.Size = New System.Drawing.Size(680, 581)
        Me.panelRiwayatDP.TabIndex = 5
        '
        'Panel79
        '
        Me.Panel79.Controls.Add(Me.Panel80)
        Me.Panel79.Controls.Add(Me.Button3)
        Me.Panel79.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel79.Location = New System.Drawing.Point(0, 0)
        Me.Panel79.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel79.Name = "Panel79"
        Me.Panel79.Size = New System.Drawing.Size(680, 66)
        Me.Panel79.TabIndex = 3
        '
        'Panel80
        '
        Me.Panel80.Controls.Add(Me.Label39)
        Me.Panel80.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel80.Location = New System.Drawing.Point(75, 0)
        Me.Panel80.Name = "Panel80"
        Me.Panel80.Size = New System.Drawing.Size(605, 66)
        Me.Panel80.TabIndex = 3
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label39.Location = New System.Drawing.Point(16, 18)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(202, 29)
        Me.Label39.TabIndex = 2
        Me.Label39.Text = "Riwayat Pasien"
        '
        'Button3
        '
        Me.Button3.BackgroundImage = CType(resources.GetObject("Button3.BackgroundImage"), System.Drawing.Image)
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button3.Dock = System.Windows.Forms.DockStyle.Left
        Me.Button3.Location = New System.Drawing.Point(0, 0)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 66)
        Me.Button3.TabIndex = 4
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Panel63
        '
        Me.Panel63.Controls.Add(Me.Panel64)
        Me.Panel63.Controls.Add(Me.Panel65)
        Me.Panel63.Controls.Add(Me.Panel66)
        Me.Panel63.Controls.Add(Me.Panel67)
        Me.Panel63.Controls.Add(Me.Panel68)
        Me.Panel63.Controls.Add(Me.Panel69)
        Me.Panel63.Controls.Add(Me.Panel70)
        Me.Panel63.Controls.Add(Me.Panel71)
        Me.Panel63.Controls.Add(Me.Panel72)
        Me.Panel63.Controls.Add(Me.Panel73)
        Me.Panel63.Controls.Add(Me.Panel74)
        Me.Panel63.Controls.Add(Me.Panel75)
        Me.Panel63.Controls.Add(Me.Panel76)
        Me.Panel63.Controls.Add(Me.Panel77)
        Me.Panel63.Controls.Add(Me.Panel78)
        Me.Panel63.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel63.Location = New System.Drawing.Point(0, 0)
        Me.Panel63.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel63.Name = "Panel63"
        Me.Panel63.Size = New System.Drawing.Size(175, 263)
        Me.Panel63.TabIndex = 1
        '
        'Panel78
        '
        Me.Panel78.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel78.Location = New System.Drawing.Point(0, 0)
        Me.Panel78.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel78.Name = "Panel78"
        Me.Panel78.Size = New System.Drawing.Size(175, 11)
        Me.Panel78.TabIndex = 15
        '
        'Panel77
        '
        Me.Panel77.Controls.Add(Me.Label38)
        Me.Panel77.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel77.Location = New System.Drawing.Point(0, 11)
        Me.Panel77.Name = "Panel77"
        Me.Panel77.Size = New System.Drawing.Size(175, 25)
        Me.Panel77.TabIndex = 31
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label38.Location = New System.Drawing.Point(0, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(30, 17)
        Me.Label38.TabIndex = 0
        Me.Label38.Text = "NIK"
        '
        'Panel76
        '
        Me.Panel76.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel76.Location = New System.Drawing.Point(0, 36)
        Me.Panel76.Name = "Panel76"
        Me.Panel76.Size = New System.Drawing.Size(175, 11)
        Me.Panel76.TabIndex = 32
        '
        'Panel75
        '
        Me.Panel75.Controls.Add(Me.Label37)
        Me.Panel75.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel75.Location = New System.Drawing.Point(0, 47)
        Me.Panel75.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel75.Name = "Panel75"
        Me.Panel75.Size = New System.Drawing.Size(175, 25)
        Me.Panel75.TabIndex = 16
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label37.Location = New System.Drawing.Point(0, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(79, 17)
        Me.Label37.TabIndex = 3
        Me.Label37.Text = "User Name"
        '
        'Panel74
        '
        Me.Panel74.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel74.Location = New System.Drawing.Point(0, 72)
        Me.Panel74.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel74.Name = "Panel74"
        Me.Panel74.Size = New System.Drawing.Size(175, 11)
        Me.Panel74.TabIndex = 17
        '
        'Panel73
        '
        Me.Panel73.Controls.Add(Me.Label36)
        Me.Panel73.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel73.Location = New System.Drawing.Point(0, 83)
        Me.Panel73.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel73.Name = "Panel73"
        Me.Panel73.Size = New System.Drawing.Size(175, 25)
        Me.Panel73.TabIndex = 18
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label36.Location = New System.Drawing.Point(0, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(104, 17)
        Me.Label36.TabIndex = 2
        Me.Label36.Text = "Nama Lengkap"
        '
        'Panel72
        '
        Me.Panel72.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel72.Location = New System.Drawing.Point(0, 108)
        Me.Panel72.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel72.Name = "Panel72"
        Me.Panel72.Size = New System.Drawing.Size(175, 11)
        Me.Panel72.TabIndex = 19
        '
        'Panel71
        '
        Me.Panel71.Controls.Add(Me.Label29)
        Me.Panel71.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel71.Location = New System.Drawing.Point(0, 119)
        Me.Panel71.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel71.Name = "Panel71"
        Me.Panel71.Size = New System.Drawing.Size(175, 25)
        Me.Panel71.TabIndex = 20
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label29.Location = New System.Drawing.Point(0, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(42, 17)
        Me.Label29.TabIndex = 1
        Me.Label29.Text = "Umur"
        '
        'Panel70
        '
        Me.Panel70.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel70.Location = New System.Drawing.Point(0, 144)
        Me.Panel70.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel70.Name = "Panel70"
        Me.Panel70.Size = New System.Drawing.Size(175, 11)
        Me.Panel70.TabIndex = 21
        '
        'Panel69
        '
        Me.Panel69.Controls.Add(Me.Label28)
        Me.Panel69.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel69.Location = New System.Drawing.Point(0, 155)
        Me.Panel69.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel69.Name = "Panel69"
        Me.Panel69.Size = New System.Drawing.Size(175, 25)
        Me.Panel69.TabIndex = 22
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label28.Location = New System.Drawing.Point(0, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(95, 17)
        Me.Label28.TabIndex = 1
        Me.Label28.Text = "Jenis Kelamin"
        '
        'Panel68
        '
        Me.Panel68.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel68.Location = New System.Drawing.Point(0, 180)
        Me.Panel68.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel68.Name = "Panel68"
        Me.Panel68.Size = New System.Drawing.Size(175, 11)
        Me.Panel68.TabIndex = 23
        '
        'Panel67
        '
        Me.Panel67.Controls.Add(Me.Label27)
        Me.Panel67.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel67.Location = New System.Drawing.Point(0, 191)
        Me.Panel67.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel67.Name = "Panel67"
        Me.Panel67.Size = New System.Drawing.Size(175, 25)
        Me.Panel67.TabIndex = 24
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label27.Location = New System.Drawing.Point(0, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(51, 17)
        Me.Label27.TabIndex = 1
        Me.Label27.Text = "Alamat"
        '
        'Panel66
        '
        Me.Panel66.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel66.Location = New System.Drawing.Point(0, 216)
        Me.Panel66.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel66.Name = "Panel66"
        Me.Panel66.Size = New System.Drawing.Size(175, 11)
        Me.Panel66.TabIndex = 25
        '
        'Panel65
        '
        Me.Panel65.Controls.Add(Me.Label26)
        Me.Panel65.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel65.Location = New System.Drawing.Point(0, 227)
        Me.Panel65.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel65.Name = "Panel65"
        Me.Panel65.Size = New System.Drawing.Size(175, 25)
        Me.Panel65.TabIndex = 27
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label26.Location = New System.Drawing.Point(0, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(53, 17)
        Me.Label26.TabIndex = 1
        Me.Label26.Text = "Faskes"
        '
        'Panel64
        '
        Me.Panel64.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel64.Location = New System.Drawing.Point(0, 252)
        Me.Panel64.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel64.Name = "Panel64"
        Me.Panel64.Size = New System.Drawing.Size(175, 11)
        Me.Panel64.TabIndex = 30
        '
        'Panel47
        '
        Me.Panel47.Controls.Add(Me.Panel48)
        Me.Panel47.Controls.Add(Me.Panel49)
        Me.Panel47.Controls.Add(Me.Panel50)
        Me.Panel47.Controls.Add(Me.Panel51)
        Me.Panel47.Controls.Add(Me.Panel52)
        Me.Panel47.Controls.Add(Me.Panel53)
        Me.Panel47.Controls.Add(Me.Panel54)
        Me.Panel47.Controls.Add(Me.Panel55)
        Me.Panel47.Controls.Add(Me.Panel56)
        Me.Panel47.Controls.Add(Me.Panel57)
        Me.Panel47.Controls.Add(Me.Panel58)
        Me.Panel47.Controls.Add(Me.Panel59)
        Me.Panel47.Controls.Add(Me.Panel60)
        Me.Panel47.Controls.Add(Me.Panel61)
        Me.Panel47.Controls.Add(Me.Panel62)
        Me.Panel47.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel47.Location = New System.Drawing.Point(175, 0)
        Me.Panel47.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel47.Name = "Panel47"
        Me.Panel47.Size = New System.Drawing.Size(505, 263)
        Me.Panel47.TabIndex = 1
        '
        'Panel62
        '
        Me.Panel62.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel62.Location = New System.Drawing.Point(0, 0)
        Me.Panel62.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel62.Name = "Panel62"
        Me.Panel62.Size = New System.Drawing.Size(505, 11)
        Me.Panel62.TabIndex = 15
        '
        'Panel61
        '
        Me.Panel61.Controls.Add(Me.Label25)
        Me.Panel61.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel61.Location = New System.Drawing.Point(0, 11)
        Me.Panel61.Name = "Panel61"
        Me.Panel61.Size = New System.Drawing.Size(505, 25)
        Me.Panel61.TabIndex = 31
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label25.Location = New System.Drawing.Point(0, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(30, 17)
        Me.Label25.TabIndex = 0
        Me.Label25.Text = "NIK"
        '
        'Panel60
        '
        Me.Panel60.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel60.Location = New System.Drawing.Point(0, 36)
        Me.Panel60.Name = "Panel60"
        Me.Panel60.Size = New System.Drawing.Size(505, 11)
        Me.Panel60.TabIndex = 31
        '
        'Panel59
        '
        Me.Panel59.Controls.Add(Me.Label24)
        Me.Panel59.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel59.Location = New System.Drawing.Point(0, 47)
        Me.Panel59.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel59.Name = "Panel59"
        Me.Panel59.Size = New System.Drawing.Size(505, 25)
        Me.Panel59.TabIndex = 16
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label24.Location = New System.Drawing.Point(0, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(79, 17)
        Me.Label24.TabIndex = 3
        Me.Label24.Text = "User Name"
        '
        'Panel58
        '
        Me.Panel58.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel58.Location = New System.Drawing.Point(0, 72)
        Me.Panel58.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel58.Name = "Panel58"
        Me.Panel58.Size = New System.Drawing.Size(505, 11)
        Me.Panel58.TabIndex = 17
        '
        'Panel57
        '
        Me.Panel57.Controls.Add(Me.Label23)
        Me.Panel57.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel57.Location = New System.Drawing.Point(0, 83)
        Me.Panel57.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel57.Name = "Panel57"
        Me.Panel57.Size = New System.Drawing.Size(505, 25)
        Me.Panel57.TabIndex = 18
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label23.Location = New System.Drawing.Point(0, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(104, 17)
        Me.Label23.TabIndex = 2
        Me.Label23.Text = "Nama Lengkap"
        '
        'Panel56
        '
        Me.Panel56.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel56.Location = New System.Drawing.Point(0, 108)
        Me.Panel56.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel56.Name = "Panel56"
        Me.Panel56.Size = New System.Drawing.Size(505, 11)
        Me.Panel56.TabIndex = 19
        '
        'Panel55
        '
        Me.Panel55.Controls.Add(Me.Label21)
        Me.Panel55.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel55.Location = New System.Drawing.Point(0, 119)
        Me.Panel55.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel55.Name = "Panel55"
        Me.Panel55.Size = New System.Drawing.Size(505, 25)
        Me.Panel55.TabIndex = 20
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label21.Location = New System.Drawing.Point(0, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(42, 17)
        Me.Label21.TabIndex = 1
        Me.Label21.Text = "Umur"
        '
        'Panel54
        '
        Me.Panel54.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel54.Location = New System.Drawing.Point(0, 144)
        Me.Panel54.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel54.Name = "Panel54"
        Me.Panel54.Size = New System.Drawing.Size(505, 11)
        Me.Panel54.TabIndex = 21
        '
        'Panel53
        '
        Me.Panel53.Controls.Add(Me.Label20)
        Me.Panel53.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel53.Location = New System.Drawing.Point(0, 155)
        Me.Panel53.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel53.Name = "Panel53"
        Me.Panel53.Size = New System.Drawing.Size(505, 25)
        Me.Panel53.TabIndex = 22
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label20.Location = New System.Drawing.Point(0, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(95, 17)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "Jenis Kelamin"
        '
        'Panel52
        '
        Me.Panel52.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel52.Location = New System.Drawing.Point(0, 180)
        Me.Panel52.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel52.Name = "Panel52"
        Me.Panel52.Size = New System.Drawing.Size(505, 11)
        Me.Panel52.TabIndex = 23
        '
        'Panel51
        '
        Me.Panel51.Controls.Add(Me.Label19)
        Me.Panel51.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel51.Location = New System.Drawing.Point(0, 191)
        Me.Panel51.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel51.Name = "Panel51"
        Me.Panel51.Size = New System.Drawing.Size(505, 25)
        Me.Panel51.TabIndex = 24
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label19.Location = New System.Drawing.Point(0, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(51, 17)
        Me.Label19.TabIndex = 1
        Me.Label19.Text = "Alamat"
        '
        'Panel50
        '
        Me.Panel50.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel50.Location = New System.Drawing.Point(0, 216)
        Me.Panel50.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel50.Name = "Panel50"
        Me.Panel50.Size = New System.Drawing.Size(505, 11)
        Me.Panel50.TabIndex = 25
        '
        'Panel49
        '
        Me.Panel49.Controls.Add(Me.Label18)
        Me.Panel49.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel49.Location = New System.Drawing.Point(0, 227)
        Me.Panel49.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel49.Name = "Panel49"
        Me.Panel49.Size = New System.Drawing.Size(505, 25)
        Me.Panel49.TabIndex = 27
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label18.Location = New System.Drawing.Point(0, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(53, 17)
        Me.Label18.TabIndex = 1
        Me.Label18.Text = "Faskes"
        '
        'Panel48
        '
        Me.Panel48.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel48.Location = New System.Drawing.Point(0, 252)
        Me.Panel48.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel48.Name = "Panel48"
        Me.Panel48.Size = New System.Drawing.Size(505, 11)
        Me.Panel48.TabIndex = 30
        '
        'Panel46
        '
        Me.Panel46.Controls.Add(Me.Panel47)
        Me.Panel46.Controls.Add(Me.Panel63)
        Me.Panel46.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel46.Location = New System.Drawing.Point(0, 66)
        Me.Panel46.Name = "Panel46"
        Me.Panel46.Size = New System.Drawing.Size(680, 263)
        Me.Panel46.TabIndex = 4
        '
        'dgvRiwayatPasien
        '
        Me.dgvRiwayatPasien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvRiwayatPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvRiwayatPasien.Location = New System.Drawing.Point(0, 329)
        Me.dgvRiwayatPasien.Name = "dgvRiwayatPasien"
        Me.dgvRiwayatPasien.RowHeadersWidth = 51
        Me.dgvRiwayatPasien.RowTemplate.Height = 24
        Me.dgvRiwayatPasien.Size = New System.Drawing.Size(680, 252)
        Me.dgvRiwayatPasien.TabIndex = 5
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.ColumnCount = 1
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.Controls.Add(Me.Label15, 0, 0)
        Me.TableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(0, 329)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 1
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(680, 252)
        Me.TableLayoutPanel5.TabIndex = 6
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label15.Location = New System.Drawing.Point(3, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(674, 252)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "No Data"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'DokterDashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(911, 629)
        Me.Controls.Add(Me.panelGrup)
        Me.Controls.Add(Me.listMenuItem)
        Me.Controls.Add(Me.appBar)
        Me.Name = "DokterDashboard"
        Me.Text = "DokterDashboard"
        Me.appBar.ResumeLayout(False)
        Me.appBar.PerformLayout()
        CType(Me.showMenuItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.hideMenuItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureAkun, System.ComponentModel.ISupportInitialize).EndInit()
        Me.listMenuItem.ResumeLayout(False)
        Me.listMenuItem.PerformLayout()
        CType(Me.pictureKeluar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureLaporan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureTransaksi, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picturePasien, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureDashboard, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelGrup.ResumeLayout(False)
        Me.panelDaftarPasien.ResumeLayout(False)
        Me.panelTindakanDP.ResumeLayout(False)
        Me.Panel164.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel14.ResumeLayout(False)
        Me.Panel27.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.Panel23.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.Panel22.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel26.ResumeLayout(False)
        Me.Panel26.PerformLayout()
        Me.Panel20.ResumeLayout(False)
        Me.Panel20.PerformLayout()
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout()
        Me.Panel84.ResumeLayout(False)
        Me.Panel167.ResumeLayout(False)
        Me.Panel173.ResumeLayout(False)
        Me.Panel173.PerformLayout()
        Me.Panel175.ResumeLayout(False)
        Me.Panel175.PerformLayout()
        Me.Panel177.ResumeLayout(False)
        Me.Panel177.PerformLayout()
        Me.Panel179.ResumeLayout(False)
        Me.Panel179.PerformLayout()
        Me.Panel181.ResumeLayout(False)
        Me.Panel181.PerformLayout()
        Me.Panel183.ResumeLayout(False)
        Me.Panel183.PerformLayout()
        Me.Panel87.ResumeLayout(False)
        Me.Panel87.PerformLayout()
        Me.Panel185.ResumeLayout(False)
        Me.Panel191.ResumeLayout(False)
        Me.Panel191.PerformLayout()
        Me.Panel193.ResumeLayout(False)
        Me.Panel193.PerformLayout()
        Me.Panel195.ResumeLayout(False)
        Me.Panel195.PerformLayout()
        Me.Panel197.ResumeLayout(False)
        Me.Panel197.PerformLayout()
        Me.Panel199.ResumeLayout(False)
        Me.Panel199.PerformLayout()
        Me.Panel201.ResumeLayout(False)
        Me.Panel201.PerformLayout()
        Me.Panel118.ResumeLayout(False)
        Me.Panel118.PerformLayout()
        Me.Panel240.ResumeLayout(False)
        Me.Panel165.ResumeLayout(False)
        Me.Panel165.PerformLayout()
        Me.panelBerandaDP.ResumeLayout(False)
        Me.panelDatabaseDP.ResumeLayout(False)
        Me.TLPNoData.ResumeLayout(False)
        Me.TLPNoData.PerformLayout()
        CType(Me.dgvDaftarPasien, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel145.ResumeLayout(False)
        Me.Panel146.ResumeLayout(False)
        Me.Panel146.PerformLayout()
        Me.panelKeteranganDP.ResumeLayout(False)
        Me.panelKeteranganDP.PerformLayout()
        Me.panelDashboard.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel35.ResumeLayout(False)
        Me.Panel156.ResumeLayout(False)
        Me.Panel156.PerformLayout()
        Me.Panel154.ResumeLayout(False)
        Me.Panel154.PerformLayout()
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.panelTransaksi.ResumeLayout(False)
        Me.panelDatabaseTransaksi.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel157.ResumeLayout(False)
        Me.Panel158.ResumeLayout(False)
        Me.Panel158.PerformLayout()
        Me.panelKeteranganTransaksi.ResumeLayout(False)
        Me.panelKeteranganTransaksi.PerformLayout()
        Me.panelLaporan.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.panelAkun.ResumeLayout(False)
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        Me.panelRiwayatDP.ResumeLayout(False)
        Me.Panel79.ResumeLayout(False)
        Me.Panel80.ResumeLayout(False)
        Me.Panel80.PerformLayout()
        Me.Panel63.ResumeLayout(False)
        Me.Panel77.ResumeLayout(False)
        Me.Panel77.PerformLayout()
        Me.Panel75.ResumeLayout(False)
        Me.Panel75.PerformLayout()
        Me.Panel73.ResumeLayout(False)
        Me.Panel73.PerformLayout()
        Me.Panel71.ResumeLayout(False)
        Me.Panel71.PerformLayout()
        Me.Panel69.ResumeLayout(False)
        Me.Panel69.PerformLayout()
        Me.Panel67.ResumeLayout(False)
        Me.Panel67.PerformLayout()
        Me.Panel65.ResumeLayout(False)
        Me.Panel65.PerformLayout()
        Me.Panel47.ResumeLayout(False)
        Me.Panel61.ResumeLayout(False)
        Me.Panel61.PerformLayout()
        Me.Panel59.ResumeLayout(False)
        Me.Panel59.PerformLayout()
        Me.Panel57.ResumeLayout(False)
        Me.Panel57.PerformLayout()
        Me.Panel55.ResumeLayout(False)
        Me.Panel55.PerformLayout()
        Me.Panel53.ResumeLayout(False)
        Me.Panel53.PerformLayout()
        Me.Panel51.ResumeLayout(False)
        Me.Panel51.PerformLayout()
        Me.Panel49.ResumeLayout(False)
        Me.Panel49.PerformLayout()
        Me.Panel46.ResumeLayout(False)
        CType(Me.dgvRiwayatPasien, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel5.ResumeLayout(False)
        Me.TableLayoutPanel5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents appBar As Panel
    Friend WithEvents showMenuItem As PictureBox
    Friend WithEvents pictureAkun As PictureBox
    Friend WithEvents hideMenuItem As PictureBox
    Friend WithEvents listMenuItem As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents pictureDashboard As PictureBox
    Friend WithEvents pictureKeluar As PictureBox
    Friend WithEvents pictureLaporan As PictureBox
    Friend WithEvents picturePasien As PictureBox
    Friend WithEvents pictureTransaksi As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents buttonKeluar As Button
    Friend WithEvents buttonAkun As Button
    Friend WithEvents buttonLaporan As Button
    Friend WithEvents buttonTransaksi As Button
    Friend WithEvents buttonDaftar_Pasien As Button
    Friend WithEvents buttonDashboard As Button
    Friend WithEvents panelGrup As Panel
    Friend WithEvents panelDaftarPasien As Panel
    Friend WithEvents panelDatabaseDP As Panel
    Friend WithEvents dgvDaftarPasien As DataGridView
    Friend WithEvents Panel145 As Panel
    Friend WithEvents Panel146 As Panel
    Friend WithEvents txtCariPasien As TextBox
    Friend WithEvents Panel147 As Panel
    Friend WithEvents btnCariPasien As Button
    Friend WithEvents Panel148 As Panel
    Friend WithEvents Panel149 As Panel
    Friend WithEvents Panel150 As Panel
    Friend WithEvents Panel151 As Panel
    Friend WithEvents panelKeteranganDP As Panel
    Friend WithEvents textKeterangan As Label
    Friend WithEvents VScrollBar1 As VScrollBar
    Friend WithEvents panelDashboard As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel35 As Panel
    Friend WithEvents Panel156 As Panel
    Friend WithEvents Label33 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Panel155 As Panel
    Friend WithEvents Panel154 As Panel
    Friend WithEvents Label31 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Panel153 As Panel
    Friend WithEvents Panel152 As Panel
    Friend WithEvents Panel16 As Panel
    Friend WithEvents Label9 As Label
    Friend WithEvents VScrollBar3 As VScrollBar
    Friend WithEvents panelTransaksi As Panel
    Friend WithEvents panelDatabaseTransaksi As Panel
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents btnBelumBayar As Button
    Friend WithEvents btnSemuaTransaksi As Button
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Panel157 As Panel
    Friend WithEvents Panel158 As Panel
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents Panel159 As Panel
    Friend WithEvents Button8 As Button
    Friend WithEvents Panel160 As Panel
    Friend WithEvents Panel161 As Panel
    Friend WithEvents Panel162 As Panel
    Friend WithEvents Panel163 As Panel
    Friend WithEvents panelKeteranganTransaksi As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents VScrollBar2 As VScrollBar
    Friend WithEvents panelLaporan As Panel
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Label10 As Label
    Friend WithEvents VScrollBar4 As VScrollBar
    Friend WithEvents panelAkun As Panel
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Label34 As Label
    Friend WithEvents txtNamaPengguna As Label
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Label11 As Label
    Friend WithEvents VScrollBar5 As VScrollBar
    Friend WithEvents panelBerandaDP As Panel
    Friend WithEvents panelTindakanDP As Panel
    Friend WithEvents Panel164 As Panel
    Friend WithEvents btn_IP_AjukanApoteker As Button
    Friend WithEvents btn_IP_Batal As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel14 As Panel
    Friend WithEvents Panel21 As Panel
    Friend WithEvents Panel22 As Panel
    Friend WithEvents Panel19 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel20 As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents Panel18 As Panel
    Friend WithEvents Panel17 As Panel
    Friend WithEvents Label12 As Label
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Panel84 As Panel
    Friend WithEvents Panel167 As Panel
    Friend WithEvents Panel170 As Panel
    Friend WithEvents Panel173 As Panel
    Friend WithEvents txt_IP_Faskes As Label
    Friend WithEvents Panel174 As Panel
    Friend WithEvents Panel175 As Panel
    Friend WithEvents txt_IP_Alamat As Label
    Friend WithEvents Panel176 As Panel
    Friend WithEvents Panel177 As Panel
    Friend WithEvents txt_IP_JenisKelamin As Label
    Friend WithEvents Panel178 As Panel
    Friend WithEvents Panel179 As Panel
    Friend WithEvents txt_IP_Umur As Label
    Friend WithEvents Panel180 As Panel
    Friend WithEvents Panel181 As Panel
    Friend WithEvents txt_IP_NamaLengkap As Label
    Friend WithEvents Panel182 As Panel
    Friend WithEvents Panel183 As Panel
    Friend WithEvents txt_IP_UserName As Label
    Friend WithEvents Panel86 As Panel
    Friend WithEvents Panel87 As Panel
    Friend WithEvents txt_IP_NIK As Label
    Friend WithEvents Panel184 As Panel
    Friend WithEvents Panel185 As Panel
    Friend WithEvents Panel188 As Panel
    Friend WithEvents Panel191 As Panel
    Friend WithEvents Label47 As Label
    Friend WithEvents Panel192 As Panel
    Friend WithEvents Panel193 As Panel
    Friend WithEvents Label48 As Label
    Friend WithEvents Panel194 As Panel
    Friend WithEvents Panel195 As Panel
    Friend WithEvents Label49 As Label
    Friend WithEvents Panel196 As Panel
    Friend WithEvents Panel197 As Panel
    Friend WithEvents Label50 As Label
    Friend WithEvents Panel198 As Panel
    Friend WithEvents Panel199 As Panel
    Friend WithEvents Label51 As Label
    Friend WithEvents Panel200 As Panel
    Friend WithEvents Panel201 As Panel
    Friend WithEvents Label52 As Label
    Friend WithEvents Panel119 As Panel
    Friend WithEvents Panel118 As Panel
    Friend WithEvents Label22 As Label
    Friend WithEvents Panel202 As Panel
    Friend WithEvents Panel240 As Panel
    Friend WithEvents Panel165 As Panel
    Friend WithEvents Label45 As Label
    Friend WithEvents btn_IP_Kembali As Button
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents txt_IP_Diagnosa As TextBox
    Friend WithEvents Panel24 As Panel
    Friend WithEvents Panel23 As Panel
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents txt_IP_Terapi As TextBox
    Friend WithEvents Panel27 As Panel
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents txt_IP_Harga As TextBox
    Friend WithEvents Panel25 As Panel
    Friend WithEvents Panel26 As Panel
    Friend WithEvents Label14 As Label
    Friend WithEvents TLPNoData As TableLayoutPanel
    Friend WithEvents Label35 As Label
    Friend WithEvents txtJadwal As Label
    Friend WithEvents jadwal As Timer
    Friend WithEvents panelRiwayatDP As Panel
    Friend WithEvents dgvRiwayatPasien As DataGridView
    Friend WithEvents Panel46 As Panel
    Friend WithEvents Panel47 As Panel
    Friend WithEvents Panel48 As Panel
    Friend WithEvents Panel49 As Panel
    Friend WithEvents Label18 As Label
    Friend WithEvents Panel50 As Panel
    Friend WithEvents Panel51 As Panel
    Friend WithEvents Label19 As Label
    Friend WithEvents Panel52 As Panel
    Friend WithEvents Panel53 As Panel
    Friend WithEvents Label20 As Label
    Friend WithEvents Panel54 As Panel
    Friend WithEvents Panel55 As Panel
    Friend WithEvents Label21 As Label
    Friend WithEvents Panel56 As Panel
    Friend WithEvents Panel57 As Panel
    Friend WithEvents Label23 As Label
    Friend WithEvents Panel58 As Panel
    Friend WithEvents Panel59 As Panel
    Friend WithEvents Label24 As Label
    Friend WithEvents Panel60 As Panel
    Friend WithEvents Panel61 As Panel
    Friend WithEvents Label25 As Label
    Friend WithEvents Panel62 As Panel
    Friend WithEvents Panel63 As Panel
    Friend WithEvents Panel64 As Panel
    Friend WithEvents Panel65 As Panel
    Friend WithEvents Label26 As Label
    Friend WithEvents Panel66 As Panel
    Friend WithEvents Panel67 As Panel
    Friend WithEvents Label27 As Label
    Friend WithEvents Panel68 As Panel
    Friend WithEvents Panel69 As Panel
    Friend WithEvents Label28 As Label
    Friend WithEvents Panel70 As Panel
    Friend WithEvents Panel71 As Panel
    Friend WithEvents Label29 As Label
    Friend WithEvents Panel72 As Panel
    Friend WithEvents Panel73 As Panel
    Friend WithEvents Label36 As Label
    Friend WithEvents Panel74 As Panel
    Friend WithEvents Panel75 As Panel
    Friend WithEvents Label37 As Label
    Friend WithEvents Panel76 As Panel
    Friend WithEvents Panel77 As Panel
    Friend WithEvents Label38 As Label
    Friend WithEvents Panel78 As Panel
    Friend WithEvents Panel79 As Panel
    Friend WithEvents Panel80 As Panel
    Friend WithEvents Label39 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents Label15 As Label
End Class
