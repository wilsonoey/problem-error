﻿Public Class LoginScreen
    Private Sub LoginScreen_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtUserName.Text = ""
        txtPosition.Text = ""
        txtPosition.Items.Add("Dokter")
        txtPosition.Items.Add("Apoteker")
        txtPosition.Items.Add("Admin")
        txtPosition.Items.Add("Loketor")
        txtPosition.Items.Add("Pasien")
        txtPassword.Text = ""
        txtUserName.Focus()
    End Sub
    Private Sub btnKeluar_Click(sender As Object, e As EventArgs) Handles btnKeluar.Click
        Me.Close()
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        Me.Hide()
        RegisterScreen.ShowDialog()
        Me.Close()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim SelectSQL As String = "SELECT * FROM tb_user WHERE username='" & txtUserName.Text & "' AND jabatan='" & txtPosition.Text & "' AND password=MD5('" & txtPassword.Text & "')"
        If (txtUserName.Text = "") Or (txtPosition.Text = "") Or (txtPassword.Text = "") Then
            MsgBox("User Name atau Password masing kosong!",
            MsgBoxStyle.Critical, "Kesalahan")
            txtUserName.Focus()
        End If
        If (txtPosition.Text = "Dokter") And KoneksiDB.CariData(SelectSQL) Then
            MsgBox("Selamat Bekerja " & txtUserName.Text.ToUpper & "!", MsgBoxStyle.Information, "Info")
            Me.Hide()
            DokterDashboard.ShowDialog()
            Me.Close()
        ElseIf (txtPosition.Text = "Admin") And KoneksiDB.CariData(SelectSQL) Then
            MsgBox("Selamat Bekerja " & txtUserName.Text.ToUpper & "!", MsgBoxStyle.Information, "Info")
            Me.Hide()
            AdminDashboard.ShowDialog()
            Me.Close()
        ElseIf (txtPosition.Text = "Apoteker") And KoneksiDB.CariData(SelectSQL) Then
            MsgBox("Selamat Bekerja " & txtUserName.Text.ToUpper & "!", MsgBoxStyle.Information, "Info")
            Me.Hide()
            ApotekerDashboard.ShowDialog()
            Me.Close()
        ElseIf (txtPosition.Text = "Loketor") And KoneksiDB.CariData(SelectSQL) Then
            MsgBox("Selamat Bekerja " & txtUserName.Text.ToUpper & "!", MsgBoxStyle.Information, "Info")
            Me.Hide()
            LoketorDashboard.ShowDialog()
            Me.Close()
        ElseIf (txtPosition.Text = "Pasien") And KoneksiDB.CariData(SelectSQL) Then
            MsgBox("Selamat Bekerja " & txtUserName.Text.ToUpper & "!", MsgBoxStyle.Information, "Info")
            Me.Hide()
            PasienDashboard.ShowDialog()
            Me.Close()
        Else
            MsgBox("user name atau password salah" & "!", MsgBoxStyle.Critical, "info")
        End If
    End Sub
End Class