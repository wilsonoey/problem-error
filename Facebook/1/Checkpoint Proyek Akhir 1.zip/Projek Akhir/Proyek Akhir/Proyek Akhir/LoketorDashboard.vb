﻿Public Class LoketorDashboard
    Dim id_users As Integer
    Private Sub LoketorDashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtUserName.Text = ""
        txtFaskes.Text = ""
        txtFaskes.Items.Add("BPJS")
        txtFaskes.Items.Add("Umum")
        txtFaskes.Items.Add("Asuransi")
        txtUserName.Focus()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim SQLSelectPasien, SQLSimpanPasien, SQLStatusPasien As String
        SQLSelectPasien = "SELECT username FROM tb_pasien WHERE username like'" & txtUserName.Text & "'"
        SQLSimpanPasien = "INSERT INTO tb_pasien (username,faskes,status) VALUES ('" & txtUserName.Text & "','" & txtFaskes.Text & "','Menunggu Antrian')"
        SQLStatusPasien = "UPDATE tb_pasien SET status = 'Menunggu Antrian' WHERE id = '" & id_users & "'"
        If (txtUserName.Text = "") Or (txtFaskes.Text = "") Then
            MsgBox("Data belum lengkap!", MsgBoxStyle.Critical, "Kesalahan")
        End If
        If KoneksiDB.CariData(SQLSelectPasien) <> True Then
            Call KoneksiDB.ProsesSQL(SQLSimpanPasien)
            Call KoneksiDB.ProsesSQL(SQLStatusPasien)
            MsgBox("Data berhasil ditambahkan", vbInformation, "Tambah Data")
        ElseIf KoneksiDB.CariData(SQLSelectPasien) <> False Then
            Call KoneksiDB.ProsesSQL(SQLStatusPasien)
            MsgBox("Username sudah terdaftar", vbInformation, "Info")
        End If
    End Sub
End Class