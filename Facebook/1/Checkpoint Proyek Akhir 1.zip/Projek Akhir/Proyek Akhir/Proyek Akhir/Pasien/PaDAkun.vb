﻿Public Class PaDAkun
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim x As Integer = 50
        Dim y As Integer = 50
        Dim a = New Label()
        a.Location = New Point(x, y)
        a.Size = New Size(20, 15)

        a.Text = "La"
        Me.Controls.Add(a)
        x += 30
        y += 30
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

    End Sub
End Class