﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PasienDashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PasienDashboard))
        Me.appBar = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.showMenuItem = New System.Windows.Forms.PictureBox()
        Me.hideMenuItem = New System.Windows.Forms.PictureBox()
        Me.pictureAkun = New System.Windows.Forms.PictureBox()
        Me.listMenuItem = New System.Windows.Forms.Panel()
        Me.pictureKeluar = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pictureLaporan = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.pictureDashboard = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.buttonKeluar = New System.Windows.Forms.Button()
        Me.buttonAkun = New System.Windows.Forms.Button()
        Me.buttonRiwayat = New System.Windows.Forms.Button()
        Me.buttonDashboard = New System.Windows.Forms.Button()
        Me.textDashboard = New System.Windows.Forms.Label()
        Me.panelDashboard = New System.Windows.Forms.Panel()
        Me.panelRiwayat = New System.Windows.Forms.Panel()
        Me.textRiwayat = New System.Windows.Forms.Label()
        Me.panelAkun = New System.Windows.Forms.Panel()
        Me.textAkun = New System.Windows.Forms.Label()
        Me.panelAntrian = New System.Windows.Forms.Panel()
        Me.VScrollBar1 = New System.Windows.Forms.VScrollBar()
        Me.panelBelumBayar = New System.Windows.Forms.Panel()
        Me.labelStatus = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.buttonStatusAdmin = New System.Windows.Forms.Button()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.labelStatusAntrian = New System.Windows.Forms.Label()
        Me.labelAntrianBerapa = New System.Windows.Forms.Label()
        Me.labelStatusNone = New System.Windows.Forms.Label()
        Me.labelStatusTempat = New System.Windows.Forms.Label()
        Me.appBar.SuspendLayout()
        CType(Me.showMenuItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.hideMenuItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureAkun, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.listMenuItem.SuspendLayout()
        CType(Me.pictureKeluar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureLaporan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureDashboard, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDashboard.SuspendLayout()
        Me.panelRiwayat.SuspendLayout()
        Me.panelAkun.SuspendLayout()
        Me.panelAntrian.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.SuspendLayout()
        '
        'appBar
        '
        Me.appBar.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.appBar.Controls.Add(Me.Label8)
        Me.appBar.Controls.Add(Me.showMenuItem)
        Me.appBar.Controls.Add(Me.hideMenuItem)
        Me.appBar.Dock = System.Windows.Forms.DockStyle.Top
        Me.appBar.Location = New System.Drawing.Point(0, 0)
        Me.appBar.Name = "appBar"
        Me.appBar.Size = New System.Drawing.Size(911, 48)
        Me.appBar.TabIndex = 0
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(65, 8)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(109, 32)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Pasien"
        '
        'showMenuItem
        '
        Me.showMenuItem.BackgroundImage = CType(resources.GetObject("showMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.showMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.showMenuItem.Location = New System.Drawing.Point(12, 6)
        Me.showMenuItem.Name = "showMenuItem"
        Me.showMenuItem.Size = New System.Drawing.Size(38, 33)
        Me.showMenuItem.TabIndex = 0
        Me.showMenuItem.TabStop = False
        '
        'hideMenuItem
        '
        Me.hideMenuItem.BackgroundImage = CType(resources.GetObject("hideMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.hideMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.hideMenuItem.Location = New System.Drawing.Point(12, 6)
        Me.hideMenuItem.Name = "hideMenuItem"
        Me.hideMenuItem.Size = New System.Drawing.Size(38, 33)
        Me.hideMenuItem.TabIndex = 0
        Me.hideMenuItem.TabStop = False
        '
        'pictureAkun
        '
        Me.pictureAkun.BackgroundImage = CType(resources.GetObject("pictureAkun.BackgroundImage"), System.Drawing.Image)
        Me.pictureAkun.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureAkun.Location = New System.Drawing.Point(13, 143)
        Me.pictureAkun.Name = "pictureAkun"
        Me.pictureAkun.Size = New System.Drawing.Size(50, 50)
        Me.pictureAkun.TabIndex = 0
        Me.pictureAkun.TabStop = False
        '
        'listMenuItem
        '
        Me.listMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.listMenuItem.Controls.Add(Me.pictureKeluar)
        Me.listMenuItem.Controls.Add(Me.pictureAkun)
        Me.listMenuItem.Controls.Add(Me.Label3)
        Me.listMenuItem.Controls.Add(Me.pictureLaporan)
        Me.listMenuItem.Controls.Add(Me.Label5)
        Me.listMenuItem.Controls.Add(Me.Label7)
        Me.listMenuItem.Controls.Add(Me.pictureDashboard)
        Me.listMenuItem.Controls.Add(Me.Label1)
        Me.listMenuItem.Controls.Add(Me.buttonKeluar)
        Me.listMenuItem.Controls.Add(Me.buttonAkun)
        Me.listMenuItem.Controls.Add(Me.buttonRiwayat)
        Me.listMenuItem.Controls.Add(Me.buttonDashboard)
        Me.listMenuItem.Dock = System.Windows.Forms.DockStyle.Left
        Me.listMenuItem.Location = New System.Drawing.Point(0, 48)
        Me.listMenuItem.Name = "listMenuItem"
        Me.listMenuItem.Size = New System.Drawing.Size(231, 529)
        Me.listMenuItem.TabIndex = 1
        '
        'pictureKeluar
        '
        Me.pictureKeluar.BackgroundImage = CType(resources.GetObject("pictureKeluar.BackgroundImage"), System.Drawing.Image)
        Me.pictureKeluar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureKeluar.Location = New System.Drawing.Point(13, 210)
        Me.pictureKeluar.Name = "pictureKeluar"
        Me.pictureKeluar.Size = New System.Drawing.Size(50, 50)
        Me.pictureKeluar.TabIndex = 0
        Me.pictureKeluar.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(66, 224)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 29)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Keluar"
        '
        'pictureLaporan
        '
        Me.pictureLaporan.BackgroundImage = CType(resources.GetObject("pictureLaporan.BackgroundImage"), System.Drawing.Image)
        Me.pictureLaporan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureLaporan.Location = New System.Drawing.Point(13, 76)
        Me.pictureLaporan.Name = "pictureLaporan"
        Me.pictureLaporan.Size = New System.Drawing.Size(50, 50)
        Me.pictureLaporan.TabIndex = 0
        Me.pictureLaporan.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(66, 153)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 29)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Akun"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(66, 87)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(97, 29)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Riwayat"
        '
        'pictureDashboard
        '
        Me.pictureDashboard.BackgroundImage = CType(resources.GetObject("pictureDashboard.BackgroundImage"), System.Drawing.Image)
        Me.pictureDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureDashboard.Location = New System.Drawing.Point(13, 8)
        Me.pictureDashboard.Name = "pictureDashboard"
        Me.pictureDashboard.Size = New System.Drawing.Size(50, 50)
        Me.pictureDashboard.TabIndex = 0
        Me.pictureDashboard.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(66, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(131, 29)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Dashboard"
        '
        'buttonKeluar
        '
        Me.buttonKeluar.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonKeluar.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonKeluar.Location = New System.Drawing.Point(0, 201)
        Me.buttonKeluar.Name = "buttonKeluar"
        Me.buttonKeluar.Size = New System.Drawing.Size(231, 67)
        Me.buttonKeluar.TabIndex = 3
        Me.buttonKeluar.UseVisualStyleBackColor = False
        '
        'buttonAkun
        '
        Me.buttonAkun.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonAkun.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonAkun.Location = New System.Drawing.Point(0, 134)
        Me.buttonAkun.Name = "buttonAkun"
        Me.buttonAkun.Size = New System.Drawing.Size(231, 67)
        Me.buttonAkun.TabIndex = 3
        Me.buttonAkun.UseVisualStyleBackColor = False
        '
        'buttonRiwayat
        '
        Me.buttonRiwayat.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonRiwayat.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonRiwayat.Location = New System.Drawing.Point(0, 67)
        Me.buttonRiwayat.Name = "buttonRiwayat"
        Me.buttonRiwayat.Size = New System.Drawing.Size(231, 67)
        Me.buttonRiwayat.TabIndex = 3
        Me.buttonRiwayat.UseVisualStyleBackColor = False
        '
        'buttonDashboard
        '
        Me.buttonDashboard.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonDashboard.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonDashboard.Location = New System.Drawing.Point(0, 0)
        Me.buttonDashboard.Name = "buttonDashboard"
        Me.buttonDashboard.Size = New System.Drawing.Size(231, 67)
        Me.buttonDashboard.TabIndex = 3
        Me.buttonDashboard.UseVisualStyleBackColor = False
        '
        'textDashboard
        '
        Me.textDashboard.AutoSize = True
        Me.textDashboard.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.textDashboard.Location = New System.Drawing.Point(15, 19)
        Me.textDashboard.Name = "textDashboard"
        Me.textDashboard.Size = New System.Drawing.Size(145, 29)
        Me.textDashboard.TabIndex = 2
        Me.textDashboard.Text = "Dashboard"
        '
        'panelDashboard
        '
        Me.panelDashboard.Controls.Add(Me.panelAntrian)
        Me.panelDashboard.Controls.Add(Me.panelBelumBayar)
        Me.panelDashboard.Controls.Add(Me.VScrollBar1)
        Me.panelDashboard.Controls.Add(Me.textDashboard)
        Me.panelDashboard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDashboard.Location = New System.Drawing.Point(231, 48)
        Me.panelDashboard.Name = "panelDashboard"
        Me.panelDashboard.Size = New System.Drawing.Size(680, 529)
        Me.panelDashboard.TabIndex = 3
        '
        'panelRiwayat
        '
        Me.panelRiwayat.Controls.Add(Me.textRiwayat)
        Me.panelRiwayat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelRiwayat.Location = New System.Drawing.Point(231, 48)
        Me.panelRiwayat.Name = "panelRiwayat"
        Me.panelRiwayat.Size = New System.Drawing.Size(680, 529)
        Me.panelRiwayat.TabIndex = 4
        '
        'textRiwayat
        '
        Me.textRiwayat.AutoSize = True
        Me.textRiwayat.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.textRiwayat.Location = New System.Drawing.Point(15, 15)
        Me.textRiwayat.Name = "textRiwayat"
        Me.textRiwayat.Size = New System.Drawing.Size(104, 29)
        Me.textRiwayat.TabIndex = 2
        Me.textRiwayat.Text = "Riwayat"
        '
        'panelAkun
        '
        Me.panelAkun.Controls.Add(Me.textAkun)
        Me.panelAkun.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelAkun.Location = New System.Drawing.Point(231, 48)
        Me.panelAkun.Name = "panelAkun"
        Me.panelAkun.Size = New System.Drawing.Size(680, 529)
        Me.panelAkun.TabIndex = 5
        '
        'textAkun
        '
        Me.textAkun.AutoSize = True
        Me.textAkun.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.textAkun.Location = New System.Drawing.Point(15, 15)
        Me.textAkun.Name = "textAkun"
        Me.textAkun.Size = New System.Drawing.Size(70, 29)
        Me.textAkun.TabIndex = 2
        Me.textAkun.Text = "Akun"
        '
        'panelAntrian
        '
        Me.panelAntrian.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.panelAntrian.Controls.Add(Me.Panel2)
        Me.panelAntrian.Controls.Add(Me.Panel5)
        Me.panelAntrian.Controls.Add(Me.Panel4)
        Me.panelAntrian.Controls.Add(Me.Panel3)
        Me.panelAntrian.Controls.Add(Me.Panel1)
        Me.panelAntrian.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelAntrian.Location = New System.Drawing.Point(0, 69)
        Me.panelAntrian.Name = "panelAntrian"
        Me.panelAntrian.Size = New System.Drawing.Size(659, 132)
        Me.panelAntrian.TabIndex = 3
        '
        'VScrollBar1
        '
        Me.VScrollBar1.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar1.Location = New System.Drawing.Point(659, 0)
        Me.VScrollBar1.Name = "VScrollBar1"
        Me.VScrollBar1.Size = New System.Drawing.Size(21, 529)
        Me.VScrollBar1.TabIndex = 3
        '
        'panelBelumBayar
        '
        Me.panelBelumBayar.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.panelBelumBayar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelBelumBayar.Location = New System.Drawing.Point(0, 201)
        Me.panelBelumBayar.Name = "panelBelumBayar"
        Me.panelBelumBayar.Size = New System.Drawing.Size(659, 328)
        Me.panelBelumBayar.TabIndex = 3
        '
        'labelStatus
        '
        Me.labelStatus.AutoSize = True
        Me.labelStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labelStatus.Location = New System.Drawing.Point(13, 9)
        Me.labelStatus.Name = "labelStatus"
        Me.labelStatus.Size = New System.Drawing.Size(68, 25)
        Me.labelStatus.TabIndex = 0
        Me.labelStatus.Text = "Status"
        '
        'Panel1
        '
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(19, 132)
        Me.Panel1.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Panel2.Controls.Add(Me.Panel7)
        Me.Panel2.Controls.Add(Me.Panel6)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(19, 45)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(621, 73)
        Me.Panel2.TabIndex = 1
        '
        'Panel3
        '
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel3.Location = New System.Drawing.Point(640, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(19, 132)
        Me.Panel3.TabIndex = 1
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.labelStatus)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(19, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(621, 45)
        Me.Panel4.TabIndex = 1
        '
        'Panel5
        '
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel5.Location = New System.Drawing.Point(19, 118)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(621, 14)
        Me.Panel5.TabIndex = 1
        '
        'buttonStatusAdmin
        '
        Me.buttonStatusAdmin.Location = New System.Drawing.Point(20, 26)
        Me.buttonStatusAdmin.Name = "buttonStatusAdmin"
        Me.buttonStatusAdmin.Size = New System.Drawing.Size(75, 23)
        Me.buttonStatusAdmin.TabIndex = 0
        Me.buttonStatusAdmin.Text = "Admin"
        Me.buttonStatusAdmin.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.buttonStatusAdmin)
        Me.Panel6.Controls.Add(Me.labelAntrianBerapa)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel6.Location = New System.Drawing.Point(503, 0)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(118, 73)
        Me.Panel6.TabIndex = 1
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.labelStatusAntrian)
        Me.Panel7.Controls.Add(Me.labelStatusTempat)
        Me.Panel7.Controls.Add(Me.labelStatusNone)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel7.Location = New System.Drawing.Point(0, 0)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(503, 73)
        Me.Panel7.TabIndex = 2
        '
        'labelStatusAntrian
        '
        Me.labelStatusAntrian.AutoSize = True
        Me.labelStatusAntrian.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labelStatusAntrian.Location = New System.Drawing.Point(15, 20)
        Me.labelStatusAntrian.Name = "labelStatusAntrian"
        Me.labelStatusAntrian.Size = New System.Drawing.Size(159, 32)
        Me.labelStatusAntrian.TabIndex = 0
        Me.labelStatusAntrian.Text = "Antrian ke- "
        '
        'labelAntrianBerapa
        '
        Me.labelAntrianBerapa.AutoSize = True
        Me.labelAntrianBerapa.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labelAntrianBerapa.Location = New System.Drawing.Point(36, 10)
        Me.labelAntrianBerapa.Name = "labelAntrianBerapa"
        Me.labelAntrianBerapa.Size = New System.Drawing.Size(47, 52)
        Me.labelAntrianBerapa.TabIndex = 1
        Me.labelAntrianBerapa.Text = "1"
        '
        'labelStatusNone
        '
        Me.labelStatusNone.AutoSize = True
        Me.labelStatusNone.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labelStatusNone.Location = New System.Drawing.Point(15, 20)
        Me.labelStatusNone.Name = "labelStatusNone"
        Me.labelStatusNone.Size = New System.Drawing.Size(235, 32)
        Me.labelStatusNone.TabIndex = 0
        Me.labelStatusNone.Text = "Tidak ada antrian"
        '
        'labelStatusTempat
        '
        Me.labelStatusTempat.AutoSize = True
        Me.labelStatusTempat.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labelStatusTempat.Location = New System.Drawing.Point(15, 20)
        Me.labelStatusTempat.Name = "labelStatusTempat"
        Me.labelStatusTempat.Size = New System.Drawing.Size(126, 32)
        Me.labelStatusTempat.TabIndex = 0
        Me.labelStatusTempat.Text = "Pergi ke "
        '
        'PasienDashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(911, 577)
        Me.Controls.Add(Me.panelDashboard)
        Me.Controls.Add(Me.panelRiwayat)
        Me.Controls.Add(Me.panelAkun)
        Me.Controls.Add(Me.listMenuItem)
        Me.Controls.Add(Me.appBar)
        Me.Name = "PasienDashboard"
        Me.Text = "PasienDashboard"
        Me.appBar.ResumeLayout(False)
        Me.appBar.PerformLayout()
        CType(Me.showMenuItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.hideMenuItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureAkun, System.ComponentModel.ISupportInitialize).EndInit()
        Me.listMenuItem.ResumeLayout(False)
        Me.listMenuItem.PerformLayout()
        CType(Me.pictureKeluar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureLaporan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureDashboard, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDashboard.ResumeLayout(False)
        Me.panelDashboard.PerformLayout()
        Me.panelRiwayat.ResumeLayout(False)
        Me.panelRiwayat.PerformLayout()
        Me.panelAkun.ResumeLayout(False)
        Me.panelAkun.PerformLayout()
        Me.panelAntrian.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents appBar As Panel
    Friend WithEvents showMenuItem As PictureBox
    Friend WithEvents pictureAkun As PictureBox
    Friend WithEvents hideMenuItem As PictureBox
    Friend WithEvents listMenuItem As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents pictureDashboard As PictureBox
    Friend WithEvents pictureKeluar As PictureBox
    Friend WithEvents pictureLaporan As PictureBox
    Friend WithEvents textDashboard As Label
    Friend WithEvents buttonKeluar As Button
    Friend WithEvents buttonAkun As Button
    Friend WithEvents buttonRiwayat As Button
    Friend WithEvents buttonDashboard As Button
    Friend WithEvents panelDashboard As Panel
    Friend WithEvents panelRiwayat As Panel
    Friend WithEvents textRiwayat As Label
    Friend WithEvents panelAkun As Panel
    Friend WithEvents textAkun As Label
    Friend WithEvents panelBelumBayar As Panel
    Friend WithEvents panelAntrian As Panel
    Friend WithEvents VScrollBar1 As VScrollBar
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents labelStatus As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents labelStatusAntrian As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents buttonStatusAdmin As Button
    Friend WithEvents labelAntrianBerapa As Label
    Friend WithEvents labelStatusTempat As Label
    Friend WithEvents labelStatusNone As Label
End Class
