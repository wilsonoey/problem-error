﻿Public Class RegisterScreen
    Private Sub RegisterScreen_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtUserName.Text = ""
        txtNickName.Text = ""
        txtAge.Text = ""
        txtGender.Text = ""
        txtGender.Items.Add("Laki-Laki")
        txtGender.Items.Add("Perempuan")
        txtGender.Items.Add("Tidak diketahui")
        txtPosition.Text = ""
        txtPosition.Items.Add("Dokter")
        txtPosition.Items.Add("Apoteker")
        txtPosition.Items.Add("Admin")
        txtPosition.Items.Add("Loketor")
        txtAddress.Text = ""
        txtPassword.Text = ""
        txtUserName.Focus()
    End Sub
    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        Dim SQLSelectUser, SQLSimpanUser As String
        SQLSelectUser = "SELECT username FROM tb_user WHERE username like'" & txtUserName.Text & "'"
        SQLSimpanUser = "INSERT INTO tb_user (username,namalengkap,umur,jeniskelamin,alamat,jabatan,password) VALUES ('" & txtUserName.Text & "',
'" & txtNickName.Text & "','" & txtAge.Text & "','" & txtGender.Text & "','" & txtAddress.Text & "','" & txtPosition.Text & "',MD5('" & txtPassword.Text & "'))"
        If (txtUserName.Text = "") Or (txtNickName.Text = "") Or (txtAge.Text = "") Or (txtGender.Text = "") Or (txtAddress.Text = "") Or (txtPosition.Text = "") Or (txtPassword.Text = "") Then
            MsgBox("Data belum lengkap!", MsgBoxStyle.Critical, "Kesalahan")
            txtUserName.Focus()
            Exit Sub
        End If
        If (txtPosition.Text = "Dokter") And KoneksiDB.CariData(SQLSelectUser) <> True Then
            Call KoneksiDB.ProsesSQL(SQLSimpanUser)
            Me.Hide()
            MsgBox("Data berhasil ditambahkan", vbInformation, "Tambah Data")
            DokterDashboard.ShowDialog()
            Me.Close()
        ElseIf (txtPosition.Text = "Admin") And KoneksiDB.CariData(SQLSelectUser) <> True Then
            Call KoneksiDB.ProsesSQL(SQLSimpanUser)
            Me.Hide()
            MsgBox("Data berhasil ditambahkan", vbInformation, "Tambah Data")
            AdminDashboard.ShowDialog()
            Me.Close()
        ElseIf (txtPosition.Text = "Apoteker") And KoneksiDB.CariData(SQLSelectUser) <> True Then
            Call KoneksiDB.ProsesSQL(SQLSimpanUser)
            Me.Hide()
            MsgBox("Data berhasil ditambahkan", vbInformation, "Tambah Data")
            ApotekerDashboard.ShowDialog()
            Me.Close()
        ElseIf (txtPosition.Text = "Loketor") And KoneksiDB.CariData(SQLSelectUser) <> True Then
            Call KoneksiDB.ProsesSQL(SQLSimpanUser)
            Me.Hide()
            MsgBox("Data berhasil ditambahkan", vbInformation, "Tambah Data")
            LoketorDashboard.ShowDialog()
            Me.Close()
        Else
            MsgBox("Username sudah terdaftar", vbInformation, "Info")
        End If
    End Sub

    Private Sub btnKeluar_Click(sender As Object, e As EventArgs) Handles btnKeluar.Click
        Me.Close()
    End Sub


End Class