﻿Public Class SplashScreen
    Private Sub SplashScreen_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblLoading.Text = "Loading"
        prgLoading.Value = 0
        TmrLoading.Start()
    End Sub

    Private Sub TmrLoading_Tick(sender As Object, e As EventArgs) Handles TmrLoading.Tick
        If prgLoading.Value < 100 Then
            lblPersen.Text = CStr(prgLoading.Value & " %")
            prgLoading.Value += 1
        ElseIf prgLoading.Value = 100 Then
            TmrLoading.Stop()
            Me.Hide()
            LoginScreen.ShowDialog()
            Me.Close()
        End If

        If prgLoading.Value < 40 Then
            lblLoading.Text = "Loading database...."
        ElseIf prgLoading.Value < 80 Then
            lblLoading.Text = "Loading interface..."
        ElseIf prgLoading.Value < 100 Then
            lblLoading.Text = "Loading progress...."
        End If
    End Sub
End Class
