﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminDashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AdminDashboard))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.appBar = New System.Windows.Forms.Panel()
        Me.txtJadwal = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.showMenuItem = New System.Windows.Forms.PictureBox()
        Me.hideMenuItem = New System.Windows.Forms.PictureBox()
        Me.pictureAkun = New System.Windows.Forms.PictureBox()
        Me.listMenuItem = New System.Windows.Forms.Panel()
        Me.pictureKeluar = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pictureLaporan = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.pictureTransaksi = New System.Windows.Forms.PictureBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.picturePasien = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.pictureDashboard = New System.Windows.Forms.PictureBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.buttonKeluar = New System.Windows.Forms.Button()
        Me.buttonDaftarUser = New System.Windows.Forms.Button()
        Me.buttonAkun = New System.Windows.Forms.Button()
        Me.buttonLaporan = New System.Windows.Forms.Button()
        Me.buttonTransaksi = New System.Windows.Forms.Button()
        Me.buttonDaftar_Pasien = New System.Windows.Forms.Button()
        Me.buttonDashboard = New System.Windows.Forms.Button()
        Me.textKeterangan = New System.Windows.Forms.Label()
        Me.panelDaftarPasien = New System.Windows.Forms.Panel()
        Me.panelBerandaDP = New System.Windows.Forms.Panel()
        Me.panelDatabaseDP = New System.Windows.Forms.Panel()
        Me.panelDGVPasien = New System.Windows.Forms.Panel()
        Me.TLPNoData = New System.Windows.Forms.TableLayoutPanel()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.dgvDaftarPasien = New System.Windows.Forms.DataGridView()
        Me.panelTab = New System.Windows.Forms.Panel()
        Me.panelTengah = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.btnSemuaPasien = New System.Windows.Forms.Button()
        Me.btnBelumSelesaiPasien = New System.Windows.Forms.Button()
        Me.panelAtas = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.panelKanan = New System.Windows.Forms.Panel()
        Me.panelKiri = New System.Windows.Forms.Panel()
        Me.panelFormulirPasien = New System.Windows.Forms.Panel()
        Me.Panel85 = New System.Windows.Forms.Panel()
        Me.Panel90 = New System.Windows.Forms.Panel()
        Me.Panel91 = New System.Windows.Forms.Panel()
        Me.txtFaskesPasien = New System.Windows.Forms.ComboBox()
        Me.Panel92 = New System.Windows.Forms.Panel()
        Me.Panel93 = New System.Windows.Forms.Panel()
        Me.txtAlamatPasien = New System.Windows.Forms.TextBox()
        Me.Panel94 = New System.Windows.Forms.Panel()
        Me.Panel95 = New System.Windows.Forms.Panel()
        Me.txtJenisKelaminPasien = New System.Windows.Forms.ComboBox()
        Me.Panel96 = New System.Windows.Forms.Panel()
        Me.Panel97 = New System.Windows.Forms.Panel()
        Me.txtUmurPasien = New System.Windows.Forms.TextBox()
        Me.Panel98 = New System.Windows.Forms.Panel()
        Me.Panel99 = New System.Windows.Forms.Panel()
        Me.txtNamaLengkapPasien = New System.Windows.Forms.TextBox()
        Me.Panel100 = New System.Windows.Forms.Panel()
        Me.Panel101 = New System.Windows.Forms.Panel()
        Me.txtUserNamePasien = New System.Windows.Forms.TextBox()
        Me.Panel88 = New System.Windows.Forms.Panel()
        Me.Panel89 = New System.Windows.Forms.Panel()
        Me.txtNIKPasien = New System.Windows.Forms.TextBox()
        Me.Panel102 = New System.Windows.Forms.Panel()
        Me.Panel103 = New System.Windows.Forms.Panel()
        Me.Panel104 = New System.Windows.Forms.Panel()
        Me.Panel105 = New System.Windows.Forms.Panel()
        Me.Panel106 = New System.Windows.Forms.Panel()
        Me.Panel107 = New System.Windows.Forms.Panel()
        Me.Panel108 = New System.Windows.Forms.Panel()
        Me.Panel109 = New System.Windows.Forms.Panel()
        Me.btnBatalPasien = New System.Windows.Forms.Button()
        Me.Panel110 = New System.Windows.Forms.Panel()
        Me.Panel111 = New System.Windows.Forms.Panel()
        Me.Panel112 = New System.Windows.Forms.Panel()
        Me.Panel113 = New System.Windows.Forms.Panel()
        Me.Panel114 = New System.Windows.Forms.Panel()
        Me.Panel115 = New System.Windows.Forms.Panel()
        Me.btnSimpanPasien = New System.Windows.Forms.Button()
        Me.Panel116 = New System.Windows.Forms.Panel()
        Me.Panel117 = New System.Windows.Forms.Panel()
        Me.Panel122 = New System.Windows.Forms.Panel()
        Me.Panel123 = New System.Windows.Forms.Panel()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Panel124 = New System.Windows.Forms.Panel()
        Me.Panel125 = New System.Windows.Forms.Panel()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Panel126 = New System.Windows.Forms.Panel()
        Me.Panel127 = New System.Windows.Forms.Panel()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Panel128 = New System.Windows.Forms.Panel()
        Me.Panel129 = New System.Windows.Forms.Panel()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Panel130 = New System.Windows.Forms.Panel()
        Me.Panel131 = New System.Windows.Forms.Panel()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Panel132 = New System.Windows.Forms.Panel()
        Me.Panel133 = New System.Windows.Forms.Panel()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Panel120 = New System.Windows.Forms.Panel()
        Me.Panel121 = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Panel134 = New System.Windows.Forms.Panel()
        Me.Panel135 = New System.Windows.Forms.Panel()
        Me.Panel136 = New System.Windows.Forms.Panel()
        Me.Panel137 = New System.Windows.Forms.Panel()
        Me.btnTambahPasien = New System.Windows.Forms.Button()
        Me.Panel138 = New System.Windows.Forms.Panel()
        Me.btnEditPasien = New System.Windows.Forms.Button()
        Me.Panel139 = New System.Windows.Forms.Panel()
        Me.btnHapusPasien = New System.Windows.Forms.Button()
        Me.Panel140 = New System.Windows.Forms.Panel()
        Me.btnRefreshPasien = New System.Windows.Forms.Button()
        Me.Panel141 = New System.Windows.Forms.Panel()
        Me.Panel142 = New System.Windows.Forms.Panel()
        Me.Panel143 = New System.Windows.Forms.Panel()
        Me.Panel144 = New System.Windows.Forms.Panel()
        Me.Panel145 = New System.Windows.Forms.Panel()
        Me.Panel146 = New System.Windows.Forms.Panel()
        Me.txtCariPasien = New System.Windows.Forms.TextBox()
        Me.Panel147 = New System.Windows.Forms.Panel()
        Me.btnCariPasien = New System.Windows.Forms.Button()
        Me.Panel148 = New System.Windows.Forms.Panel()
        Me.Panel149 = New System.Windows.Forms.Panel()
        Me.Panel150 = New System.Windows.Forms.Panel()
        Me.Panel151 = New System.Windows.Forms.Panel()
        Me.panelKeteranganDP = New System.Windows.Forms.Panel()
        Me.VScrollBar1 = New System.Windows.Forms.VScrollBar()
        Me.panelTindakanDP = New System.Windows.Forms.Panel()
        Me.Panel164 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.btn_IP_AjukanDokter = New System.Windows.Forms.Button()
        Me.btn_IP_Batal = New System.Windows.Forms.Button()
        Me.Panel84 = New System.Windows.Forms.Panel()
        Me.Panel167 = New System.Windows.Forms.Panel()
        Me.Panel170 = New System.Windows.Forms.Panel()
        Me.Panel173 = New System.Windows.Forms.Panel()
        Me.txt_IP_Faskes = New System.Windows.Forms.Label()
        Me.Panel174 = New System.Windows.Forms.Panel()
        Me.Panel175 = New System.Windows.Forms.Panel()
        Me.txt_IP_Alamat = New System.Windows.Forms.Label()
        Me.Panel176 = New System.Windows.Forms.Panel()
        Me.Panel177 = New System.Windows.Forms.Panel()
        Me.txt_IP_JenisKelamin = New System.Windows.Forms.Label()
        Me.Panel178 = New System.Windows.Forms.Panel()
        Me.Panel179 = New System.Windows.Forms.Panel()
        Me.txt_IP_Umur = New System.Windows.Forms.Label()
        Me.Panel180 = New System.Windows.Forms.Panel()
        Me.Panel181 = New System.Windows.Forms.Panel()
        Me.txt_IP_NamaLengkap = New System.Windows.Forms.Label()
        Me.Panel182 = New System.Windows.Forms.Panel()
        Me.Panel183 = New System.Windows.Forms.Panel()
        Me.txt_IP_UserName = New System.Windows.Forms.Label()
        Me.Panel86 = New System.Windows.Forms.Panel()
        Me.Panel87 = New System.Windows.Forms.Panel()
        Me.txt_IP_NIK = New System.Windows.Forms.Label()
        Me.Panel184 = New System.Windows.Forms.Panel()
        Me.Panel185 = New System.Windows.Forms.Panel()
        Me.Panel188 = New System.Windows.Forms.Panel()
        Me.Panel191 = New System.Windows.Forms.Panel()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Panel192 = New System.Windows.Forms.Panel()
        Me.Panel193 = New System.Windows.Forms.Panel()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Panel194 = New System.Windows.Forms.Panel()
        Me.Panel195 = New System.Windows.Forms.Panel()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Panel196 = New System.Windows.Forms.Panel()
        Me.Panel197 = New System.Windows.Forms.Panel()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Panel198 = New System.Windows.Forms.Panel()
        Me.Panel199 = New System.Windows.Forms.Panel()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Panel200 = New System.Windows.Forms.Panel()
        Me.Panel201 = New System.Windows.Forms.Panel()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Panel119 = New System.Windows.Forms.Panel()
        Me.Panel118 = New System.Windows.Forms.Panel()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Panel202 = New System.Windows.Forms.Panel()
        Me.Panel240 = New System.Windows.Forms.Panel()
        Me.Panel165 = New System.Windows.Forms.Panel()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.btn_IP_Kembali = New System.Windows.Forms.Button()
        Me.panelTransaksi = New System.Windows.Forms.Panel()
        Me.panelDatabaseTransaksi = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.btnBelumBayar = New System.Windows.Forms.Button()
        Me.btnSemuaTransaksi = New System.Windows.Forms.Button()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Panel157 = New System.Windows.Forms.Panel()
        Me.Panel158 = New System.Windows.Forms.Panel()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Panel159 = New System.Windows.Forms.Panel()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Panel160 = New System.Windows.Forms.Panel()
        Me.Panel161 = New System.Windows.Forms.Panel()
        Me.Panel162 = New System.Windows.Forms.Panel()
        Me.Panel163 = New System.Windows.Forms.Panel()
        Me.panelKeteranganTransaksi = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.VScrollBar2 = New System.Windows.Forms.VScrollBar()
        Me.panelDashboard = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel35 = New System.Windows.Forms.Panel()
        Me.Panel156 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Panel155 = New System.Windows.Forms.Panel()
        Me.Panel154 = New System.Windows.Forms.Panel()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Panel153 = New System.Windows.Forms.Panel()
        Me.Panel152 = New System.Windows.Forms.Panel()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.VScrollBar3 = New System.Windows.Forms.VScrollBar()
        Me.panelLaporan = New System.Windows.Forms.Panel()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.VScrollBar4 = New System.Windows.Forms.VScrollBar()
        Me.panelAkun = New System.Windows.Forms.Panel()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.txtNamaPengguna = New System.Windows.Forms.Label()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.VScrollBar5 = New System.Windows.Forms.VScrollBar()
        Me.panelGrup = New System.Windows.Forms.Panel()
        Me.panelDaftarUser = New System.Windows.Forms.Panel()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.dgvDaftarUser = New System.Windows.Forms.DataGridView()
        Me.panelFormulir = New System.Windows.Forms.Panel()
        Me.Panel40 = New System.Windows.Forms.Panel()
        Me.Panel61 = New System.Windows.Forms.Panel()
        Me.Panel60 = New System.Windows.Forms.Panel()
        Me.txtKonfirmasiPassword = New System.Windows.Forms.TextBox()
        Me.Panel59 = New System.Windows.Forms.Panel()
        Me.Panel58 = New System.Windows.Forms.Panel()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.Panel57 = New System.Windows.Forms.Panel()
        Me.Panel56 = New System.Windows.Forms.Panel()
        Me.txtPosition = New System.Windows.Forms.ComboBox()
        Me.Panel55 = New System.Windows.Forms.Panel()
        Me.Panel54 = New System.Windows.Forms.Panel()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.Panel53 = New System.Windows.Forms.Panel()
        Me.Panel52 = New System.Windows.Forms.Panel()
        Me.txtGender = New System.Windows.Forms.ComboBox()
        Me.Panel51 = New System.Windows.Forms.Panel()
        Me.Panel50 = New System.Windows.Forms.Panel()
        Me.txtAge = New System.Windows.Forms.TextBox()
        Me.Panel49 = New System.Windows.Forms.Panel()
        Me.Panel48 = New System.Windows.Forms.Panel()
        Me.txtNickName = New System.Windows.Forms.TextBox()
        Me.Panel47 = New System.Windows.Forms.Panel()
        Me.Panel46 = New System.Windows.Forms.Panel()
        Me.txtUserName = New System.Windows.Forms.TextBox()
        Me.Panel45 = New System.Windows.Forms.Panel()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.Panel62 = New System.Windows.Forms.Panel()
        Me.Panel39 = New System.Windows.Forms.Panel()
        Me.Panel63 = New System.Windows.Forms.Panel()
        Me.Panel64 = New System.Windows.Forms.Panel()
        Me.Panel65 = New System.Windows.Forms.Panel()
        Me.Panel66 = New System.Windows.Forms.Panel()
        Me.btnBatal = New System.Windows.Forms.Button()
        Me.Panel38 = New System.Windows.Forms.Panel()
        Me.Panel37 = New System.Windows.Forms.Panel()
        Me.Panel44 = New System.Windows.Forms.Panel()
        Me.Panel43 = New System.Windows.Forms.Panel()
        Me.Panel42 = New System.Windows.Forms.Panel()
        Me.Panel41 = New System.Windows.Forms.Panel()
        Me.btnSimpan = New System.Windows.Forms.Button()
        Me.Panel36 = New System.Windows.Forms.Panel()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.Panel82 = New System.Windows.Forms.Panel()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Panel67 = New System.Windows.Forms.Panel()
        Me.Panel68 = New System.Windows.Forms.Panel()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Panel69 = New System.Windows.Forms.Panel()
        Me.Panel70 = New System.Windows.Forms.Panel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Panel71 = New System.Windows.Forms.Panel()
        Me.Panel72 = New System.Windows.Forms.Panel()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Panel73 = New System.Windows.Forms.Panel()
        Me.Panel74 = New System.Windows.Forms.Panel()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Panel75 = New System.Windows.Forms.Panel()
        Me.Panel76 = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Panel77 = New System.Windows.Forms.Panel()
        Me.Panel78 = New System.Windows.Forms.Panel()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Panel79 = New System.Windows.Forms.Panel()
        Me.Panel80 = New System.Windows.Forms.Panel()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Panel81 = New System.Windows.Forms.Panel()
        Me.Panel83 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.btnTambah = New System.Windows.Forms.Button()
        Me.Panel34 = New System.Windows.Forms.Panel()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.btnHapus = New System.Windows.Forms.Button()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.Panel30 = New System.Windows.Forms.Panel()
        Me.Panel31 = New System.Windows.Forms.Panel()
        Me.Panel32 = New System.Windows.Forms.Panel()
        Me.Panel33 = New System.Windows.Forms.Panel()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.txtCariNamaPengguna = New System.Windows.Forms.TextBox()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.btnCariPengguna = New System.Windows.Forms.Button()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.Panel26 = New System.Windows.Forms.Panel()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.VScrollBar6 = New System.Windows.Forms.VScrollBar()
        Me.jadwal = New System.Windows.Forms.Timer(Me.components)
        Me.appBar.SuspendLayout()
        CType(Me.showMenuItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.hideMenuItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureAkun, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.listMenuItem.SuspendLayout()
        CType(Me.pictureKeluar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureLaporan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureTransaksi, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picturePasien, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureDashboard, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDaftarPasien.SuspendLayout()
        Me.panelBerandaDP.SuspendLayout()
        Me.panelDatabaseDP.SuspendLayout()
        Me.panelDGVPasien.SuspendLayout()
        Me.TLPNoData.SuspendLayout()
        CType(Me.dgvDaftarPasien, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelTab.SuspendLayout()
        Me.panelTengah.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.panelFormulirPasien.SuspendLayout()
        Me.Panel85.SuspendLayout()
        Me.Panel91.SuspendLayout()
        Me.Panel93.SuspendLayout()
        Me.Panel95.SuspendLayout()
        Me.Panel97.SuspendLayout()
        Me.Panel99.SuspendLayout()
        Me.Panel101.SuspendLayout()
        Me.Panel89.SuspendLayout()
        Me.Panel103.SuspendLayout()
        Me.Panel105.SuspendLayout()
        Me.Panel111.SuspendLayout()
        Me.Panel117.SuspendLayout()
        Me.Panel123.SuspendLayout()
        Me.Panel125.SuspendLayout()
        Me.Panel127.SuspendLayout()
        Me.Panel129.SuspendLayout()
        Me.Panel131.SuspendLayout()
        Me.Panel133.SuspendLayout()
        Me.Panel121.SuspendLayout()
        Me.Panel136.SuspendLayout()
        Me.Panel137.SuspendLayout()
        Me.Panel145.SuspendLayout()
        Me.Panel146.SuspendLayout()
        Me.panelKeteranganDP.SuspendLayout()
        Me.panelTindakanDP.SuspendLayout()
        Me.Panel164.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel84.SuspendLayout()
        Me.Panel167.SuspendLayout()
        Me.Panel173.SuspendLayout()
        Me.Panel175.SuspendLayout()
        Me.Panel177.SuspendLayout()
        Me.Panel179.SuspendLayout()
        Me.Panel181.SuspendLayout()
        Me.Panel183.SuspendLayout()
        Me.Panel87.SuspendLayout()
        Me.Panel185.SuspendLayout()
        Me.Panel191.SuspendLayout()
        Me.Panel193.SuspendLayout()
        Me.Panel195.SuspendLayout()
        Me.Panel197.SuspendLayout()
        Me.Panel199.SuspendLayout()
        Me.Panel201.SuspendLayout()
        Me.Panel118.SuspendLayout()
        Me.Panel240.SuspendLayout()
        Me.Panel165.SuspendLayout()
        Me.panelTransaksi.SuspendLayout()
        Me.panelDatabaseTransaksi.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel157.SuspendLayout()
        Me.Panel158.SuspendLayout()
        Me.panelKeteranganTransaksi.SuspendLayout()
        Me.panelDashboard.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel35.SuspendLayout()
        Me.Panel156.SuspendLayout()
        Me.Panel154.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.panelLaporan.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.panelAkun.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.panelGrup.SuspendLayout()
        Me.panelDaftarUser.SuspendLayout()
        Me.Panel14.SuspendLayout()
        CType(Me.dgvDaftarUser, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFormulir.SuspendLayout()
        Me.Panel40.SuspendLayout()
        Me.Panel60.SuspendLayout()
        Me.Panel58.SuspendLayout()
        Me.Panel56.SuspendLayout()
        Me.Panel54.SuspendLayout()
        Me.Panel52.SuspendLayout()
        Me.Panel50.SuspendLayout()
        Me.Panel48.SuspendLayout()
        Me.Panel46.SuspendLayout()
        Me.Panel23.SuspendLayout()
        Me.Panel39.SuspendLayout()
        Me.Panel37.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.Panel25.SuspendLayout()
        Me.Panel68.SuspendLayout()
        Me.Panel70.SuspendLayout()
        Me.Panel72.SuspendLayout()
        Me.Panel74.SuspendLayout()
        Me.Panel76.SuspendLayout()
        Me.Panel78.SuspendLayout()
        Me.Panel80.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel27.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.Panel22.SuspendLayout()
        Me.SuspendLayout()
        '
        'appBar
        '
        Me.appBar.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.appBar.Controls.Add(Me.txtJadwal)
        Me.appBar.Controls.Add(Me.Label8)
        Me.appBar.Controls.Add(Me.showMenuItem)
        Me.appBar.Controls.Add(Me.hideMenuItem)
        Me.appBar.Dock = System.Windows.Forms.DockStyle.Top
        Me.appBar.Location = New System.Drawing.Point(0, 0)
        Me.appBar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.appBar.Name = "appBar"
        Me.appBar.Size = New System.Drawing.Size(911, 48)
        Me.appBar.TabIndex = 0
        '
        'txtJadwal
        '
        Me.txtJadwal.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtJadwal.AutoSize = True
        Me.txtJadwal.Location = New System.Drawing.Point(750, 15)
        Me.txtJadwal.Name = "txtJadwal"
        Me.txtJadwal.Size = New System.Drawing.Size(108, 17)
        Me.txtJadwal.TabIndex = 3
        Me.txtJadwal.Text = "Tanggal, Waktu"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(65, 7)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(101, 32)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Admin"
        '
        'showMenuItem
        '
        Me.showMenuItem.BackgroundImage = CType(resources.GetObject("showMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.showMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.showMenuItem.Location = New System.Drawing.Point(12, 6)
        Me.showMenuItem.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.showMenuItem.Name = "showMenuItem"
        Me.showMenuItem.Size = New System.Drawing.Size(37, 33)
        Me.showMenuItem.TabIndex = 0
        Me.showMenuItem.TabStop = False
        '
        'hideMenuItem
        '
        Me.hideMenuItem.BackgroundImage = CType(resources.GetObject("hideMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.hideMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.hideMenuItem.Location = New System.Drawing.Point(12, 6)
        Me.hideMenuItem.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.hideMenuItem.Name = "hideMenuItem"
        Me.hideMenuItem.Size = New System.Drawing.Size(37, 33)
        Me.hideMenuItem.TabIndex = 0
        Me.hideMenuItem.TabStop = False
        '
        'pictureAkun
        '
        Me.pictureAkun.BackgroundImage = CType(resources.GetObject("pictureAkun.BackgroundImage"), System.Drawing.Image)
        Me.pictureAkun.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureAkun.Location = New System.Drawing.Point(13, 274)
        Me.pictureAkun.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.pictureAkun.Name = "pictureAkun"
        Me.pictureAkun.Size = New System.Drawing.Size(51, 50)
        Me.pictureAkun.TabIndex = 0
        Me.pictureAkun.TabStop = False
        '
        'listMenuItem
        '
        Me.listMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.listMenuItem.Controls.Add(Me.pictureKeluar)
        Me.listMenuItem.Controls.Add(Me.pictureAkun)
        Me.listMenuItem.Controls.Add(Me.Label3)
        Me.listMenuItem.Controls.Add(Me.pictureLaporan)
        Me.listMenuItem.Controls.Add(Me.Label5)
        Me.listMenuItem.Controls.Add(Me.pictureTransaksi)
        Me.listMenuItem.Controls.Add(Me.Label7)
        Me.listMenuItem.Controls.Add(Me.PictureBox1)
        Me.listMenuItem.Controls.Add(Me.picturePasien)
        Me.listMenuItem.Controls.Add(Me.Label6)
        Me.listMenuItem.Controls.Add(Me.pictureDashboard)
        Me.listMenuItem.Controls.Add(Me.Label12)
        Me.listMenuItem.Controls.Add(Me.Label2)
        Me.listMenuItem.Controls.Add(Me.Label1)
        Me.listMenuItem.Controls.Add(Me.buttonKeluar)
        Me.listMenuItem.Controls.Add(Me.buttonDaftarUser)
        Me.listMenuItem.Controls.Add(Me.buttonAkun)
        Me.listMenuItem.Controls.Add(Me.buttonLaporan)
        Me.listMenuItem.Controls.Add(Me.buttonTransaksi)
        Me.listMenuItem.Controls.Add(Me.buttonDaftar_Pasien)
        Me.listMenuItem.Controls.Add(Me.buttonDashboard)
        Me.listMenuItem.Dock = System.Windows.Forms.DockStyle.Left
        Me.listMenuItem.Location = New System.Drawing.Point(0, 48)
        Me.listMenuItem.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.listMenuItem.Name = "listMenuItem"
        Me.listMenuItem.Size = New System.Drawing.Size(231, 583)
        Me.listMenuItem.TabIndex = 1
        '
        'pictureKeluar
        '
        Me.pictureKeluar.BackgroundImage = CType(resources.GetObject("pictureKeluar.BackgroundImage"), System.Drawing.Image)
        Me.pictureKeluar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureKeluar.Location = New System.Drawing.Point(12, 411)
        Me.pictureKeluar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.pictureKeluar.Name = "pictureKeluar"
        Me.pictureKeluar.Size = New System.Drawing.Size(51, 50)
        Me.pictureKeluar.TabIndex = 0
        Me.pictureKeluar.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(65, 425)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 29)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Keluar"
        '
        'pictureLaporan
        '
        Me.pictureLaporan.BackgroundImage = CType(resources.GetObject("pictureLaporan.BackgroundImage"), System.Drawing.Image)
        Me.pictureLaporan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureLaporan.Location = New System.Drawing.Point(13, 208)
        Me.pictureLaporan.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.pictureLaporan.Name = "pictureLaporan"
        Me.pictureLaporan.Size = New System.Drawing.Size(51, 50)
        Me.pictureLaporan.TabIndex = 0
        Me.pictureLaporan.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(67, 286)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 29)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Akun"
        '
        'pictureTransaksi
        '
        Me.pictureTransaksi.BackgroundImage = CType(resources.GetObject("pictureTransaksi.BackgroundImage"), System.Drawing.Image)
        Me.pictureTransaksi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureTransaksi.Location = New System.Drawing.Point(13, 142)
        Me.pictureTransaksi.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.pictureTransaksi.Name = "pictureTransaksi"
        Me.pictureTransaksi.Size = New System.Drawing.Size(51, 50)
        Me.pictureTransaksi.TabIndex = 0
        Me.pictureTransaksi.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(67, 219)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(101, 29)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Laporan"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(12, 343)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(51, 50)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'picturePasien
        '
        Me.picturePasien.BackgroundImage = CType(resources.GetObject("picturePasien.BackgroundImage"), System.Drawing.Image)
        Me.picturePasien.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picturePasien.Location = New System.Drawing.Point(13, 76)
        Me.picturePasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.picturePasien.Name = "picturePasien"
        Me.picturePasien.Size = New System.Drawing.Size(51, 50)
        Me.picturePasien.TabIndex = 0
        Me.picturePasien.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(67, 151)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(118, 29)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Transaksi"
        '
        'pictureDashboard
        '
        Me.pictureDashboard.BackgroundImage = CType(resources.GetObject("pictureDashboard.BackgroundImage"), System.Drawing.Image)
        Me.pictureDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictureDashboard.Location = New System.Drawing.Point(13, 7)
        Me.pictureDashboard.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.pictureDashboard.Name = "pictureDashboard"
        Me.pictureDashboard.Size = New System.Drawing.Size(51, 50)
        Me.pictureDashboard.TabIndex = 0
        Me.pictureDashboard.TabStop = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(65, 354)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(133, 29)
        Me.Label12.TabIndex = 2
        Me.Label12.Text = "Daftar User"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(67, 89)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(156, 29)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Daftar Pasien"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(67, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(131, 29)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Dashboard"
        '
        'buttonKeluar
        '
        Me.buttonKeluar.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonKeluar.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonKeluar.Location = New System.Drawing.Point(0, 396)
        Me.buttonKeluar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.buttonKeluar.Name = "buttonKeluar"
        Me.buttonKeluar.Size = New System.Drawing.Size(231, 66)
        Me.buttonKeluar.TabIndex = 3
        Me.buttonKeluar.UseVisualStyleBackColor = False
        '
        'buttonDaftarUser
        '
        Me.buttonDaftarUser.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonDaftarUser.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonDaftarUser.Location = New System.Drawing.Point(0, 330)
        Me.buttonDaftarUser.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.buttonDaftarUser.Name = "buttonDaftarUser"
        Me.buttonDaftarUser.Size = New System.Drawing.Size(231, 66)
        Me.buttonDaftarUser.TabIndex = 0
        Me.buttonDaftarUser.UseVisualStyleBackColor = False
        '
        'buttonAkun
        '
        Me.buttonAkun.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonAkun.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonAkun.Location = New System.Drawing.Point(0, 264)
        Me.buttonAkun.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.buttonAkun.Name = "buttonAkun"
        Me.buttonAkun.Size = New System.Drawing.Size(231, 66)
        Me.buttonAkun.TabIndex = 3
        Me.buttonAkun.UseVisualStyleBackColor = False
        '
        'buttonLaporan
        '
        Me.buttonLaporan.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonLaporan.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonLaporan.Location = New System.Drawing.Point(0, 198)
        Me.buttonLaporan.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.buttonLaporan.Name = "buttonLaporan"
        Me.buttonLaporan.Size = New System.Drawing.Size(231, 66)
        Me.buttonLaporan.TabIndex = 3
        Me.buttonLaporan.UseVisualStyleBackColor = False
        '
        'buttonTransaksi
        '
        Me.buttonTransaksi.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonTransaksi.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonTransaksi.Location = New System.Drawing.Point(0, 132)
        Me.buttonTransaksi.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.buttonTransaksi.Name = "buttonTransaksi"
        Me.buttonTransaksi.Size = New System.Drawing.Size(231, 66)
        Me.buttonTransaksi.TabIndex = 3
        Me.buttonTransaksi.UseVisualStyleBackColor = False
        '
        'buttonDaftar_Pasien
        '
        Me.buttonDaftar_Pasien.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonDaftar_Pasien.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonDaftar_Pasien.Location = New System.Drawing.Point(0, 66)
        Me.buttonDaftar_Pasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.buttonDaftar_Pasien.Name = "buttonDaftar_Pasien"
        Me.buttonDaftar_Pasien.Size = New System.Drawing.Size(231, 66)
        Me.buttonDaftar_Pasien.TabIndex = 3
        Me.buttonDaftar_Pasien.UseVisualStyleBackColor = False
        '
        'buttonDashboard
        '
        Me.buttonDashboard.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.buttonDashboard.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonDashboard.Location = New System.Drawing.Point(0, 0)
        Me.buttonDashboard.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.buttonDashboard.Name = "buttonDashboard"
        Me.buttonDashboard.Size = New System.Drawing.Size(231, 66)
        Me.buttonDashboard.TabIndex = 3
        Me.buttonDashboard.UseVisualStyleBackColor = False
        '
        'textKeterangan
        '
        Me.textKeterangan.AutoSize = True
        Me.textKeterangan.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.textKeterangan.Location = New System.Drawing.Point(16, 18)
        Me.textKeterangan.Name = "textKeterangan"
        Me.textKeterangan.Size = New System.Drawing.Size(179, 29)
        Me.textKeterangan.TabIndex = 2
        Me.textKeterangan.Text = "Daftar Pasien"
        '
        'panelDaftarPasien
        '
        Me.panelDaftarPasien.Controls.Add(Me.panelBerandaDP)
        Me.panelDaftarPasien.Controls.Add(Me.panelTindakanDP)
        Me.panelDaftarPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDaftarPasien.Location = New System.Drawing.Point(0, 0)
        Me.panelDaftarPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDaftarPasien.Name = "panelDaftarPasien"
        Me.panelDaftarPasien.Size = New System.Drawing.Size(680, 583)
        Me.panelDaftarPasien.TabIndex = 3
        '
        'panelBerandaDP
        '
        Me.panelBerandaDP.Controls.Add(Me.panelDatabaseDP)
        Me.panelBerandaDP.Controls.Add(Me.panelFormulirPasien)
        Me.panelBerandaDP.Controls.Add(Me.Panel136)
        Me.panelBerandaDP.Controls.Add(Me.Panel145)
        Me.panelBerandaDP.Controls.Add(Me.panelKeteranganDP)
        Me.panelBerandaDP.Controls.Add(Me.VScrollBar1)
        Me.panelBerandaDP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelBerandaDP.Location = New System.Drawing.Point(0, 0)
        Me.panelBerandaDP.Name = "panelBerandaDP"
        Me.panelBerandaDP.Size = New System.Drawing.Size(680, 583)
        Me.panelBerandaDP.TabIndex = 0
        '
        'panelDatabaseDP
        '
        Me.panelDatabaseDP.Controls.Add(Me.panelDGVPasien)
        Me.panelDatabaseDP.Controls.Add(Me.panelTab)
        Me.panelDatabaseDP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDatabaseDP.Location = New System.Drawing.Point(0, 454)
        Me.panelDatabaseDP.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDatabaseDP.Name = "panelDatabaseDP"
        Me.panelDatabaseDP.Size = New System.Drawing.Size(659, 129)
        Me.panelDatabaseDP.TabIndex = 5
        '
        'panelDGVPasien
        '
        Me.panelDGVPasien.Controls.Add(Me.TLPNoData)
        Me.panelDGVPasien.Controls.Add(Me.dgvDaftarPasien)
        Me.panelDGVPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDGVPasien.Location = New System.Drawing.Point(0, 62)
        Me.panelDGVPasien.Name = "panelDGVPasien"
        Me.panelDGVPasien.Size = New System.Drawing.Size(659, 67)
        Me.panelDGVPasien.TabIndex = 1
        '
        'TLPNoData
        '
        Me.TLPNoData.ColumnCount = 1
        Me.TLPNoData.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLPNoData.Controls.Add(Me.Label35, 0, 0)
        Me.TLPNoData.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLPNoData.Location = New System.Drawing.Point(0, 0)
        Me.TLPNoData.Name = "TLPNoData"
        Me.TLPNoData.RowCount = 1
        Me.TLPNoData.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLPNoData.Size = New System.Drawing.Size(659, 67)
        Me.TLPNoData.TabIndex = 0
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label35.Location = New System.Drawing.Point(3, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(653, 67)
        Me.Label35.TabIndex = 0
        Me.Label35.Text = "No Data"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'dgvDaftarPasien
        '
        Me.dgvDaftarPasien.AllowUserToAddRows = False
        Me.dgvDaftarPasien.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgvDaftarPasien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDaftarPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvDaftarPasien.GridColor = System.Drawing.SystemColors.Control
        Me.dgvDaftarPasien.Location = New System.Drawing.Point(0, 0)
        Me.dgvDaftarPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgvDaftarPasien.Name = "dgvDaftarPasien"
        Me.dgvDaftarPasien.ReadOnly = True
        Me.dgvDaftarPasien.RowHeadersWidth = 51
        Me.dgvDaftarPasien.RowTemplate.Height = 24
        Me.dgvDaftarPasien.Size = New System.Drawing.Size(659, 67)
        Me.dgvDaftarPasien.TabIndex = 1
        '
        'panelTab
        '
        Me.panelTab.Controls.Add(Me.panelTengah)
        Me.panelTab.Controls.Add(Me.panelKanan)
        Me.panelTab.Controls.Add(Me.panelKiri)
        Me.panelTab.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelTab.Location = New System.Drawing.Point(0, 0)
        Me.panelTab.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelTab.Name = "panelTab"
        Me.panelTab.Size = New System.Drawing.Size(659, 62)
        Me.panelTab.TabIndex = 0
        '
        'panelTengah
        '
        Me.panelTengah.Controls.Add(Me.TableLayoutPanel1)
        Me.panelTengah.Controls.Add(Me.panelAtas)
        Me.panelTengah.Controls.Add(Me.Panel1)
        Me.panelTengah.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelTengah.Location = New System.Drawing.Point(200, 0)
        Me.panelTengah.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelTengah.Name = "panelTengah"
        Me.panelTengah.Size = New System.Drawing.Size(259, 62)
        Me.panelTengah.TabIndex = 2
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.btnSemuaPasien, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.btnBelumSelesaiPasien, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 12)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(259, 38)
        Me.TableLayoutPanel1.TabIndex = 5
        '
        'btnSemuaPasien
        '
        Me.btnSemuaPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnSemuaPasien.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnSemuaPasien.FlatAppearance.BorderSize = 2
        Me.btnSemuaPasien.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSemuaPasien.Location = New System.Drawing.Point(132, 2)
        Me.btnSemuaPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSemuaPasien.Name = "btnSemuaPasien"
        Me.btnSemuaPasien.Size = New System.Drawing.Size(124, 34)
        Me.btnSemuaPasien.TabIndex = 4
        Me.btnSemuaPasien.Text = "Semua"
        Me.btnSemuaPasien.UseVisualStyleBackColor = True
        '
        'btnBelumSelesaiPasien
        '
        Me.btnBelumSelesaiPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnBelumSelesaiPasien.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnBelumSelesaiPasien.FlatAppearance.BorderSize = 2
        Me.btnBelumSelesaiPasien.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBelumSelesaiPasien.Location = New System.Drawing.Point(3, 2)
        Me.btnBelumSelesaiPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBelumSelesaiPasien.Name = "btnBelumSelesaiPasien"
        Me.btnBelumSelesaiPasien.Size = New System.Drawing.Size(123, 34)
        Me.btnBelumSelesaiPasien.TabIndex = 1
        Me.btnBelumSelesaiPasien.Text = "Belum Selesai"
        Me.btnBelumSelesaiPasien.UseVisualStyleBackColor = True
        '
        'panelAtas
        '
        Me.panelAtas.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelAtas.Location = New System.Drawing.Point(0, 0)
        Me.panelAtas.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelAtas.Name = "panelAtas"
        Me.panelAtas.Size = New System.Drawing.Size(259, 12)
        Me.panelAtas.TabIndex = 2
        '
        'Panel1
        '
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 50)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(259, 12)
        Me.Panel1.TabIndex = 3
        '
        'panelKanan
        '
        Me.panelKanan.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelKanan.Location = New System.Drawing.Point(459, 0)
        Me.panelKanan.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelKanan.Name = "panelKanan"
        Me.panelKanan.Size = New System.Drawing.Size(200, 62)
        Me.panelKanan.TabIndex = 1
        '
        'panelKiri
        '
        Me.panelKiri.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelKiri.Location = New System.Drawing.Point(0, 0)
        Me.panelKiri.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelKiri.Name = "panelKiri"
        Me.panelKiri.Size = New System.Drawing.Size(200, 62)
        Me.panelKiri.TabIndex = 0
        '
        'panelFormulirPasien
        '
        Me.panelFormulirPasien.Controls.Add(Me.Panel85)
        Me.panelFormulirPasien.Controls.Add(Me.Panel103)
        Me.panelFormulirPasien.Controls.Add(Me.Panel117)
        Me.panelFormulirPasien.Controls.Add(Me.Panel135)
        Me.panelFormulirPasien.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFormulirPasien.Location = New System.Drawing.Point(0, 191)
        Me.panelFormulirPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelFormulirPasien.Name = "panelFormulirPasien"
        Me.panelFormulirPasien.Size = New System.Drawing.Size(659, 263)
        Me.panelFormulirPasien.TabIndex = 3
        '
        'Panel85
        '
        Me.Panel85.Controls.Add(Me.Panel90)
        Me.Panel85.Controls.Add(Me.Panel91)
        Me.Panel85.Controls.Add(Me.Panel92)
        Me.Panel85.Controls.Add(Me.Panel93)
        Me.Panel85.Controls.Add(Me.Panel94)
        Me.Panel85.Controls.Add(Me.Panel95)
        Me.Panel85.Controls.Add(Me.Panel96)
        Me.Panel85.Controls.Add(Me.Panel97)
        Me.Panel85.Controls.Add(Me.Panel98)
        Me.Panel85.Controls.Add(Me.Panel99)
        Me.Panel85.Controls.Add(Me.Panel100)
        Me.Panel85.Controls.Add(Me.Panel101)
        Me.Panel85.Controls.Add(Me.Panel88)
        Me.Panel85.Controls.Add(Me.Panel89)
        Me.Panel85.Controls.Add(Me.Panel102)
        Me.Panel85.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel85.Location = New System.Drawing.Point(178, 0)
        Me.Panel85.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel85.Name = "Panel85"
        Me.Panel85.Size = New System.Drawing.Size(326, 263)
        Me.Panel85.TabIndex = 1
        '
        'Panel90
        '
        Me.Panel90.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel90.Location = New System.Drawing.Point(0, 252)
        Me.Panel90.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel90.Name = "Panel90"
        Me.Panel90.Size = New System.Drawing.Size(326, 11)
        Me.Panel90.TabIndex = 11
        '
        'Panel91
        '
        Me.Panel91.Controls.Add(Me.txtFaskesPasien)
        Me.Panel91.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel91.Location = New System.Drawing.Point(0, 227)
        Me.Panel91.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel91.Name = "Panel91"
        Me.Panel91.Size = New System.Drawing.Size(326, 25)
        Me.Panel91.TabIndex = 11
        '
        'txtFaskesPasien
        '
        Me.txtFaskesPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtFaskesPasien.FormattingEnabled = True
        Me.txtFaskesPasien.Items.AddRange(New Object() {"BPJS", "Umum", "Asuransi"})
        Me.txtFaskesPasien.Location = New System.Drawing.Point(0, 0)
        Me.txtFaskesPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtFaskesPasien.Name = "txtFaskesPasien"
        Me.txtFaskesPasien.Size = New System.Drawing.Size(326, 24)
        Me.txtFaskesPasien.TabIndex = 4
        '
        'Panel92
        '
        Me.Panel92.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel92.Location = New System.Drawing.Point(0, 216)
        Me.Panel92.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel92.Name = "Panel92"
        Me.Panel92.Size = New System.Drawing.Size(326, 11)
        Me.Panel92.TabIndex = 10
        '
        'Panel93
        '
        Me.Panel93.Controls.Add(Me.txtAlamatPasien)
        Me.Panel93.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel93.Location = New System.Drawing.Point(0, 191)
        Me.Panel93.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel93.Name = "Panel93"
        Me.Panel93.Size = New System.Drawing.Size(326, 25)
        Me.Panel93.TabIndex = 9
        '
        'txtAlamatPasien
        '
        Me.txtAlamatPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtAlamatPasien.Location = New System.Drawing.Point(0, 0)
        Me.txtAlamatPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtAlamatPasien.Name = "txtAlamatPasien"
        Me.txtAlamatPasien.Size = New System.Drawing.Size(326, 22)
        Me.txtAlamatPasien.TabIndex = 2
        '
        'Panel94
        '
        Me.Panel94.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel94.Location = New System.Drawing.Point(0, 180)
        Me.Panel94.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel94.Name = "Panel94"
        Me.Panel94.Size = New System.Drawing.Size(326, 11)
        Me.Panel94.TabIndex = 8
        '
        'Panel95
        '
        Me.Panel95.Controls.Add(Me.txtJenisKelaminPasien)
        Me.Panel95.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel95.Location = New System.Drawing.Point(0, 155)
        Me.Panel95.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel95.Name = "Panel95"
        Me.Panel95.Size = New System.Drawing.Size(326, 25)
        Me.Panel95.TabIndex = 7
        '
        'txtJenisKelaminPasien
        '
        Me.txtJenisKelaminPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtJenisKelaminPasien.FormattingEnabled = True
        Me.txtJenisKelaminPasien.Items.AddRange(New Object() {"Laki-Laki", "Perempuan", "Tidak diketahui"})
        Me.txtJenisKelaminPasien.Location = New System.Drawing.Point(0, 0)
        Me.txtJenisKelaminPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtJenisKelaminPasien.Name = "txtJenisKelaminPasien"
        Me.txtJenisKelaminPasien.Size = New System.Drawing.Size(326, 24)
        Me.txtJenisKelaminPasien.TabIndex = 4
        '
        'Panel96
        '
        Me.Panel96.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel96.Location = New System.Drawing.Point(0, 144)
        Me.Panel96.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel96.Name = "Panel96"
        Me.Panel96.Size = New System.Drawing.Size(326, 11)
        Me.Panel96.TabIndex = 6
        '
        'Panel97
        '
        Me.Panel97.Controls.Add(Me.txtUmurPasien)
        Me.Panel97.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel97.Location = New System.Drawing.Point(0, 119)
        Me.Panel97.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel97.Name = "Panel97"
        Me.Panel97.Size = New System.Drawing.Size(326, 25)
        Me.Panel97.TabIndex = 5
        '
        'txtUmurPasien
        '
        Me.txtUmurPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtUmurPasien.Location = New System.Drawing.Point(0, 0)
        Me.txtUmurPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtUmurPasien.Name = "txtUmurPasien"
        Me.txtUmurPasien.Size = New System.Drawing.Size(326, 22)
        Me.txtUmurPasien.TabIndex = 2
        '
        'Panel98
        '
        Me.Panel98.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel98.Location = New System.Drawing.Point(0, 108)
        Me.Panel98.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel98.Name = "Panel98"
        Me.Panel98.Size = New System.Drawing.Size(326, 11)
        Me.Panel98.TabIndex = 4
        '
        'Panel99
        '
        Me.Panel99.Controls.Add(Me.txtNamaLengkapPasien)
        Me.Panel99.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel99.Location = New System.Drawing.Point(0, 83)
        Me.Panel99.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel99.Name = "Panel99"
        Me.Panel99.Size = New System.Drawing.Size(326, 25)
        Me.Panel99.TabIndex = 3
        '
        'txtNamaLengkapPasien
        '
        Me.txtNamaLengkapPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtNamaLengkapPasien.Location = New System.Drawing.Point(0, 0)
        Me.txtNamaLengkapPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtNamaLengkapPasien.Name = "txtNamaLengkapPasien"
        Me.txtNamaLengkapPasien.Size = New System.Drawing.Size(326, 22)
        Me.txtNamaLengkapPasien.TabIndex = 3
        '
        'Panel100
        '
        Me.Panel100.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel100.Location = New System.Drawing.Point(0, 72)
        Me.Panel100.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel100.Name = "Panel100"
        Me.Panel100.Size = New System.Drawing.Size(326, 11)
        Me.Panel100.TabIndex = 2
        '
        'Panel101
        '
        Me.Panel101.Controls.Add(Me.txtUserNamePasien)
        Me.Panel101.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel101.Location = New System.Drawing.Point(0, 47)
        Me.Panel101.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel101.Name = "Panel101"
        Me.Panel101.Size = New System.Drawing.Size(326, 25)
        Me.Panel101.TabIndex = 1
        '
        'txtUserNamePasien
        '
        Me.txtUserNamePasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtUserNamePasien.Location = New System.Drawing.Point(0, 0)
        Me.txtUserNamePasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtUserNamePasien.Name = "txtUserNamePasien"
        Me.txtUserNamePasien.Size = New System.Drawing.Size(326, 22)
        Me.txtUserNamePasien.TabIndex = 2
        '
        'Panel88
        '
        Me.Panel88.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel88.Location = New System.Drawing.Point(0, 36)
        Me.Panel88.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel88.Name = "Panel88"
        Me.Panel88.Size = New System.Drawing.Size(326, 11)
        Me.Panel88.TabIndex = 14
        '
        'Panel89
        '
        Me.Panel89.Controls.Add(Me.txtNIKPasien)
        Me.Panel89.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel89.Location = New System.Drawing.Point(0, 11)
        Me.Panel89.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel89.Name = "Panel89"
        Me.Panel89.Size = New System.Drawing.Size(326, 25)
        Me.Panel89.TabIndex = 12
        '
        'txtNIKPasien
        '
        Me.txtNIKPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtNIKPasien.Location = New System.Drawing.Point(0, 0)
        Me.txtNIKPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtNIKPasien.Name = "txtNIKPasien"
        Me.txtNIKPasien.Size = New System.Drawing.Size(326, 22)
        Me.txtNIKPasien.TabIndex = 2
        '
        'Panel102
        '
        Me.Panel102.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel102.Location = New System.Drawing.Point(0, 0)
        Me.Panel102.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel102.Name = "Panel102"
        Me.Panel102.Size = New System.Drawing.Size(326, 11)
        Me.Panel102.TabIndex = 0
        '
        'Panel103
        '
        Me.Panel103.Controls.Add(Me.Panel104)
        Me.Panel103.Controls.Add(Me.Panel105)
        Me.Panel103.Controls.Add(Me.Panel110)
        Me.Panel103.Controls.Add(Me.Panel111)
        Me.Panel103.Controls.Add(Me.Panel116)
        Me.Panel103.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel103.Location = New System.Drawing.Point(504, 0)
        Me.Panel103.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel103.Name = "Panel103"
        Me.Panel103.Size = New System.Drawing.Size(155, 263)
        Me.Panel103.TabIndex = 0
        '
        'Panel104
        '
        Me.Panel104.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel104.Location = New System.Drawing.Point(0, 220)
        Me.Panel104.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel104.Name = "Panel104"
        Me.Panel104.Size = New System.Drawing.Size(155, 43)
        Me.Panel104.TabIndex = 4
        '
        'Panel105
        '
        Me.Panel105.Controls.Add(Me.Panel106)
        Me.Panel105.Controls.Add(Me.Panel107)
        Me.Panel105.Controls.Add(Me.Panel108)
        Me.Panel105.Controls.Add(Me.Panel109)
        Me.Panel105.Controls.Add(Me.btnBatalPasien)
        Me.Panel105.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel105.Location = New System.Drawing.Point(0, 165)
        Me.Panel105.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel105.Name = "Panel105"
        Me.Panel105.Size = New System.Drawing.Size(155, 55)
        Me.Panel105.TabIndex = 3
        '
        'Panel106
        '
        Me.Panel106.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel106.Location = New System.Drawing.Point(16, 0)
        Me.Panel106.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel106.Name = "Panel106"
        Me.Panel106.Size = New System.Drawing.Size(123, 10)
        Me.Panel106.TabIndex = 9
        '
        'Panel107
        '
        Me.Panel107.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel107.Location = New System.Drawing.Point(16, 45)
        Me.Panel107.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel107.Name = "Panel107"
        Me.Panel107.Size = New System.Drawing.Size(123, 10)
        Me.Panel107.TabIndex = 8
        '
        'Panel108
        '
        Me.Panel108.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel108.Location = New System.Drawing.Point(139, 0)
        Me.Panel108.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel108.Name = "Panel108"
        Me.Panel108.Size = New System.Drawing.Size(16, 55)
        Me.Panel108.TabIndex = 7
        '
        'Panel109
        '
        Me.Panel109.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel109.Location = New System.Drawing.Point(0, 0)
        Me.Panel109.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel109.Name = "Panel109"
        Me.Panel109.Size = New System.Drawing.Size(16, 55)
        Me.Panel109.TabIndex = 6
        '
        'btnBatalPasien
        '
        Me.btnBatalPasien.BackColor = System.Drawing.Color.LightGray
        Me.btnBatalPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnBatalPasien.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnBatalPasien.FlatAppearance.BorderSize = 4
        Me.btnBatalPasien.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBatalPasien.Location = New System.Drawing.Point(0, 0)
        Me.btnBatalPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBatalPasien.Name = "btnBatalPasien"
        Me.btnBatalPasien.Size = New System.Drawing.Size(155, 55)
        Me.btnBatalPasien.TabIndex = 5
        Me.btnBatalPasien.Text = "Batal"
        Me.btnBatalPasien.UseVisualStyleBackColor = False
        '
        'Panel110
        '
        Me.Panel110.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel110.Location = New System.Drawing.Point(0, 110)
        Me.Panel110.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel110.Name = "Panel110"
        Me.Panel110.Size = New System.Drawing.Size(155, 55)
        Me.Panel110.TabIndex = 2
        '
        'Panel111
        '
        Me.Panel111.Controls.Add(Me.Panel112)
        Me.Panel111.Controls.Add(Me.Panel113)
        Me.Panel111.Controls.Add(Me.Panel114)
        Me.Panel111.Controls.Add(Me.Panel115)
        Me.Panel111.Controls.Add(Me.btnSimpanPasien)
        Me.Panel111.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel111.Location = New System.Drawing.Point(0, 55)
        Me.Panel111.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel111.Name = "Panel111"
        Me.Panel111.Size = New System.Drawing.Size(155, 55)
        Me.Panel111.TabIndex = 1
        '
        'Panel112
        '
        Me.Panel112.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel112.Location = New System.Drawing.Point(16, 0)
        Me.Panel112.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel112.Name = "Panel112"
        Me.Panel112.Size = New System.Drawing.Size(123, 10)
        Me.Panel112.TabIndex = 4
        '
        'Panel113
        '
        Me.Panel113.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel113.Location = New System.Drawing.Point(16, 45)
        Me.Panel113.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel113.Name = "Panel113"
        Me.Panel113.Size = New System.Drawing.Size(123, 10)
        Me.Panel113.TabIndex = 3
        '
        'Panel114
        '
        Me.Panel114.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel114.Location = New System.Drawing.Point(139, 0)
        Me.Panel114.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel114.Name = "Panel114"
        Me.Panel114.Size = New System.Drawing.Size(16, 55)
        Me.Panel114.TabIndex = 2
        '
        'Panel115
        '
        Me.Panel115.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel115.Location = New System.Drawing.Point(0, 0)
        Me.Panel115.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel115.Name = "Panel115"
        Me.Panel115.Size = New System.Drawing.Size(16, 55)
        Me.Panel115.TabIndex = 1
        '
        'btnSimpanPasien
        '
        Me.btnSimpanPasien.BackColor = System.Drawing.Color.LightGray
        Me.btnSimpanPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnSimpanPasien.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnSimpanPasien.FlatAppearance.BorderSize = 4
        Me.btnSimpanPasien.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSimpanPasien.Location = New System.Drawing.Point(0, 0)
        Me.btnSimpanPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSimpanPasien.Name = "btnSimpanPasien"
        Me.btnSimpanPasien.Size = New System.Drawing.Size(155, 55)
        Me.btnSimpanPasien.TabIndex = 0
        Me.btnSimpanPasien.Text = "Simpan"
        Me.btnSimpanPasien.UseVisualStyleBackColor = False
        '
        'Panel116
        '
        Me.Panel116.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel116.Location = New System.Drawing.Point(0, 0)
        Me.Panel116.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel116.Name = "Panel116"
        Me.Panel116.Size = New System.Drawing.Size(155, 55)
        Me.Panel116.TabIndex = 0
        '
        'Panel117
        '
        Me.Panel117.Controls.Add(Me.Panel122)
        Me.Panel117.Controls.Add(Me.Panel123)
        Me.Panel117.Controls.Add(Me.Panel124)
        Me.Panel117.Controls.Add(Me.Panel125)
        Me.Panel117.Controls.Add(Me.Panel126)
        Me.Panel117.Controls.Add(Me.Panel127)
        Me.Panel117.Controls.Add(Me.Panel128)
        Me.Panel117.Controls.Add(Me.Panel129)
        Me.Panel117.Controls.Add(Me.Panel130)
        Me.Panel117.Controls.Add(Me.Panel131)
        Me.Panel117.Controls.Add(Me.Panel132)
        Me.Panel117.Controls.Add(Me.Panel133)
        Me.Panel117.Controls.Add(Me.Panel120)
        Me.Panel117.Controls.Add(Me.Panel121)
        Me.Panel117.Controls.Add(Me.Panel134)
        Me.Panel117.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel117.Location = New System.Drawing.Point(25, 0)
        Me.Panel117.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel117.Name = "Panel117"
        Me.Panel117.Size = New System.Drawing.Size(153, 263)
        Me.Panel117.TabIndex = 0
        '
        'Panel122
        '
        Me.Panel122.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel122.Location = New System.Drawing.Point(0, 252)
        Me.Panel122.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel122.Name = "Panel122"
        Me.Panel122.Size = New System.Drawing.Size(153, 11)
        Me.Panel122.TabIndex = 26
        '
        'Panel123
        '
        Me.Panel123.Controls.Add(Me.Label24)
        Me.Panel123.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel123.Location = New System.Drawing.Point(0, 227)
        Me.Panel123.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel123.Name = "Panel123"
        Me.Panel123.Size = New System.Drawing.Size(153, 25)
        Me.Panel123.TabIndex = 27
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label24.Location = New System.Drawing.Point(0, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(53, 17)
        Me.Label24.TabIndex = 1
        Me.Label24.Text = "Faskes"
        '
        'Panel124
        '
        Me.Panel124.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel124.Location = New System.Drawing.Point(0, 216)
        Me.Panel124.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel124.Name = "Panel124"
        Me.Panel124.Size = New System.Drawing.Size(153, 11)
        Me.Panel124.TabIndex = 25
        '
        'Panel125
        '
        Me.Panel125.Controls.Add(Me.Label25)
        Me.Panel125.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel125.Location = New System.Drawing.Point(0, 191)
        Me.Panel125.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel125.Name = "Panel125"
        Me.Panel125.Size = New System.Drawing.Size(153, 25)
        Me.Panel125.TabIndex = 24
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label25.Location = New System.Drawing.Point(0, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(51, 17)
        Me.Label25.TabIndex = 1
        Me.Label25.Text = "Alamat"
        '
        'Panel126
        '
        Me.Panel126.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel126.Location = New System.Drawing.Point(0, 180)
        Me.Panel126.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel126.Name = "Panel126"
        Me.Panel126.Size = New System.Drawing.Size(153, 11)
        Me.Panel126.TabIndex = 23
        '
        'Panel127
        '
        Me.Panel127.Controls.Add(Me.Label26)
        Me.Panel127.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel127.Location = New System.Drawing.Point(0, 155)
        Me.Panel127.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel127.Name = "Panel127"
        Me.Panel127.Size = New System.Drawing.Size(153, 25)
        Me.Panel127.TabIndex = 22
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label26.Location = New System.Drawing.Point(0, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(95, 17)
        Me.Label26.TabIndex = 1
        Me.Label26.Text = "Jenis Kelamin"
        '
        'Panel128
        '
        Me.Panel128.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel128.Location = New System.Drawing.Point(0, 144)
        Me.Panel128.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel128.Name = "Panel128"
        Me.Panel128.Size = New System.Drawing.Size(153, 11)
        Me.Panel128.TabIndex = 21
        '
        'Panel129
        '
        Me.Panel129.Controls.Add(Me.Label27)
        Me.Panel129.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel129.Location = New System.Drawing.Point(0, 119)
        Me.Panel129.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel129.Name = "Panel129"
        Me.Panel129.Size = New System.Drawing.Size(153, 25)
        Me.Panel129.TabIndex = 20
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label27.Location = New System.Drawing.Point(0, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(42, 17)
        Me.Label27.TabIndex = 1
        Me.Label27.Text = "Umur"
        '
        'Panel130
        '
        Me.Panel130.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel130.Location = New System.Drawing.Point(0, 108)
        Me.Panel130.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel130.Name = "Panel130"
        Me.Panel130.Size = New System.Drawing.Size(153, 11)
        Me.Panel130.TabIndex = 19
        '
        'Panel131
        '
        Me.Panel131.Controls.Add(Me.Label28)
        Me.Panel131.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel131.Location = New System.Drawing.Point(0, 83)
        Me.Panel131.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel131.Name = "Panel131"
        Me.Panel131.Size = New System.Drawing.Size(153, 25)
        Me.Panel131.TabIndex = 18
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label28.Location = New System.Drawing.Point(0, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(104, 17)
        Me.Label28.TabIndex = 2
        Me.Label28.Text = "Nama Lengkap"
        '
        'Panel132
        '
        Me.Panel132.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel132.Location = New System.Drawing.Point(0, 72)
        Me.Panel132.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel132.Name = "Panel132"
        Me.Panel132.Size = New System.Drawing.Size(153, 11)
        Me.Panel132.TabIndex = 17
        '
        'Panel133
        '
        Me.Panel133.Controls.Add(Me.Label29)
        Me.Panel133.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel133.Location = New System.Drawing.Point(0, 47)
        Me.Panel133.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel133.Name = "Panel133"
        Me.Panel133.Size = New System.Drawing.Size(153, 25)
        Me.Panel133.TabIndex = 16
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label29.Location = New System.Drawing.Point(0, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(79, 17)
        Me.Label29.TabIndex = 3
        Me.Label29.Text = "User Name"
        '
        'Panel120
        '
        Me.Panel120.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel120.Location = New System.Drawing.Point(0, 36)
        Me.Panel120.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel120.Name = "Panel120"
        Me.Panel120.Size = New System.Drawing.Size(153, 11)
        Me.Panel120.TabIndex = 30
        '
        'Panel121
        '
        Me.Panel121.Controls.Add(Me.Label23)
        Me.Panel121.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel121.Location = New System.Drawing.Point(0, 11)
        Me.Panel121.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel121.Name = "Panel121"
        Me.Panel121.Size = New System.Drawing.Size(153, 25)
        Me.Panel121.TabIndex = 28
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label23.Location = New System.Drawing.Point(0, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(30, 17)
        Me.Label23.TabIndex = 1
        Me.Label23.Text = "NIK"
        '
        'Panel134
        '
        Me.Panel134.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel134.Location = New System.Drawing.Point(0, 0)
        Me.Panel134.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel134.Name = "Panel134"
        Me.Panel134.Size = New System.Drawing.Size(153, 11)
        Me.Panel134.TabIndex = 15
        '
        'Panel135
        '
        Me.Panel135.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel135.Location = New System.Drawing.Point(0, 0)
        Me.Panel135.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel135.Name = "Panel135"
        Me.Panel135.Size = New System.Drawing.Size(25, 263)
        Me.Panel135.TabIndex = 0
        '
        'Panel136
        '
        Me.Panel136.Controls.Add(Me.Panel137)
        Me.Panel136.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel136.Location = New System.Drawing.Point(0, 128)
        Me.Panel136.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel136.Name = "Panel136"
        Me.Panel136.Size = New System.Drawing.Size(659, 63)
        Me.Panel136.TabIndex = 2
        '
        'Panel137
        '
        Me.Panel137.Controls.Add(Me.btnTambahPasien)
        Me.Panel137.Controls.Add(Me.Panel138)
        Me.Panel137.Controls.Add(Me.btnEditPasien)
        Me.Panel137.Controls.Add(Me.Panel139)
        Me.Panel137.Controls.Add(Me.btnHapusPasien)
        Me.Panel137.Controls.Add(Me.Panel140)
        Me.Panel137.Controls.Add(Me.btnRefreshPasien)
        Me.Panel137.Controls.Add(Me.Panel141)
        Me.Panel137.Controls.Add(Me.Panel142)
        Me.Panel137.Controls.Add(Me.Panel143)
        Me.Panel137.Controls.Add(Me.Panel144)
        Me.Panel137.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel137.Location = New System.Drawing.Point(0, 0)
        Me.Panel137.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel137.Name = "Panel137"
        Me.Panel137.Size = New System.Drawing.Size(659, 63)
        Me.Panel137.TabIndex = 3
        '
        'btnTambahPasien
        '
        Me.btnTambahPasien.AutoSize = True
        Me.btnTambahPasien.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnTambahPasien.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnTambahPasien.FlatAppearance.BorderSize = 2
        Me.btnTambahPasien.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTambahPasien.Location = New System.Drawing.Point(23, 15)
        Me.btnTambahPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnTambahPasien.Name = "btnTambahPasien"
        Me.btnTambahPasien.Size = New System.Drawing.Size(131, 33)
        Me.btnTambahPasien.TabIndex = 10
        Me.btnTambahPasien.Text = "Tambah"
        Me.btnTambahPasien.UseVisualStyleBackColor = True
        '
        'Panel138
        '
        Me.Panel138.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel138.Location = New System.Drawing.Point(154, 15)
        Me.Panel138.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel138.Name = "Panel138"
        Me.Panel138.Size = New System.Drawing.Size(29, 33)
        Me.Panel138.TabIndex = 8
        '
        'btnEditPasien
        '
        Me.btnEditPasien.AutoSize = True
        Me.btnEditPasien.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnEditPasien.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnEditPasien.FlatAppearance.BorderSize = 2
        Me.btnEditPasien.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEditPasien.Location = New System.Drawing.Point(183, 15)
        Me.btnEditPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnEditPasien.Name = "btnEditPasien"
        Me.btnEditPasien.Size = New System.Drawing.Size(131, 33)
        Me.btnEditPasien.TabIndex = 9
        Me.btnEditPasien.Text = "Edit"
        Me.btnEditPasien.UseVisualStyleBackColor = True
        '
        'Panel139
        '
        Me.Panel139.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel139.Location = New System.Drawing.Point(314, 15)
        Me.Panel139.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel139.Name = "Panel139"
        Me.Panel139.Size = New System.Drawing.Size(29, 33)
        Me.Panel139.TabIndex = 7
        '
        'btnHapusPasien
        '
        Me.btnHapusPasien.AutoSize = True
        Me.btnHapusPasien.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnHapusPasien.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnHapusPasien.FlatAppearance.BorderSize = 2
        Me.btnHapusPasien.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHapusPasien.Location = New System.Drawing.Point(343, 15)
        Me.btnHapusPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnHapusPasien.Name = "btnHapusPasien"
        Me.btnHapusPasien.Size = New System.Drawing.Size(131, 33)
        Me.btnHapusPasien.TabIndex = 1
        Me.btnHapusPasien.Text = "Hapus"
        Me.btnHapusPasien.UseVisualStyleBackColor = True
        '
        'Panel140
        '
        Me.Panel140.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel140.Location = New System.Drawing.Point(474, 15)
        Me.Panel140.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel140.Name = "Panel140"
        Me.Panel140.Size = New System.Drawing.Size(29, 33)
        Me.Panel140.TabIndex = 8
        '
        'btnRefreshPasien
        '
        Me.btnRefreshPasien.AutoSize = True
        Me.btnRefreshPasien.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnRefreshPasien.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnRefreshPasien.FlatAppearance.BorderSize = 2
        Me.btnRefreshPasien.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRefreshPasien.Location = New System.Drawing.Point(503, 15)
        Me.btnRefreshPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnRefreshPasien.Name = "btnRefreshPasien"
        Me.btnRefreshPasien.Size = New System.Drawing.Size(131, 33)
        Me.btnRefreshPasien.TabIndex = 4
        Me.btnRefreshPasien.Text = "Refresh"
        Me.btnRefreshPasien.UseVisualStyleBackColor = True
        '
        'Panel141
        '
        Me.Panel141.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel141.Location = New System.Drawing.Point(0, 15)
        Me.Panel141.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel141.Name = "Panel141"
        Me.Panel141.Size = New System.Drawing.Size(25, 33)
        Me.Panel141.TabIndex = 5
        '
        'Panel142
        '
        Me.Panel142.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel142.Location = New System.Drawing.Point(634, 15)
        Me.Panel142.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel142.Name = "Panel142"
        Me.Panel142.Size = New System.Drawing.Size(25, 33)
        Me.Panel142.TabIndex = 6
        '
        'Panel143
        '
        Me.Panel143.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel143.Location = New System.Drawing.Point(0, 0)
        Me.Panel143.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel143.Name = "Panel143"
        Me.Panel143.Size = New System.Drawing.Size(659, 15)
        Me.Panel143.TabIndex = 2
        '
        'Panel144
        '
        Me.Panel144.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel144.Location = New System.Drawing.Point(0, 48)
        Me.Panel144.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel144.Name = "Panel144"
        Me.Panel144.Size = New System.Drawing.Size(659, 15)
        Me.Panel144.TabIndex = 3
        '
        'Panel145
        '
        Me.Panel145.Controls.Add(Me.Panel146)
        Me.Panel145.Controls.Add(Me.Panel150)
        Me.Panel145.Controls.Add(Me.Panel151)
        Me.Panel145.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel145.Location = New System.Drawing.Point(0, 66)
        Me.Panel145.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel145.Name = "Panel145"
        Me.Panel145.Size = New System.Drawing.Size(659, 62)
        Me.Panel145.TabIndex = 0
        '
        'Panel146
        '
        Me.Panel146.Controls.Add(Me.txtCariPasien)
        Me.Panel146.Controls.Add(Me.Panel147)
        Me.Panel146.Controls.Add(Me.btnCariPasien)
        Me.Panel146.Controls.Add(Me.Panel148)
        Me.Panel146.Controls.Add(Me.Panel149)
        Me.Panel146.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel146.Location = New System.Drawing.Point(25, 0)
        Me.Panel146.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel146.Name = "Panel146"
        Me.Panel146.Size = New System.Drawing.Size(609, 62)
        Me.Panel146.TabIndex = 2
        '
        'txtCariPasien
        '
        Me.txtCariPasien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtCariPasien.Location = New System.Drawing.Point(0, 15)
        Me.txtCariPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtCariPasien.Multiline = True
        Me.txtCariPasien.Name = "txtCariPasien"
        Me.txtCariPasien.Size = New System.Drawing.Size(449, 32)
        Me.txtCariPasien.TabIndex = 0
        '
        'Panel147
        '
        Me.Panel147.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel147.Location = New System.Drawing.Point(449, 15)
        Me.Panel147.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel147.Name = "Panel147"
        Me.Panel147.Size = New System.Drawing.Size(29, 32)
        Me.Panel147.TabIndex = 7
        '
        'btnCariPasien
        '
        Me.btnCariPasien.AutoSize = True
        Me.btnCariPasien.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnCariPasien.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnCariPasien.FlatAppearance.BorderSize = 2
        Me.btnCariPasien.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCariPasien.Location = New System.Drawing.Point(478, 15)
        Me.btnCariPasien.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCariPasien.Name = "btnCariPasien"
        Me.btnCariPasien.Size = New System.Drawing.Size(131, 32)
        Me.btnCariPasien.TabIndex = 1
        Me.btnCariPasien.Text = "Cari"
        Me.btnCariPasien.UseVisualStyleBackColor = True
        '
        'Panel148
        '
        Me.Panel148.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel148.Location = New System.Drawing.Point(0, 0)
        Me.Panel148.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel148.Name = "Panel148"
        Me.Panel148.Size = New System.Drawing.Size(609, 15)
        Me.Panel148.TabIndex = 2
        '
        'Panel149
        '
        Me.Panel149.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel149.Location = New System.Drawing.Point(0, 47)
        Me.Panel149.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel149.Name = "Panel149"
        Me.Panel149.Size = New System.Drawing.Size(609, 15)
        Me.Panel149.TabIndex = 3
        '
        'Panel150
        '
        Me.Panel150.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel150.Location = New System.Drawing.Point(634, 0)
        Me.Panel150.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel150.Name = "Panel150"
        Me.Panel150.Size = New System.Drawing.Size(25, 62)
        Me.Panel150.TabIndex = 1
        '
        'Panel151
        '
        Me.Panel151.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel151.Location = New System.Drawing.Point(0, 0)
        Me.Panel151.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel151.Name = "Panel151"
        Me.Panel151.Size = New System.Drawing.Size(25, 62)
        Me.Panel151.TabIndex = 0
        '
        'panelKeteranganDP
        '
        Me.panelKeteranganDP.Controls.Add(Me.textKeterangan)
        Me.panelKeteranganDP.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelKeteranganDP.Location = New System.Drawing.Point(0, 0)
        Me.panelKeteranganDP.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelKeteranganDP.Name = "panelKeteranganDP"
        Me.panelKeteranganDP.Size = New System.Drawing.Size(659, 66)
        Me.panelKeteranganDP.TabIndex = 3
        '
        'VScrollBar1
        '
        Me.VScrollBar1.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar1.Location = New System.Drawing.Point(659, 0)
        Me.VScrollBar1.Name = "VScrollBar1"
        Me.VScrollBar1.Size = New System.Drawing.Size(21, 583)
        Me.VScrollBar1.TabIndex = 4
        '
        'panelTindakanDP
        '
        Me.panelTindakanDP.Controls.Add(Me.Panel164)
        Me.panelTindakanDP.Controls.Add(Me.Panel84)
        Me.panelTindakanDP.Controls.Add(Me.Panel240)
        Me.panelTindakanDP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelTindakanDP.Location = New System.Drawing.Point(0, 0)
        Me.panelTindakanDP.Name = "panelTindakanDP"
        Me.panelTindakanDP.Size = New System.Drawing.Size(680, 583)
        Me.panelTindakanDP.TabIndex = 3
        '
        'Panel164
        '
        Me.Panel164.Controls.Add(Me.TableLayoutPanel2)
        Me.Panel164.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel164.Location = New System.Drawing.Point(0, 346)
        Me.Panel164.Name = "Panel164"
        Me.Panel164.Size = New System.Drawing.Size(680, 41)
        Me.Panel164.TabIndex = 4
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 5
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 125.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 125.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.btn_IP_AjukanDokter, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.btn_IP_Batal, 3, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(680, 41)
        Me.TableLayoutPanel2.TabIndex = 1
        '
        'btn_IP_AjukanDokter
        '
        Me.btn_IP_AjukanDokter.Location = New System.Drawing.Point(215, 3)
        Me.btn_IP_AjukanDokter.Name = "btn_IP_AjukanDokter"
        Me.btn_IP_AjukanDokter.Size = New System.Drawing.Size(119, 35)
        Me.btn_IP_AjukanDokter.TabIndex = 0
        Me.btn_IP_AjukanDokter.Text = "Ajukan Dokter"
        Me.btn_IP_AjukanDokter.UseVisualStyleBackColor = True
        '
        'btn_IP_Batal
        '
        Me.btn_IP_Batal.Location = New System.Drawing.Point(345, 3)
        Me.btn_IP_Batal.Name = "btn_IP_Batal"
        Me.btn_IP_Batal.Size = New System.Drawing.Size(118, 35)
        Me.btn_IP_Batal.TabIndex = 0
        Me.btn_IP_Batal.Text = "Batal"
        Me.btn_IP_Batal.UseVisualStyleBackColor = True
        '
        'Panel84
        '
        Me.Panel84.Controls.Add(Me.Panel167)
        Me.Panel84.Controls.Add(Me.Panel185)
        Me.Panel84.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel84.Location = New System.Drawing.Point(0, 66)
        Me.Panel84.Name = "Panel84"
        Me.Panel84.Size = New System.Drawing.Size(680, 280)
        Me.Panel84.TabIndex = 4
        '
        'Panel167
        '
        Me.Panel167.Controls.Add(Me.Panel170)
        Me.Panel167.Controls.Add(Me.Panel173)
        Me.Panel167.Controls.Add(Me.Panel174)
        Me.Panel167.Controls.Add(Me.Panel175)
        Me.Panel167.Controls.Add(Me.Panel176)
        Me.Panel167.Controls.Add(Me.Panel177)
        Me.Panel167.Controls.Add(Me.Panel178)
        Me.Panel167.Controls.Add(Me.Panel179)
        Me.Panel167.Controls.Add(Me.Panel180)
        Me.Panel167.Controls.Add(Me.Panel181)
        Me.Panel167.Controls.Add(Me.Panel182)
        Me.Panel167.Controls.Add(Me.Panel183)
        Me.Panel167.Controls.Add(Me.Panel86)
        Me.Panel167.Controls.Add(Me.Panel87)
        Me.Panel167.Controls.Add(Me.Panel184)
        Me.Panel167.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel167.Location = New System.Drawing.Point(175, 0)
        Me.Panel167.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel167.Name = "Panel167"
        Me.Panel167.Size = New System.Drawing.Size(505, 280)
        Me.Panel167.TabIndex = 1
        '
        'Panel170
        '
        Me.Panel170.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel170.Location = New System.Drawing.Point(0, 252)
        Me.Panel170.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel170.Name = "Panel170"
        Me.Panel170.Size = New System.Drawing.Size(505, 11)
        Me.Panel170.TabIndex = 30
        '
        'Panel173
        '
        Me.Panel173.Controls.Add(Me.txt_IP_Faskes)
        Me.Panel173.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel173.Location = New System.Drawing.Point(0, 227)
        Me.Panel173.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel173.Name = "Panel173"
        Me.Panel173.Size = New System.Drawing.Size(505, 25)
        Me.Panel173.TabIndex = 27
        '
        'txt_IP_Faskes
        '
        Me.txt_IP_Faskes.AutoSize = True
        Me.txt_IP_Faskes.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_Faskes.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_Faskes.Name = "txt_IP_Faskes"
        Me.txt_IP_Faskes.Size = New System.Drawing.Size(53, 17)
        Me.txt_IP_Faskes.TabIndex = 1
        Me.txt_IP_Faskes.Text = "Faskes"
        '
        'Panel174
        '
        Me.Panel174.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel174.Location = New System.Drawing.Point(0, 216)
        Me.Panel174.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel174.Name = "Panel174"
        Me.Panel174.Size = New System.Drawing.Size(505, 11)
        Me.Panel174.TabIndex = 25
        '
        'Panel175
        '
        Me.Panel175.Controls.Add(Me.txt_IP_Alamat)
        Me.Panel175.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel175.Location = New System.Drawing.Point(0, 191)
        Me.Panel175.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel175.Name = "Panel175"
        Me.Panel175.Size = New System.Drawing.Size(505, 25)
        Me.Panel175.TabIndex = 24
        '
        'txt_IP_Alamat
        '
        Me.txt_IP_Alamat.AutoSize = True
        Me.txt_IP_Alamat.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_Alamat.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_Alamat.Name = "txt_IP_Alamat"
        Me.txt_IP_Alamat.Size = New System.Drawing.Size(51, 17)
        Me.txt_IP_Alamat.TabIndex = 1
        Me.txt_IP_Alamat.Text = "Alamat"
        '
        'Panel176
        '
        Me.Panel176.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel176.Location = New System.Drawing.Point(0, 180)
        Me.Panel176.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel176.Name = "Panel176"
        Me.Panel176.Size = New System.Drawing.Size(505, 11)
        Me.Panel176.TabIndex = 23
        '
        'Panel177
        '
        Me.Panel177.Controls.Add(Me.txt_IP_JenisKelamin)
        Me.Panel177.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel177.Location = New System.Drawing.Point(0, 155)
        Me.Panel177.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel177.Name = "Panel177"
        Me.Panel177.Size = New System.Drawing.Size(505, 25)
        Me.Panel177.TabIndex = 22
        '
        'txt_IP_JenisKelamin
        '
        Me.txt_IP_JenisKelamin.AutoSize = True
        Me.txt_IP_JenisKelamin.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_JenisKelamin.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_JenisKelamin.Name = "txt_IP_JenisKelamin"
        Me.txt_IP_JenisKelamin.Size = New System.Drawing.Size(95, 17)
        Me.txt_IP_JenisKelamin.TabIndex = 1
        Me.txt_IP_JenisKelamin.Text = "Jenis Kelamin"
        '
        'Panel178
        '
        Me.Panel178.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel178.Location = New System.Drawing.Point(0, 144)
        Me.Panel178.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel178.Name = "Panel178"
        Me.Panel178.Size = New System.Drawing.Size(505, 11)
        Me.Panel178.TabIndex = 21
        '
        'Panel179
        '
        Me.Panel179.Controls.Add(Me.txt_IP_Umur)
        Me.Panel179.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel179.Location = New System.Drawing.Point(0, 119)
        Me.Panel179.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel179.Name = "Panel179"
        Me.Panel179.Size = New System.Drawing.Size(505, 25)
        Me.Panel179.TabIndex = 20
        '
        'txt_IP_Umur
        '
        Me.txt_IP_Umur.AutoSize = True
        Me.txt_IP_Umur.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_Umur.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_Umur.Name = "txt_IP_Umur"
        Me.txt_IP_Umur.Size = New System.Drawing.Size(42, 17)
        Me.txt_IP_Umur.TabIndex = 1
        Me.txt_IP_Umur.Text = "Umur"
        '
        'Panel180
        '
        Me.Panel180.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel180.Location = New System.Drawing.Point(0, 108)
        Me.Panel180.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel180.Name = "Panel180"
        Me.Panel180.Size = New System.Drawing.Size(505, 11)
        Me.Panel180.TabIndex = 19
        '
        'Panel181
        '
        Me.Panel181.Controls.Add(Me.txt_IP_NamaLengkap)
        Me.Panel181.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel181.Location = New System.Drawing.Point(0, 83)
        Me.Panel181.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel181.Name = "Panel181"
        Me.Panel181.Size = New System.Drawing.Size(505, 25)
        Me.Panel181.TabIndex = 18
        '
        'txt_IP_NamaLengkap
        '
        Me.txt_IP_NamaLengkap.AutoSize = True
        Me.txt_IP_NamaLengkap.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_NamaLengkap.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_NamaLengkap.Name = "txt_IP_NamaLengkap"
        Me.txt_IP_NamaLengkap.Size = New System.Drawing.Size(104, 17)
        Me.txt_IP_NamaLengkap.TabIndex = 2
        Me.txt_IP_NamaLengkap.Text = "Nama Lengkap"
        '
        'Panel182
        '
        Me.Panel182.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel182.Location = New System.Drawing.Point(0, 72)
        Me.Panel182.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel182.Name = "Panel182"
        Me.Panel182.Size = New System.Drawing.Size(505, 11)
        Me.Panel182.TabIndex = 17
        '
        'Panel183
        '
        Me.Panel183.Controls.Add(Me.txt_IP_UserName)
        Me.Panel183.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel183.Location = New System.Drawing.Point(0, 47)
        Me.Panel183.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel183.Name = "Panel183"
        Me.Panel183.Size = New System.Drawing.Size(505, 25)
        Me.Panel183.TabIndex = 16
        '
        'txt_IP_UserName
        '
        Me.txt_IP_UserName.AutoSize = True
        Me.txt_IP_UserName.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_UserName.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_UserName.Name = "txt_IP_UserName"
        Me.txt_IP_UserName.Size = New System.Drawing.Size(79, 17)
        Me.txt_IP_UserName.TabIndex = 3
        Me.txt_IP_UserName.Text = "User Name"
        '
        'Panel86
        '
        Me.Panel86.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel86.Location = New System.Drawing.Point(0, 36)
        Me.Panel86.Name = "Panel86"
        Me.Panel86.Size = New System.Drawing.Size(505, 11)
        Me.Panel86.TabIndex = 31
        '
        'Panel87
        '
        Me.Panel87.Controls.Add(Me.txt_IP_NIK)
        Me.Panel87.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel87.Location = New System.Drawing.Point(0, 11)
        Me.Panel87.Name = "Panel87"
        Me.Panel87.Size = New System.Drawing.Size(505, 25)
        Me.Panel87.TabIndex = 31
        '
        'txt_IP_NIK
        '
        Me.txt_IP_NIK.AutoSize = True
        Me.txt_IP_NIK.Dock = System.Windows.Forms.DockStyle.Left
        Me.txt_IP_NIK.Location = New System.Drawing.Point(0, 0)
        Me.txt_IP_NIK.Name = "txt_IP_NIK"
        Me.txt_IP_NIK.Size = New System.Drawing.Size(30, 17)
        Me.txt_IP_NIK.TabIndex = 0
        Me.txt_IP_NIK.Text = "NIK"
        '
        'Panel184
        '
        Me.Panel184.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel184.Location = New System.Drawing.Point(0, 0)
        Me.Panel184.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel184.Name = "Panel184"
        Me.Panel184.Size = New System.Drawing.Size(505, 11)
        Me.Panel184.TabIndex = 15
        '
        'Panel185
        '
        Me.Panel185.Controls.Add(Me.Panel188)
        Me.Panel185.Controls.Add(Me.Panel191)
        Me.Panel185.Controls.Add(Me.Panel192)
        Me.Panel185.Controls.Add(Me.Panel193)
        Me.Panel185.Controls.Add(Me.Panel194)
        Me.Panel185.Controls.Add(Me.Panel195)
        Me.Panel185.Controls.Add(Me.Panel196)
        Me.Panel185.Controls.Add(Me.Panel197)
        Me.Panel185.Controls.Add(Me.Panel198)
        Me.Panel185.Controls.Add(Me.Panel199)
        Me.Panel185.Controls.Add(Me.Panel200)
        Me.Panel185.Controls.Add(Me.Panel201)
        Me.Panel185.Controls.Add(Me.Panel119)
        Me.Panel185.Controls.Add(Me.Panel118)
        Me.Panel185.Controls.Add(Me.Panel202)
        Me.Panel185.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel185.Location = New System.Drawing.Point(0, 0)
        Me.Panel185.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel185.Name = "Panel185"
        Me.Panel185.Size = New System.Drawing.Size(175, 280)
        Me.Panel185.TabIndex = 1
        '
        'Panel188
        '
        Me.Panel188.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel188.Location = New System.Drawing.Point(0, 252)
        Me.Panel188.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel188.Name = "Panel188"
        Me.Panel188.Size = New System.Drawing.Size(175, 11)
        Me.Panel188.TabIndex = 30
        '
        'Panel191
        '
        Me.Panel191.Controls.Add(Me.Label47)
        Me.Panel191.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel191.Location = New System.Drawing.Point(0, 227)
        Me.Panel191.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel191.Name = "Panel191"
        Me.Panel191.Size = New System.Drawing.Size(175, 25)
        Me.Panel191.TabIndex = 27
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label47.Location = New System.Drawing.Point(0, 0)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(53, 17)
        Me.Label47.TabIndex = 1
        Me.Label47.Text = "Faskes"
        '
        'Panel192
        '
        Me.Panel192.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel192.Location = New System.Drawing.Point(0, 216)
        Me.Panel192.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel192.Name = "Panel192"
        Me.Panel192.Size = New System.Drawing.Size(175, 11)
        Me.Panel192.TabIndex = 25
        '
        'Panel193
        '
        Me.Panel193.Controls.Add(Me.Label48)
        Me.Panel193.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel193.Location = New System.Drawing.Point(0, 191)
        Me.Panel193.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel193.Name = "Panel193"
        Me.Panel193.Size = New System.Drawing.Size(175, 25)
        Me.Panel193.TabIndex = 24
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label48.Location = New System.Drawing.Point(0, 0)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(51, 17)
        Me.Label48.TabIndex = 1
        Me.Label48.Text = "Alamat"
        '
        'Panel194
        '
        Me.Panel194.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel194.Location = New System.Drawing.Point(0, 180)
        Me.Panel194.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel194.Name = "Panel194"
        Me.Panel194.Size = New System.Drawing.Size(175, 11)
        Me.Panel194.TabIndex = 23
        '
        'Panel195
        '
        Me.Panel195.Controls.Add(Me.Label49)
        Me.Panel195.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel195.Location = New System.Drawing.Point(0, 155)
        Me.Panel195.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel195.Name = "Panel195"
        Me.Panel195.Size = New System.Drawing.Size(175, 25)
        Me.Panel195.TabIndex = 22
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label49.Location = New System.Drawing.Point(0, 0)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(95, 17)
        Me.Label49.TabIndex = 1
        Me.Label49.Text = "Jenis Kelamin"
        '
        'Panel196
        '
        Me.Panel196.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel196.Location = New System.Drawing.Point(0, 144)
        Me.Panel196.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel196.Name = "Panel196"
        Me.Panel196.Size = New System.Drawing.Size(175, 11)
        Me.Panel196.TabIndex = 21
        '
        'Panel197
        '
        Me.Panel197.Controls.Add(Me.Label50)
        Me.Panel197.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel197.Location = New System.Drawing.Point(0, 119)
        Me.Panel197.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel197.Name = "Panel197"
        Me.Panel197.Size = New System.Drawing.Size(175, 25)
        Me.Panel197.TabIndex = 20
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label50.Location = New System.Drawing.Point(0, 0)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(42, 17)
        Me.Label50.TabIndex = 1
        Me.Label50.Text = "Umur"
        '
        'Panel198
        '
        Me.Panel198.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel198.Location = New System.Drawing.Point(0, 108)
        Me.Panel198.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel198.Name = "Panel198"
        Me.Panel198.Size = New System.Drawing.Size(175, 11)
        Me.Panel198.TabIndex = 19
        '
        'Panel199
        '
        Me.Panel199.Controls.Add(Me.Label51)
        Me.Panel199.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel199.Location = New System.Drawing.Point(0, 83)
        Me.Panel199.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel199.Name = "Panel199"
        Me.Panel199.Size = New System.Drawing.Size(175, 25)
        Me.Panel199.TabIndex = 18
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label51.Location = New System.Drawing.Point(0, 0)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(104, 17)
        Me.Label51.TabIndex = 2
        Me.Label51.Text = "Nama Lengkap"
        '
        'Panel200
        '
        Me.Panel200.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel200.Location = New System.Drawing.Point(0, 72)
        Me.Panel200.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel200.Name = "Panel200"
        Me.Panel200.Size = New System.Drawing.Size(175, 11)
        Me.Panel200.TabIndex = 17
        '
        'Panel201
        '
        Me.Panel201.Controls.Add(Me.Label52)
        Me.Panel201.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel201.Location = New System.Drawing.Point(0, 47)
        Me.Panel201.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel201.Name = "Panel201"
        Me.Panel201.Size = New System.Drawing.Size(175, 25)
        Me.Panel201.TabIndex = 16
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label52.Location = New System.Drawing.Point(0, 0)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(79, 17)
        Me.Label52.TabIndex = 3
        Me.Label52.Text = "User Name"
        '
        'Panel119
        '
        Me.Panel119.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel119.Location = New System.Drawing.Point(0, 36)
        Me.Panel119.Name = "Panel119"
        Me.Panel119.Size = New System.Drawing.Size(175, 11)
        Me.Panel119.TabIndex = 32
        '
        'Panel118
        '
        Me.Panel118.Controls.Add(Me.Label22)
        Me.Panel118.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel118.Location = New System.Drawing.Point(0, 11)
        Me.Panel118.Name = "Panel118"
        Me.Panel118.Size = New System.Drawing.Size(175, 25)
        Me.Panel118.TabIndex = 31
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label22.Location = New System.Drawing.Point(0, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(30, 17)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "NIK"
        '
        'Panel202
        '
        Me.Panel202.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel202.Location = New System.Drawing.Point(0, 0)
        Me.Panel202.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel202.Name = "Panel202"
        Me.Panel202.Size = New System.Drawing.Size(175, 11)
        Me.Panel202.TabIndex = 15
        '
        'Panel240
        '
        Me.Panel240.Controls.Add(Me.Panel165)
        Me.Panel240.Controls.Add(Me.btn_IP_Kembali)
        Me.Panel240.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel240.Location = New System.Drawing.Point(0, 0)
        Me.Panel240.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel240.Name = "Panel240"
        Me.Panel240.Size = New System.Drawing.Size(680, 66)
        Me.Panel240.TabIndex = 3
        '
        'Panel165
        '
        Me.Panel165.Controls.Add(Me.Label45)
        Me.Panel165.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel165.Location = New System.Drawing.Point(75, 0)
        Me.Panel165.Name = "Panel165"
        Me.Panel165.Size = New System.Drawing.Size(605, 66)
        Me.Panel165.TabIndex = 3
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label45.Location = New System.Drawing.Point(16, 18)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(150, 29)
        Me.Label45.TabIndex = 2
        Me.Label45.Text = "Info Pasien"
        '
        'btn_IP_Kembali
        '
        Me.btn_IP_Kembali.BackgroundImage = CType(resources.GetObject("btn_IP_Kembali.BackgroundImage"), System.Drawing.Image)
        Me.btn_IP_Kembali.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btn_IP_Kembali.Dock = System.Windows.Forms.DockStyle.Left
        Me.btn_IP_Kembali.Location = New System.Drawing.Point(0, 0)
        Me.btn_IP_Kembali.Name = "btn_IP_Kembali"
        Me.btn_IP_Kembali.Size = New System.Drawing.Size(75, 66)
        Me.btn_IP_Kembali.TabIndex = 4
        Me.btn_IP_Kembali.UseVisualStyleBackColor = True
        '
        'panelTransaksi
        '
        Me.panelTransaksi.Controls.Add(Me.panelDatabaseTransaksi)
        Me.panelTransaksi.Controls.Add(Me.panelKeteranganTransaksi)
        Me.panelTransaksi.Controls.Add(Me.VScrollBar2)
        Me.panelTransaksi.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelTransaksi.Location = New System.Drawing.Point(0, 0)
        Me.panelTransaksi.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelTransaksi.Name = "panelTransaksi"
        Me.panelTransaksi.Size = New System.Drawing.Size(680, 583)
        Me.panelTransaksi.TabIndex = 6
        '
        'panelDatabaseTransaksi
        '
        Me.panelDatabaseTransaksi.Controls.Add(Me.DataGridView1)
        Me.panelDatabaseTransaksi.Controls.Add(Me.Panel4)
        Me.panelDatabaseTransaksi.Controls.Add(Me.Panel157)
        Me.panelDatabaseTransaksi.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDatabaseTransaksi.Location = New System.Drawing.Point(0, 66)
        Me.panelDatabaseTransaksi.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDatabaseTransaksi.Name = "panelDatabaseTransaksi"
        Me.panelDatabaseTransaksi.Size = New System.Drawing.Size(659, 517)
        Me.panelDatabaseTransaksi.TabIndex = 5
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.Location = New System.Drawing.Point(0, 124)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(659, 393)
        Me.DataGridView1.TabIndex = 1
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Panel5)
        Me.Panel4.Controls.Add(Me.Panel8)
        Me.Panel4.Controls.Add(Me.Panel9)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 62)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(659, 62)
        Me.Panel4.TabIndex = 0
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.btnBelumBayar)
        Me.Panel5.Controls.Add(Me.btnSemuaTransaksi)
        Me.Panel5.Controls.Add(Me.Panel6)
        Me.Panel5.Controls.Add(Me.Panel7)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel5.Location = New System.Drawing.Point(200, 0)
        Me.Panel5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(259, 62)
        Me.Panel5.TabIndex = 2
        '
        'btnBelumBayar
        '
        Me.btnBelumBayar.AutoSize = True
        Me.btnBelumBayar.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnBelumBayar.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnBelumBayar.FlatAppearance.BorderSize = 2
        Me.btnBelumBayar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBelumBayar.Location = New System.Drawing.Point(0, 15)
        Me.btnBelumBayar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBelumBayar.Name = "btnBelumBayar"
        Me.btnBelumBayar.Size = New System.Drawing.Size(131, 32)
        Me.btnBelumBayar.TabIndex = 1
        Me.btnBelumBayar.Text = "Belum Membayar"
        Me.btnBelumBayar.UseVisualStyleBackColor = True
        '
        'btnSemuaTransaksi
        '
        Me.btnSemuaTransaksi.AutoSize = True
        Me.btnSemuaTransaksi.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnSemuaTransaksi.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnSemuaTransaksi.FlatAppearance.BorderSize = 2
        Me.btnSemuaTransaksi.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSemuaTransaksi.Location = New System.Drawing.Point(128, 15)
        Me.btnSemuaTransaksi.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSemuaTransaksi.Name = "btnSemuaTransaksi"
        Me.btnSemuaTransaksi.Size = New System.Drawing.Size(131, 32)
        Me.btnSemuaTransaksi.TabIndex = 4
        Me.btnSemuaTransaksi.Text = "Semua"
        Me.btnSemuaTransaksi.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel6.Location = New System.Drawing.Point(0, 0)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(259, 15)
        Me.Panel6.TabIndex = 2
        '
        'Panel7
        '
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel7.Location = New System.Drawing.Point(0, 47)
        Me.Panel7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(259, 15)
        Me.Panel7.TabIndex = 3
        '
        'Panel8
        '
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel8.Location = New System.Drawing.Point(459, 0)
        Me.Panel8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(200, 62)
        Me.Panel8.TabIndex = 1
        '
        'Panel9
        '
        Me.Panel9.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel9.Location = New System.Drawing.Point(0, 0)
        Me.Panel9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(200, 62)
        Me.Panel9.TabIndex = 0
        '
        'Panel157
        '
        Me.Panel157.Controls.Add(Me.Panel158)
        Me.Panel157.Controls.Add(Me.Panel162)
        Me.Panel157.Controls.Add(Me.Panel163)
        Me.Panel157.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel157.Location = New System.Drawing.Point(0, 0)
        Me.Panel157.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel157.Name = "Panel157"
        Me.Panel157.Size = New System.Drawing.Size(659, 62)
        Me.Panel157.TabIndex = 2
        '
        'Panel158
        '
        Me.Panel158.Controls.Add(Me.TextBox8)
        Me.Panel158.Controls.Add(Me.Panel159)
        Me.Panel158.Controls.Add(Me.Button8)
        Me.Panel158.Controls.Add(Me.Panel160)
        Me.Panel158.Controls.Add(Me.Panel161)
        Me.Panel158.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel158.Location = New System.Drawing.Point(25, 0)
        Me.Panel158.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel158.Name = "Panel158"
        Me.Panel158.Size = New System.Drawing.Size(609, 62)
        Me.Panel158.TabIndex = 2
        '
        'TextBox8
        '
        Me.TextBox8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox8.Location = New System.Drawing.Point(0, 15)
        Me.TextBox8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox8.Multiline = True
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(449, 32)
        Me.TextBox8.TabIndex = 0
        '
        'Panel159
        '
        Me.Panel159.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel159.Location = New System.Drawing.Point(449, 15)
        Me.Panel159.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel159.Name = "Panel159"
        Me.Panel159.Size = New System.Drawing.Size(29, 32)
        Me.Panel159.TabIndex = 7
        '
        'Button8
        '
        Me.Button8.AutoSize = True
        Me.Button8.Dock = System.Windows.Forms.DockStyle.Right
        Me.Button8.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.Button8.FlatAppearance.BorderSize = 2
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Location = New System.Drawing.Point(478, 15)
        Me.Button8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(131, 32)
        Me.Button8.TabIndex = 1
        Me.Button8.Text = "Cari"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Panel160
        '
        Me.Panel160.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel160.Location = New System.Drawing.Point(0, 0)
        Me.Panel160.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel160.Name = "Panel160"
        Me.Panel160.Size = New System.Drawing.Size(609, 15)
        Me.Panel160.TabIndex = 2
        '
        'Panel161
        '
        Me.Panel161.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel161.Location = New System.Drawing.Point(0, 47)
        Me.Panel161.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel161.Name = "Panel161"
        Me.Panel161.Size = New System.Drawing.Size(609, 15)
        Me.Panel161.TabIndex = 3
        '
        'Panel162
        '
        Me.Panel162.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel162.Location = New System.Drawing.Point(634, 0)
        Me.Panel162.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel162.Name = "Panel162"
        Me.Panel162.Size = New System.Drawing.Size(25, 62)
        Me.Panel162.TabIndex = 1
        '
        'Panel163
        '
        Me.Panel163.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel163.Location = New System.Drawing.Point(0, 0)
        Me.Panel163.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel163.Name = "Panel163"
        Me.Panel163.Size = New System.Drawing.Size(25, 62)
        Me.Panel163.TabIndex = 0
        '
        'panelKeteranganTransaksi
        '
        Me.panelKeteranganTransaksi.Controls.Add(Me.Label4)
        Me.panelKeteranganTransaksi.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelKeteranganTransaksi.Location = New System.Drawing.Point(0, 0)
        Me.panelKeteranganTransaksi.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelKeteranganTransaksi.Name = "panelKeteranganTransaksi"
        Me.panelKeteranganTransaksi.Size = New System.Drawing.Size(659, 66)
        Me.panelKeteranganTransaksi.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label4.Location = New System.Drawing.Point(16, 18)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(132, 29)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Transaksi"
        '
        'VScrollBar2
        '
        Me.VScrollBar2.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar2.Location = New System.Drawing.Point(659, 0)
        Me.VScrollBar2.Name = "VScrollBar2"
        Me.VScrollBar2.Size = New System.Drawing.Size(21, 583)
        Me.VScrollBar2.TabIndex = 4
        '
        'panelDashboard
        '
        Me.panelDashboard.Controls.Add(Me.Panel3)
        Me.panelDashboard.Controls.Add(Me.Panel16)
        Me.panelDashboard.Controls.Add(Me.VScrollBar3)
        Me.panelDashboard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDashboard.Location = New System.Drawing.Point(0, 0)
        Me.panelDashboard.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDashboard.Name = "panelDashboard"
        Me.panelDashboard.Size = New System.Drawing.Size(680, 583)
        Me.panelDashboard.TabIndex = 7
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Panel35)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(0, 66)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(659, 517)
        Me.Panel3.TabIndex = 5
        '
        'Panel35
        '
        Me.Panel35.Controls.Add(Me.Panel156)
        Me.Panel35.Controls.Add(Me.Panel155)
        Me.Panel35.Controls.Add(Me.Panel154)
        Me.Panel35.Controls.Add(Me.Panel153)
        Me.Panel35.Controls.Add(Me.Panel152)
        Me.Panel35.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel35.Location = New System.Drawing.Point(0, 0)
        Me.Panel35.Name = "Panel35"
        Me.Panel35.Size = New System.Drawing.Size(659, 105)
        Me.Panel35.TabIndex = 1
        '
        'Panel156
        '
        Me.Panel156.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel156.Controls.Add(Me.Label33)
        Me.Panel156.Controls.Add(Me.Label32)
        Me.Panel156.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel156.Location = New System.Drawing.Point(365, 0)
        Me.Panel156.Name = "Panel156"
        Me.Panel156.Size = New System.Drawing.Size(180, 105)
        Me.Panel156.TabIndex = 3
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(28, 62)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(127, 29)
        Me.Label33.TabIndex = 0
        Me.Label33.Text = "Kunjungan"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(75, 7)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(42, 46)
        Me.Label32.TabIndex = 0
        Me.Label32.Text = "0"
        '
        'Panel155
        '
        Me.Panel155.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel155.Location = New System.Drawing.Point(295, 0)
        Me.Panel155.Name = "Panel155"
        Me.Panel155.Size = New System.Drawing.Size(70, 105)
        Me.Panel155.TabIndex = 2
        '
        'Panel154
        '
        Me.Panel154.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel154.Controls.Add(Me.Label31)
        Me.Panel154.Controls.Add(Me.Label30)
        Me.Panel154.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel154.Location = New System.Drawing.Point(115, 0)
        Me.Panel154.Name = "Panel154"
        Me.Panel154.Size = New System.Drawing.Size(180, 105)
        Me.Panel154.TabIndex = 2
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(43, 64)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(87, 29)
        Me.Label31.TabIndex = 0
        Me.Label31.Text = "Pasien"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(66, 9)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(42, 46)
        Me.Label30.TabIndex = 0
        Me.Label30.Text = "0"
        '
        'Panel153
        '
        Me.Panel153.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel153.Location = New System.Drawing.Point(544, 0)
        Me.Panel153.Name = "Panel153"
        Me.Panel153.Size = New System.Drawing.Size(115, 105)
        Me.Panel153.TabIndex = 1
        '
        'Panel152
        '
        Me.Panel152.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel152.Location = New System.Drawing.Point(0, 0)
        Me.Panel152.Name = "Panel152"
        Me.Panel152.Size = New System.Drawing.Size(115, 105)
        Me.Panel152.TabIndex = 0
        '
        'Panel16
        '
        Me.Panel16.Controls.Add(Me.Label9)
        Me.Panel16.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel16.Location = New System.Drawing.Point(0, 0)
        Me.Panel16.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(659, 66)
        Me.Panel16.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label9.Location = New System.Drawing.Point(16, 18)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(145, 29)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Dashboard"
        '
        'VScrollBar3
        '
        Me.VScrollBar3.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar3.Location = New System.Drawing.Point(659, 0)
        Me.VScrollBar3.Name = "VScrollBar3"
        Me.VScrollBar3.Size = New System.Drawing.Size(21, 583)
        Me.VScrollBar3.TabIndex = 4
        '
        'panelLaporan
        '
        Me.panelLaporan.Controls.Add(Me.Panel10)
        Me.panelLaporan.Controls.Add(Me.Panel11)
        Me.panelLaporan.Controls.Add(Me.VScrollBar4)
        Me.panelLaporan.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelLaporan.Location = New System.Drawing.Point(0, 0)
        Me.panelLaporan.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelLaporan.Name = "panelLaporan"
        Me.panelLaporan.Size = New System.Drawing.Size(680, 583)
        Me.panelLaporan.TabIndex = 8
        '
        'Panel10
        '
        Me.Panel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel10.Location = New System.Drawing.Point(0, 66)
        Me.Panel10.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(659, 517)
        Me.Panel10.TabIndex = 5
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.Label10)
        Me.Panel11.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel11.Location = New System.Drawing.Point(0, 0)
        Me.Panel11.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(659, 66)
        Me.Panel11.TabIndex = 3
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label10.Location = New System.Drawing.Point(16, 18)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(112, 29)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Laporan"
        '
        'VScrollBar4
        '
        Me.VScrollBar4.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar4.Location = New System.Drawing.Point(659, 0)
        Me.VScrollBar4.Name = "VScrollBar4"
        Me.VScrollBar4.Size = New System.Drawing.Size(21, 583)
        Me.VScrollBar4.TabIndex = 4
        '
        'panelAkun
        '
        Me.panelAkun.Controls.Add(Me.Panel12)
        Me.panelAkun.Controls.Add(Me.Panel13)
        Me.panelAkun.Controls.Add(Me.VScrollBar5)
        Me.panelAkun.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelAkun.Location = New System.Drawing.Point(0, 0)
        Me.panelAkun.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelAkun.Name = "panelAkun"
        Me.panelAkun.Size = New System.Drawing.Size(680, 583)
        Me.panelAkun.TabIndex = 9
        '
        'Panel12
        '
        Me.Panel12.Controls.Add(Me.Label34)
        Me.Panel12.Controls.Add(Me.txtNamaPengguna)
        Me.Panel12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel12.Location = New System.Drawing.Point(0, 66)
        Me.Panel12.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(659, 517)
        Me.Panel12.TabIndex = 5
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(20, 75)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(178, 29)
        Me.Label34.TabIndex = 0
        Me.Label34.Text = "Kota Pengguna"
        '
        'txtNamaPengguna
        '
        Me.txtNamaPengguna.AutoSize = True
        Me.txtNamaPengguna.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNamaPengguna.Location = New System.Drawing.Point(16, 21)
        Me.txtNamaPengguna.Name = "txtNamaPengguna"
        Me.txtNamaPengguna.Size = New System.Drawing.Size(193, 29)
        Me.txtNamaPengguna.TabIndex = 0
        Me.txtNamaPengguna.Text = "Nama Pengguna"
        '
        'Panel13
        '
        Me.Panel13.Controls.Add(Me.Label11)
        Me.Panel13.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel13.Location = New System.Drawing.Point(0, 0)
        Me.Panel13.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(659, 66)
        Me.Panel13.TabIndex = 3
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label11.Location = New System.Drawing.Point(16, 18)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(75, 29)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "Akun"
        '
        'VScrollBar5
        '
        Me.VScrollBar5.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar5.Location = New System.Drawing.Point(659, 0)
        Me.VScrollBar5.Name = "VScrollBar5"
        Me.VScrollBar5.Size = New System.Drawing.Size(21, 583)
        Me.VScrollBar5.TabIndex = 4
        '
        'panelGrup
        '
        Me.panelGrup.Controls.Add(Me.panelDaftarPasien)
        Me.panelGrup.Controls.Add(Me.panelDashboard)
        Me.panelGrup.Controls.Add(Me.panelTransaksi)
        Me.panelGrup.Controls.Add(Me.panelLaporan)
        Me.panelGrup.Controls.Add(Me.panelAkun)
        Me.panelGrup.Controls.Add(Me.panelDaftarUser)
        Me.panelGrup.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelGrup.Location = New System.Drawing.Point(231, 48)
        Me.panelGrup.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelGrup.Name = "panelGrup"
        Me.panelGrup.Size = New System.Drawing.Size(680, 583)
        Me.panelGrup.TabIndex = 0
        '
        'panelDaftarUser
        '
        Me.panelDaftarUser.Controls.Add(Me.Panel14)
        Me.panelDaftarUser.Controls.Add(Me.Panel22)
        Me.panelDaftarUser.Controls.Add(Me.VScrollBar6)
        Me.panelDaftarUser.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDaftarUser.Location = New System.Drawing.Point(0, 0)
        Me.panelDaftarUser.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDaftarUser.Name = "panelDaftarUser"
        Me.panelDaftarUser.Size = New System.Drawing.Size(680, 583)
        Me.panelDaftarUser.TabIndex = 10
        '
        'Panel14
        '
        Me.Panel14.Controls.Add(Me.dgvDaftarUser)
        Me.Panel14.Controls.Add(Me.panelFormulir)
        Me.Panel14.Controls.Add(Me.Panel2)
        Me.Panel14.Controls.Add(Me.Panel15)
        Me.Panel14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel14.Location = New System.Drawing.Point(0, 66)
        Me.Panel14.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(659, 517)
        Me.Panel14.TabIndex = 5
        '
        'dgvDaftarUser
        '
        Me.dgvDaftarUser.AllowUserToAddRows = False
        Me.dgvDaftarUser.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.ActiveCaption
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ActiveCaption
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvDaftarUser.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvDaftarUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDaftarUser.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvDaftarUser.EnableHeadersVisualStyles = False
        Me.dgvDaftarUser.GridColor = System.Drawing.SystemColors.Control
        Me.dgvDaftarUser.Location = New System.Drawing.Point(0, 425)
        Me.dgvDaftarUser.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgvDaftarUser.Name = "dgvDaftarUser"
        Me.dgvDaftarUser.ReadOnly = True
        Me.dgvDaftarUser.RowHeadersWidth = 51
        Me.dgvDaftarUser.RowTemplate.Height = 24
        Me.dgvDaftarUser.Size = New System.Drawing.Size(659, 92)
        Me.dgvDaftarUser.TabIndex = 1
        '
        'panelFormulir
        '
        Me.panelFormulir.Controls.Add(Me.Panel40)
        Me.panelFormulir.Controls.Add(Me.Panel23)
        Me.panelFormulir.Controls.Add(Me.Panel18)
        Me.panelFormulir.Controls.Add(Me.Panel83)
        Me.panelFormulir.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFormulir.Location = New System.Drawing.Point(0, 125)
        Me.panelFormulir.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelFormulir.Name = "panelFormulir"
        Me.panelFormulir.Size = New System.Drawing.Size(659, 300)
        Me.panelFormulir.TabIndex = 3
        '
        'Panel40
        '
        Me.Panel40.Controls.Add(Me.Panel61)
        Me.Panel40.Controls.Add(Me.Panel60)
        Me.Panel40.Controls.Add(Me.Panel59)
        Me.Panel40.Controls.Add(Me.Panel58)
        Me.Panel40.Controls.Add(Me.Panel57)
        Me.Panel40.Controls.Add(Me.Panel56)
        Me.Panel40.Controls.Add(Me.Panel55)
        Me.Panel40.Controls.Add(Me.Panel54)
        Me.Panel40.Controls.Add(Me.Panel53)
        Me.Panel40.Controls.Add(Me.Panel52)
        Me.Panel40.Controls.Add(Me.Panel51)
        Me.Panel40.Controls.Add(Me.Panel50)
        Me.Panel40.Controls.Add(Me.Panel49)
        Me.Panel40.Controls.Add(Me.Panel48)
        Me.Panel40.Controls.Add(Me.Panel47)
        Me.Panel40.Controls.Add(Me.Panel46)
        Me.Panel40.Controls.Add(Me.Panel45)
        Me.Panel40.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel40.Location = New System.Drawing.Point(178, 0)
        Me.Panel40.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel40.Name = "Panel40"
        Me.Panel40.Size = New System.Drawing.Size(326, 300)
        Me.Panel40.TabIndex = 1
        '
        'Panel61
        '
        Me.Panel61.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel61.Location = New System.Drawing.Point(0, 288)
        Me.Panel61.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel61.Name = "Panel61"
        Me.Panel61.Size = New System.Drawing.Size(326, 11)
        Me.Panel61.TabIndex = 12
        '
        'Panel60
        '
        Me.Panel60.Controls.Add(Me.txtKonfirmasiPassword)
        Me.Panel60.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel60.Location = New System.Drawing.Point(0, 263)
        Me.Panel60.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel60.Name = "Panel60"
        Me.Panel60.Size = New System.Drawing.Size(326, 25)
        Me.Panel60.TabIndex = 13
        '
        'txtKonfirmasiPassword
        '
        Me.txtKonfirmasiPassword.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtKonfirmasiPassword.Location = New System.Drawing.Point(0, 0)
        Me.txtKonfirmasiPassword.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtKonfirmasiPassword.Name = "txtKonfirmasiPassword"
        Me.txtKonfirmasiPassword.Size = New System.Drawing.Size(326, 22)
        Me.txtKonfirmasiPassword.TabIndex = 3
        '
        'Panel59
        '
        Me.Panel59.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel59.Location = New System.Drawing.Point(0, 252)
        Me.Panel59.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel59.Name = "Panel59"
        Me.Panel59.Size = New System.Drawing.Size(326, 11)
        Me.Panel59.TabIndex = 14
        '
        'Panel58
        '
        Me.Panel58.Controls.Add(Me.txtPassword)
        Me.Panel58.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel58.Location = New System.Drawing.Point(0, 227)
        Me.Panel58.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel58.Name = "Panel58"
        Me.Panel58.Size = New System.Drawing.Size(326, 25)
        Me.Panel58.TabIndex = 12
        '
        'txtPassword
        '
        Me.txtPassword.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtPassword.Location = New System.Drawing.Point(0, 0)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(326, 22)
        Me.txtPassword.TabIndex = 2
        '
        'Panel57
        '
        Me.Panel57.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel57.Location = New System.Drawing.Point(0, 216)
        Me.Panel57.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel57.Name = "Panel57"
        Me.Panel57.Size = New System.Drawing.Size(326, 11)
        Me.Panel57.TabIndex = 11
        '
        'Panel56
        '
        Me.Panel56.Controls.Add(Me.txtPosition)
        Me.Panel56.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel56.Location = New System.Drawing.Point(0, 191)
        Me.Panel56.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel56.Name = "Panel56"
        Me.Panel56.Size = New System.Drawing.Size(326, 25)
        Me.Panel56.TabIndex = 11
        '
        'txtPosition
        '
        Me.txtPosition.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtPosition.FormattingEnabled = True
        Me.txtPosition.Items.AddRange(New Object() {"Dokter", "Apoteker", "Admin", "Loketor"})
        Me.txtPosition.Location = New System.Drawing.Point(0, 0)
        Me.txtPosition.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtPosition.Name = "txtPosition"
        Me.txtPosition.Size = New System.Drawing.Size(326, 24)
        Me.txtPosition.TabIndex = 4
        '
        'Panel55
        '
        Me.Panel55.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel55.Location = New System.Drawing.Point(0, 180)
        Me.Panel55.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel55.Name = "Panel55"
        Me.Panel55.Size = New System.Drawing.Size(326, 11)
        Me.Panel55.TabIndex = 10
        '
        'Panel54
        '
        Me.Panel54.Controls.Add(Me.txtAddress)
        Me.Panel54.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel54.Location = New System.Drawing.Point(0, 155)
        Me.Panel54.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel54.Name = "Panel54"
        Me.Panel54.Size = New System.Drawing.Size(326, 25)
        Me.Panel54.TabIndex = 9
        '
        'txtAddress
        '
        Me.txtAddress.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtAddress.Location = New System.Drawing.Point(0, 0)
        Me.txtAddress.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(326, 22)
        Me.txtAddress.TabIndex = 2
        '
        'Panel53
        '
        Me.Panel53.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel53.Location = New System.Drawing.Point(0, 144)
        Me.Panel53.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel53.Name = "Panel53"
        Me.Panel53.Size = New System.Drawing.Size(326, 11)
        Me.Panel53.TabIndex = 8
        '
        'Panel52
        '
        Me.Panel52.Controls.Add(Me.txtGender)
        Me.Panel52.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel52.Location = New System.Drawing.Point(0, 119)
        Me.Panel52.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel52.Name = "Panel52"
        Me.Panel52.Size = New System.Drawing.Size(326, 25)
        Me.Panel52.TabIndex = 7
        '
        'txtGender
        '
        Me.txtGender.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtGender.FormattingEnabled = True
        Me.txtGender.Items.AddRange(New Object() {"Laki-Laki", "Perempuan", "Tidak diketahui"})
        Me.txtGender.Location = New System.Drawing.Point(0, 0)
        Me.txtGender.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtGender.Name = "txtGender"
        Me.txtGender.Size = New System.Drawing.Size(326, 24)
        Me.txtGender.TabIndex = 4
        '
        'Panel51
        '
        Me.Panel51.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel51.Location = New System.Drawing.Point(0, 108)
        Me.Panel51.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel51.Name = "Panel51"
        Me.Panel51.Size = New System.Drawing.Size(326, 11)
        Me.Panel51.TabIndex = 6
        '
        'Panel50
        '
        Me.Panel50.Controls.Add(Me.txtAge)
        Me.Panel50.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel50.Location = New System.Drawing.Point(0, 83)
        Me.Panel50.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel50.Name = "Panel50"
        Me.Panel50.Size = New System.Drawing.Size(326, 25)
        Me.Panel50.TabIndex = 5
        '
        'txtAge
        '
        Me.txtAge.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtAge.Location = New System.Drawing.Point(0, 0)
        Me.txtAge.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtAge.Name = "txtAge"
        Me.txtAge.Size = New System.Drawing.Size(326, 22)
        Me.txtAge.TabIndex = 2
        '
        'Panel49
        '
        Me.Panel49.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel49.Location = New System.Drawing.Point(0, 72)
        Me.Panel49.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel49.Name = "Panel49"
        Me.Panel49.Size = New System.Drawing.Size(326, 11)
        Me.Panel49.TabIndex = 4
        '
        'Panel48
        '
        Me.Panel48.Controls.Add(Me.txtNickName)
        Me.Panel48.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel48.Location = New System.Drawing.Point(0, 47)
        Me.Panel48.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel48.Name = "Panel48"
        Me.Panel48.Size = New System.Drawing.Size(326, 25)
        Me.Panel48.TabIndex = 3
        '
        'txtNickName
        '
        Me.txtNickName.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtNickName.Location = New System.Drawing.Point(0, 0)
        Me.txtNickName.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtNickName.Name = "txtNickName"
        Me.txtNickName.Size = New System.Drawing.Size(326, 22)
        Me.txtNickName.TabIndex = 3
        '
        'Panel47
        '
        Me.Panel47.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel47.Location = New System.Drawing.Point(0, 36)
        Me.Panel47.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel47.Name = "Panel47"
        Me.Panel47.Size = New System.Drawing.Size(326, 11)
        Me.Panel47.TabIndex = 2
        '
        'Panel46
        '
        Me.Panel46.Controls.Add(Me.txtUserName)
        Me.Panel46.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel46.Location = New System.Drawing.Point(0, 11)
        Me.Panel46.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel46.Name = "Panel46"
        Me.Panel46.Size = New System.Drawing.Size(326, 25)
        Me.Panel46.TabIndex = 1
        '
        'txtUserName
        '
        Me.txtUserName.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtUserName.Location = New System.Drawing.Point(0, 0)
        Me.txtUserName.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtUserName.Name = "txtUserName"
        Me.txtUserName.Size = New System.Drawing.Size(326, 22)
        Me.txtUserName.TabIndex = 2
        '
        'Panel45
        '
        Me.Panel45.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel45.Location = New System.Drawing.Point(0, 0)
        Me.Panel45.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel45.Name = "Panel45"
        Me.Panel45.Size = New System.Drawing.Size(326, 11)
        Me.Panel45.TabIndex = 0
        '
        'Panel23
        '
        Me.Panel23.Controls.Add(Me.Panel62)
        Me.Panel23.Controls.Add(Me.Panel39)
        Me.Panel23.Controls.Add(Me.Panel38)
        Me.Panel23.Controls.Add(Me.Panel37)
        Me.Panel23.Controls.Add(Me.Panel36)
        Me.Panel23.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel23.Location = New System.Drawing.Point(504, 0)
        Me.Panel23.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(155, 300)
        Me.Panel23.TabIndex = 0
        '
        'Panel62
        '
        Me.Panel62.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel62.Location = New System.Drawing.Point(0, 220)
        Me.Panel62.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel62.Name = "Panel62"
        Me.Panel62.Size = New System.Drawing.Size(155, 55)
        Me.Panel62.TabIndex = 4
        '
        'Panel39
        '
        Me.Panel39.Controls.Add(Me.Panel63)
        Me.Panel39.Controls.Add(Me.Panel64)
        Me.Panel39.Controls.Add(Me.Panel65)
        Me.Panel39.Controls.Add(Me.Panel66)
        Me.Panel39.Controls.Add(Me.btnBatal)
        Me.Panel39.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel39.Location = New System.Drawing.Point(0, 165)
        Me.Panel39.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel39.Name = "Panel39"
        Me.Panel39.Size = New System.Drawing.Size(155, 55)
        Me.Panel39.TabIndex = 3
        '
        'Panel63
        '
        Me.Panel63.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel63.Location = New System.Drawing.Point(16, 0)
        Me.Panel63.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel63.Name = "Panel63"
        Me.Panel63.Size = New System.Drawing.Size(123, 10)
        Me.Panel63.TabIndex = 9
        '
        'Panel64
        '
        Me.Panel64.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel64.Location = New System.Drawing.Point(16, 45)
        Me.Panel64.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel64.Name = "Panel64"
        Me.Panel64.Size = New System.Drawing.Size(123, 10)
        Me.Panel64.TabIndex = 8
        '
        'Panel65
        '
        Me.Panel65.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel65.Location = New System.Drawing.Point(139, 0)
        Me.Panel65.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel65.Name = "Panel65"
        Me.Panel65.Size = New System.Drawing.Size(16, 55)
        Me.Panel65.TabIndex = 7
        '
        'Panel66
        '
        Me.Panel66.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel66.Location = New System.Drawing.Point(0, 0)
        Me.Panel66.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel66.Name = "Panel66"
        Me.Panel66.Size = New System.Drawing.Size(16, 55)
        Me.Panel66.TabIndex = 6
        '
        'btnBatal
        '
        Me.btnBatal.BackColor = System.Drawing.Color.LightGray
        Me.btnBatal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnBatal.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnBatal.FlatAppearance.BorderSize = 4
        Me.btnBatal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBatal.Location = New System.Drawing.Point(0, 0)
        Me.btnBatal.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(155, 55)
        Me.btnBatal.TabIndex = 5
        Me.btnBatal.Text = "Batal"
        Me.btnBatal.UseVisualStyleBackColor = False
        '
        'Panel38
        '
        Me.Panel38.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel38.Location = New System.Drawing.Point(0, 110)
        Me.Panel38.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel38.Name = "Panel38"
        Me.Panel38.Size = New System.Drawing.Size(155, 55)
        Me.Panel38.TabIndex = 2
        '
        'Panel37
        '
        Me.Panel37.Controls.Add(Me.Panel44)
        Me.Panel37.Controls.Add(Me.Panel43)
        Me.Panel37.Controls.Add(Me.Panel42)
        Me.Panel37.Controls.Add(Me.Panel41)
        Me.Panel37.Controls.Add(Me.btnSimpan)
        Me.Panel37.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel37.Location = New System.Drawing.Point(0, 55)
        Me.Panel37.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel37.Name = "Panel37"
        Me.Panel37.Size = New System.Drawing.Size(155, 55)
        Me.Panel37.TabIndex = 1
        '
        'Panel44
        '
        Me.Panel44.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel44.Location = New System.Drawing.Point(16, 0)
        Me.Panel44.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel44.Name = "Panel44"
        Me.Panel44.Size = New System.Drawing.Size(123, 10)
        Me.Panel44.TabIndex = 4
        '
        'Panel43
        '
        Me.Panel43.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel43.Location = New System.Drawing.Point(16, 45)
        Me.Panel43.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel43.Name = "Panel43"
        Me.Panel43.Size = New System.Drawing.Size(123, 10)
        Me.Panel43.TabIndex = 3
        '
        'Panel42
        '
        Me.Panel42.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel42.Location = New System.Drawing.Point(139, 0)
        Me.Panel42.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel42.Name = "Panel42"
        Me.Panel42.Size = New System.Drawing.Size(16, 55)
        Me.Panel42.TabIndex = 2
        '
        'Panel41
        '
        Me.Panel41.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel41.Location = New System.Drawing.Point(0, 0)
        Me.Panel41.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel41.Name = "Panel41"
        Me.Panel41.Size = New System.Drawing.Size(16, 55)
        Me.Panel41.TabIndex = 1
        '
        'btnSimpan
        '
        Me.btnSimpan.BackColor = System.Drawing.Color.LightGray
        Me.btnSimpan.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnSimpan.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnSimpan.FlatAppearance.BorderSize = 4
        Me.btnSimpan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSimpan.Location = New System.Drawing.Point(0, 0)
        Me.btnSimpan.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSimpan.Name = "btnSimpan"
        Me.btnSimpan.Size = New System.Drawing.Size(155, 55)
        Me.btnSimpan.TabIndex = 0
        Me.btnSimpan.Text = "Simpan"
        Me.btnSimpan.UseVisualStyleBackColor = False
        '
        'Panel36
        '
        Me.Panel36.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel36.Location = New System.Drawing.Point(0, 0)
        Me.Panel36.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel36.Name = "Panel36"
        Me.Panel36.Size = New System.Drawing.Size(155, 55)
        Me.Panel36.TabIndex = 0
        '
        'Panel18
        '
        Me.Panel18.Controls.Add(Me.Panel82)
        Me.Panel18.Controls.Add(Me.Panel25)
        Me.Panel18.Controls.Add(Me.Panel67)
        Me.Panel18.Controls.Add(Me.Panel68)
        Me.Panel18.Controls.Add(Me.Panel69)
        Me.Panel18.Controls.Add(Me.Panel70)
        Me.Panel18.Controls.Add(Me.Panel71)
        Me.Panel18.Controls.Add(Me.Panel72)
        Me.Panel18.Controls.Add(Me.Panel73)
        Me.Panel18.Controls.Add(Me.Panel74)
        Me.Panel18.Controls.Add(Me.Panel75)
        Me.Panel18.Controls.Add(Me.Panel76)
        Me.Panel18.Controls.Add(Me.Panel77)
        Me.Panel18.Controls.Add(Me.Panel78)
        Me.Panel18.Controls.Add(Me.Panel79)
        Me.Panel18.Controls.Add(Me.Panel80)
        Me.Panel18.Controls.Add(Me.Panel81)
        Me.Panel18.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel18.Location = New System.Drawing.Point(25, 0)
        Me.Panel18.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(153, 300)
        Me.Panel18.TabIndex = 0
        '
        'Panel82
        '
        Me.Panel82.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel82.Location = New System.Drawing.Point(0, 288)
        Me.Panel82.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel82.Name = "Panel82"
        Me.Panel82.Size = New System.Drawing.Size(153, 11)
        Me.Panel82.TabIndex = 31
        '
        'Panel25
        '
        Me.Panel25.Controls.Add(Me.Label21)
        Me.Panel25.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel25.Location = New System.Drawing.Point(0, 263)
        Me.Panel25.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(153, 25)
        Me.Panel25.TabIndex = 29
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label21.Location = New System.Drawing.Point(0, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(139, 17)
        Me.Label21.TabIndex = 2
        Me.Label21.Text = "Konfirmasi Password"
        '
        'Panel67
        '
        Me.Panel67.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel67.Location = New System.Drawing.Point(0, 252)
        Me.Panel67.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel67.Name = "Panel67"
        Me.Panel67.Size = New System.Drawing.Size(153, 11)
        Me.Panel67.TabIndex = 30
        '
        'Panel68
        '
        Me.Panel68.Controls.Add(Me.Label20)
        Me.Panel68.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel68.Location = New System.Drawing.Point(0, 227)
        Me.Panel68.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel68.Name = "Panel68"
        Me.Panel68.Size = New System.Drawing.Size(153, 25)
        Me.Panel68.TabIndex = 28
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label20.Location = New System.Drawing.Point(0, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(69, 17)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "Password"
        '
        'Panel69
        '
        Me.Panel69.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel69.Location = New System.Drawing.Point(0, 216)
        Me.Panel69.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel69.Name = "Panel69"
        Me.Panel69.Size = New System.Drawing.Size(153, 11)
        Me.Panel69.TabIndex = 26
        '
        'Panel70
        '
        Me.Panel70.Controls.Add(Me.Label19)
        Me.Panel70.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel70.Location = New System.Drawing.Point(0, 191)
        Me.Panel70.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel70.Name = "Panel70"
        Me.Panel70.Size = New System.Drawing.Size(153, 25)
        Me.Panel70.TabIndex = 27
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label19.Location = New System.Drawing.Point(0, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(59, 17)
        Me.Label19.TabIndex = 1
        Me.Label19.Text = "Jabatan"
        '
        'Panel71
        '
        Me.Panel71.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel71.Location = New System.Drawing.Point(0, 180)
        Me.Panel71.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel71.Name = "Panel71"
        Me.Panel71.Size = New System.Drawing.Size(153, 11)
        Me.Panel71.TabIndex = 25
        '
        'Panel72
        '
        Me.Panel72.Controls.Add(Me.Label18)
        Me.Panel72.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel72.Location = New System.Drawing.Point(0, 155)
        Me.Panel72.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel72.Name = "Panel72"
        Me.Panel72.Size = New System.Drawing.Size(153, 25)
        Me.Panel72.TabIndex = 24
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label18.Location = New System.Drawing.Point(0, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(51, 17)
        Me.Label18.TabIndex = 1
        Me.Label18.Text = "Alamat"
        '
        'Panel73
        '
        Me.Panel73.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel73.Location = New System.Drawing.Point(0, 144)
        Me.Panel73.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel73.Name = "Panel73"
        Me.Panel73.Size = New System.Drawing.Size(153, 11)
        Me.Panel73.TabIndex = 23
        '
        'Panel74
        '
        Me.Panel74.Controls.Add(Me.Label15)
        Me.Panel74.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel74.Location = New System.Drawing.Point(0, 119)
        Me.Panel74.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel74.Name = "Panel74"
        Me.Panel74.Size = New System.Drawing.Size(153, 25)
        Me.Panel74.TabIndex = 22
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label15.Location = New System.Drawing.Point(0, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(95, 17)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "Jenis Kelamin"
        '
        'Panel75
        '
        Me.Panel75.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel75.Location = New System.Drawing.Point(0, 108)
        Me.Panel75.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel75.Name = "Panel75"
        Me.Panel75.Size = New System.Drawing.Size(153, 11)
        Me.Panel75.TabIndex = 21
        '
        'Panel76
        '
        Me.Panel76.Controls.Add(Me.Label14)
        Me.Panel76.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel76.Location = New System.Drawing.Point(0, 83)
        Me.Panel76.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel76.Name = "Panel76"
        Me.Panel76.Size = New System.Drawing.Size(153, 25)
        Me.Panel76.TabIndex = 20
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label14.Location = New System.Drawing.Point(0, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(42, 17)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Umur"
        '
        'Panel77
        '
        Me.Panel77.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel77.Location = New System.Drawing.Point(0, 72)
        Me.Panel77.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel77.Name = "Panel77"
        Me.Panel77.Size = New System.Drawing.Size(153, 11)
        Me.Panel77.TabIndex = 19
        '
        'Panel78
        '
        Me.Panel78.Controls.Add(Me.Label16)
        Me.Panel78.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel78.Location = New System.Drawing.Point(0, 47)
        Me.Panel78.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel78.Name = "Panel78"
        Me.Panel78.Size = New System.Drawing.Size(153, 25)
        Me.Panel78.TabIndex = 18
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label16.Location = New System.Drawing.Point(0, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(104, 17)
        Me.Label16.TabIndex = 2
        Me.Label16.Text = "Nama Lengkap"
        '
        'Panel79
        '
        Me.Panel79.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel79.Location = New System.Drawing.Point(0, 36)
        Me.Panel79.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel79.Name = "Panel79"
        Me.Panel79.Size = New System.Drawing.Size(153, 11)
        Me.Panel79.TabIndex = 17
        '
        'Panel80
        '
        Me.Panel80.Controls.Add(Me.Label17)
        Me.Panel80.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel80.Location = New System.Drawing.Point(0, 11)
        Me.Panel80.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel80.Name = "Panel80"
        Me.Panel80.Size = New System.Drawing.Size(153, 25)
        Me.Panel80.TabIndex = 16
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label17.Location = New System.Drawing.Point(0, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(79, 17)
        Me.Label17.TabIndex = 3
        Me.Label17.Text = "User Name"
        '
        'Panel81
        '
        Me.Panel81.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel81.Location = New System.Drawing.Point(0, 0)
        Me.Panel81.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel81.Name = "Panel81"
        Me.Panel81.Size = New System.Drawing.Size(153, 11)
        Me.Panel81.TabIndex = 15
        '
        'Panel83
        '
        Me.Panel83.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel83.Location = New System.Drawing.Point(0, 0)
        Me.Panel83.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel83.Name = "Panel83"
        Me.Panel83.Size = New System.Drawing.Size(25, 300)
        Me.Panel83.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Panel27)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 62)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(659, 63)
        Me.Panel2.TabIndex = 2
        '
        'Panel27
        '
        Me.Panel27.Controls.Add(Me.btnTambah)
        Me.Panel27.Controls.Add(Me.Panel34)
        Me.Panel27.Controls.Add(Me.btnEdit)
        Me.Panel27.Controls.Add(Me.Panel28)
        Me.Panel27.Controls.Add(Me.btnHapus)
        Me.Panel27.Controls.Add(Me.Panel29)
        Me.Panel27.Controls.Add(Me.btnRefresh)
        Me.Panel27.Controls.Add(Me.Panel30)
        Me.Panel27.Controls.Add(Me.Panel31)
        Me.Panel27.Controls.Add(Me.Panel32)
        Me.Panel27.Controls.Add(Me.Panel33)
        Me.Panel27.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel27.Location = New System.Drawing.Point(0, 0)
        Me.Panel27.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(659, 63)
        Me.Panel27.TabIndex = 3
        '
        'btnTambah
        '
        Me.btnTambah.AutoSize = True
        Me.btnTambah.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnTambah.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnTambah.FlatAppearance.BorderSize = 2
        Me.btnTambah.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTambah.Location = New System.Drawing.Point(23, 15)
        Me.btnTambah.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnTambah.Name = "btnTambah"
        Me.btnTambah.Size = New System.Drawing.Size(131, 33)
        Me.btnTambah.TabIndex = 10
        Me.btnTambah.Text = "Tambah"
        Me.btnTambah.UseVisualStyleBackColor = True
        '
        'Panel34
        '
        Me.Panel34.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel34.Location = New System.Drawing.Point(154, 15)
        Me.Panel34.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel34.Name = "Panel34"
        Me.Panel34.Size = New System.Drawing.Size(29, 33)
        Me.Panel34.TabIndex = 8
        '
        'btnEdit
        '
        Me.btnEdit.AutoSize = True
        Me.btnEdit.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnEdit.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnEdit.FlatAppearance.BorderSize = 2
        Me.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEdit.Location = New System.Drawing.Point(183, 15)
        Me.btnEdit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(131, 33)
        Me.btnEdit.TabIndex = 9
        Me.btnEdit.Text = "Edit"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'Panel28
        '
        Me.Panel28.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel28.Location = New System.Drawing.Point(314, 15)
        Me.Panel28.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(29, 33)
        Me.Panel28.TabIndex = 7
        '
        'btnHapus
        '
        Me.btnHapus.AutoSize = True
        Me.btnHapus.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnHapus.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnHapus.FlatAppearance.BorderSize = 2
        Me.btnHapus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHapus.Location = New System.Drawing.Point(343, 15)
        Me.btnHapus.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnHapus.Name = "btnHapus"
        Me.btnHapus.Size = New System.Drawing.Size(131, 33)
        Me.btnHapus.TabIndex = 1
        Me.btnHapus.Text = "Hapus"
        Me.btnHapus.UseVisualStyleBackColor = True
        '
        'Panel29
        '
        Me.Panel29.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel29.Location = New System.Drawing.Point(474, 15)
        Me.Panel29.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(29, 33)
        Me.Panel29.TabIndex = 8
        '
        'btnRefresh
        '
        Me.btnRefresh.AutoSize = True
        Me.btnRefresh.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnRefresh.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnRefresh.FlatAppearance.BorderSize = 2
        Me.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRefresh.Location = New System.Drawing.Point(503, 15)
        Me.btnRefresh.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(131, 33)
        Me.btnRefresh.TabIndex = 4
        Me.btnRefresh.Text = "Refresh"
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'Panel30
        '
        Me.Panel30.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel30.Location = New System.Drawing.Point(0, 15)
        Me.Panel30.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel30.Name = "Panel30"
        Me.Panel30.Size = New System.Drawing.Size(25, 33)
        Me.Panel30.TabIndex = 5
        '
        'Panel31
        '
        Me.Panel31.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel31.Location = New System.Drawing.Point(634, 15)
        Me.Panel31.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(25, 33)
        Me.Panel31.TabIndex = 6
        '
        'Panel32
        '
        Me.Panel32.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel32.Location = New System.Drawing.Point(0, 0)
        Me.Panel32.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel32.Name = "Panel32"
        Me.Panel32.Size = New System.Drawing.Size(659, 15)
        Me.Panel32.TabIndex = 2
        '
        'Panel33
        '
        Me.Panel33.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel33.Location = New System.Drawing.Point(0, 48)
        Me.Panel33.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel33.Name = "Panel33"
        Me.Panel33.Size = New System.Drawing.Size(659, 15)
        Me.Panel33.TabIndex = 3
        '
        'Panel15
        '
        Me.Panel15.Controls.Add(Me.Panel17)
        Me.Panel15.Controls.Add(Me.Panel21)
        Me.Panel15.Controls.Add(Me.Panel26)
        Me.Panel15.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel15.Location = New System.Drawing.Point(0, 0)
        Me.Panel15.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(659, 62)
        Me.Panel15.TabIndex = 0
        '
        'Panel17
        '
        Me.Panel17.Controls.Add(Me.txtCariNamaPengguna)
        Me.Panel17.Controls.Add(Me.Panel24)
        Me.Panel17.Controls.Add(Me.btnCariPengguna)
        Me.Panel17.Controls.Add(Me.Panel19)
        Me.Panel17.Controls.Add(Me.Panel20)
        Me.Panel17.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel17.Location = New System.Drawing.Point(25, 0)
        Me.Panel17.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(609, 62)
        Me.Panel17.TabIndex = 2
        '
        'txtCariNamaPengguna
        '
        Me.txtCariNamaPengguna.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtCariNamaPengguna.Location = New System.Drawing.Point(0, 15)
        Me.txtCariNamaPengguna.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtCariNamaPengguna.Multiline = True
        Me.txtCariNamaPengguna.Name = "txtCariNamaPengguna"
        Me.txtCariNamaPengguna.Size = New System.Drawing.Size(449, 32)
        Me.txtCariNamaPengguna.TabIndex = 0
        '
        'Panel24
        '
        Me.Panel24.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel24.Location = New System.Drawing.Point(449, 15)
        Me.Panel24.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(29, 32)
        Me.Panel24.TabIndex = 7
        '
        'btnCariPengguna
        '
        Me.btnCariPengguna.AutoSize = True
        Me.btnCariPengguna.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnCariPengguna.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnCariPengguna.FlatAppearance.BorderSize = 2
        Me.btnCariPengguna.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCariPengguna.Location = New System.Drawing.Point(478, 15)
        Me.btnCariPengguna.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCariPengguna.Name = "btnCariPengguna"
        Me.btnCariPengguna.Size = New System.Drawing.Size(131, 32)
        Me.btnCariPengguna.TabIndex = 1
        Me.btnCariPengguna.Text = "Cari"
        Me.btnCariPengguna.UseVisualStyleBackColor = True
        '
        'Panel19
        '
        Me.Panel19.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel19.Location = New System.Drawing.Point(0, 0)
        Me.Panel19.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(609, 15)
        Me.Panel19.TabIndex = 2
        '
        'Panel20
        '
        Me.Panel20.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel20.Location = New System.Drawing.Point(0, 47)
        Me.Panel20.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(609, 15)
        Me.Panel20.TabIndex = 3
        '
        'Panel21
        '
        Me.Panel21.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel21.Location = New System.Drawing.Point(634, 0)
        Me.Panel21.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(25, 62)
        Me.Panel21.TabIndex = 1
        '
        'Panel26
        '
        Me.Panel26.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel26.Location = New System.Drawing.Point(0, 0)
        Me.Panel26.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(25, 62)
        Me.Panel26.TabIndex = 0
        '
        'Panel22
        '
        Me.Panel22.Controls.Add(Me.Label13)
        Me.Panel22.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel22.Location = New System.Drawing.Point(0, 0)
        Me.Panel22.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(659, 66)
        Me.Panel22.TabIndex = 3
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Label13.Location = New System.Drawing.Point(16, 18)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(152, 29)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Daftar User"
        '
        'VScrollBar6
        '
        Me.VScrollBar6.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar6.Location = New System.Drawing.Point(659, 0)
        Me.VScrollBar6.Name = "VScrollBar6"
        Me.VScrollBar6.Size = New System.Drawing.Size(21, 583)
        Me.VScrollBar6.TabIndex = 4
        '
        'jadwal
        '
        Me.jadwal.Interval = 1000
        '
        'AdminDashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(911, 631)
        Me.Controls.Add(Me.panelGrup)
        Me.Controls.Add(Me.listMenuItem)
        Me.Controls.Add(Me.appBar)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "AdminDashboard"
        Me.Text = "AdminDashboard"
        Me.appBar.ResumeLayout(False)
        Me.appBar.PerformLayout()
        CType(Me.showMenuItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.hideMenuItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureAkun, System.ComponentModel.ISupportInitialize).EndInit()
        Me.listMenuItem.ResumeLayout(False)
        Me.listMenuItem.PerformLayout()
        CType(Me.pictureKeluar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureLaporan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureTransaksi, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picturePasien, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureDashboard, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDaftarPasien.ResumeLayout(False)
        Me.panelBerandaDP.ResumeLayout(False)
        Me.panelDatabaseDP.ResumeLayout(False)
        Me.panelDGVPasien.ResumeLayout(False)
        Me.TLPNoData.ResumeLayout(False)
        Me.TLPNoData.PerformLayout()
        CType(Me.dgvDaftarPasien, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelTab.ResumeLayout(False)
        Me.panelTengah.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.panelFormulirPasien.ResumeLayout(False)
        Me.Panel85.ResumeLayout(False)
        Me.Panel91.ResumeLayout(False)
        Me.Panel93.ResumeLayout(False)
        Me.Panel93.PerformLayout()
        Me.Panel95.ResumeLayout(False)
        Me.Panel97.ResumeLayout(False)
        Me.Panel97.PerformLayout()
        Me.Panel99.ResumeLayout(False)
        Me.Panel99.PerformLayout()
        Me.Panel101.ResumeLayout(False)
        Me.Panel101.PerformLayout()
        Me.Panel89.ResumeLayout(False)
        Me.Panel89.PerformLayout()
        Me.Panel103.ResumeLayout(False)
        Me.Panel105.ResumeLayout(False)
        Me.Panel111.ResumeLayout(False)
        Me.Panel117.ResumeLayout(False)
        Me.Panel123.ResumeLayout(False)
        Me.Panel123.PerformLayout()
        Me.Panel125.ResumeLayout(False)
        Me.Panel125.PerformLayout()
        Me.Panel127.ResumeLayout(False)
        Me.Panel127.PerformLayout()
        Me.Panel129.ResumeLayout(False)
        Me.Panel129.PerformLayout()
        Me.Panel131.ResumeLayout(False)
        Me.Panel131.PerformLayout()
        Me.Panel133.ResumeLayout(False)
        Me.Panel133.PerformLayout()
        Me.Panel121.ResumeLayout(False)
        Me.Panel121.PerformLayout()
        Me.Panel136.ResumeLayout(False)
        Me.Panel137.ResumeLayout(False)
        Me.Panel137.PerformLayout()
        Me.Panel145.ResumeLayout(False)
        Me.Panel146.ResumeLayout(False)
        Me.Panel146.PerformLayout()
        Me.panelKeteranganDP.ResumeLayout(False)
        Me.panelKeteranganDP.PerformLayout()
        Me.panelTindakanDP.ResumeLayout(False)
        Me.Panel164.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.Panel84.ResumeLayout(False)
        Me.Panel167.ResumeLayout(False)
        Me.Panel173.ResumeLayout(False)
        Me.Panel173.PerformLayout()
        Me.Panel175.ResumeLayout(False)
        Me.Panel175.PerformLayout()
        Me.Panel177.ResumeLayout(False)
        Me.Panel177.PerformLayout()
        Me.Panel179.ResumeLayout(False)
        Me.Panel179.PerformLayout()
        Me.Panel181.ResumeLayout(False)
        Me.Panel181.PerformLayout()
        Me.Panel183.ResumeLayout(False)
        Me.Panel183.PerformLayout()
        Me.Panel87.ResumeLayout(False)
        Me.Panel87.PerformLayout()
        Me.Panel185.ResumeLayout(False)
        Me.Panel191.ResumeLayout(False)
        Me.Panel191.PerformLayout()
        Me.Panel193.ResumeLayout(False)
        Me.Panel193.PerformLayout()
        Me.Panel195.ResumeLayout(False)
        Me.Panel195.PerformLayout()
        Me.Panel197.ResumeLayout(False)
        Me.Panel197.PerformLayout()
        Me.Panel199.ResumeLayout(False)
        Me.Panel199.PerformLayout()
        Me.Panel201.ResumeLayout(False)
        Me.Panel201.PerformLayout()
        Me.Panel118.ResumeLayout(False)
        Me.Panel118.PerformLayout()
        Me.Panel240.ResumeLayout(False)
        Me.Panel165.ResumeLayout(False)
        Me.Panel165.PerformLayout()
        Me.panelTransaksi.ResumeLayout(False)
        Me.panelDatabaseTransaksi.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel157.ResumeLayout(False)
        Me.Panel158.ResumeLayout(False)
        Me.Panel158.PerformLayout()
        Me.panelKeteranganTransaksi.ResumeLayout(False)
        Me.panelKeteranganTransaksi.PerformLayout()
        Me.panelDashboard.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel35.ResumeLayout(False)
        Me.Panel156.ResumeLayout(False)
        Me.Panel156.PerformLayout()
        Me.Panel154.ResumeLayout(False)
        Me.Panel154.PerformLayout()
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.panelLaporan.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.panelAkun.ResumeLayout(False)
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        Me.panelGrup.ResumeLayout(False)
        Me.panelDaftarUser.ResumeLayout(False)
        Me.Panel14.ResumeLayout(False)
        CType(Me.dgvDaftarUser, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFormulir.ResumeLayout(False)
        Me.Panel40.ResumeLayout(False)
        Me.Panel60.ResumeLayout(False)
        Me.Panel60.PerformLayout()
        Me.Panel58.ResumeLayout(False)
        Me.Panel58.PerformLayout()
        Me.Panel56.ResumeLayout(False)
        Me.Panel54.ResumeLayout(False)
        Me.Panel54.PerformLayout()
        Me.Panel52.ResumeLayout(False)
        Me.Panel50.ResumeLayout(False)
        Me.Panel50.PerformLayout()
        Me.Panel48.ResumeLayout(False)
        Me.Panel48.PerformLayout()
        Me.Panel46.ResumeLayout(False)
        Me.Panel46.PerformLayout()
        Me.Panel23.ResumeLayout(False)
        Me.Panel39.ResumeLayout(False)
        Me.Panel37.ResumeLayout(False)
        Me.Panel18.ResumeLayout(False)
        Me.Panel25.ResumeLayout(False)
        Me.Panel25.PerformLayout()
        Me.Panel68.ResumeLayout(False)
        Me.Panel68.PerformLayout()
        Me.Panel70.ResumeLayout(False)
        Me.Panel70.PerformLayout()
        Me.Panel72.ResumeLayout(False)
        Me.Panel72.PerformLayout()
        Me.Panel74.ResumeLayout(False)
        Me.Panel74.PerformLayout()
        Me.Panel76.ResumeLayout(False)
        Me.Panel76.PerformLayout()
        Me.Panel78.ResumeLayout(False)
        Me.Panel78.PerformLayout()
        Me.Panel80.ResumeLayout(False)
        Me.Panel80.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel27.ResumeLayout(False)
        Me.Panel27.PerformLayout()
        Me.Panel15.ResumeLayout(False)
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout()
        Me.Panel22.ResumeLayout(False)
        Me.Panel22.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents appBar As Panel
    Friend WithEvents showMenuItem As PictureBox
    Friend WithEvents pictureAkun As PictureBox
    Friend WithEvents hideMenuItem As PictureBox
    Friend WithEvents listMenuItem As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents pictureDashboard As PictureBox
    Friend WithEvents pictureKeluar As PictureBox
    Friend WithEvents pictureLaporan As PictureBox
    Friend WithEvents picturePasien As PictureBox
    Friend WithEvents pictureTransaksi As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents textKeterangan As Label
    Friend WithEvents buttonKeluar As Button
    Friend WithEvents buttonAkun As Button
    Friend WithEvents buttonLaporan As Button
    Friend WithEvents buttonTransaksi As Button
    Friend WithEvents buttonDaftar_Pasien As Button
    Friend WithEvents buttonDashboard As Button
    Friend WithEvents panelDaftarPasien As Panel
    Friend WithEvents VScrollBar1 As VScrollBar
    Friend WithEvents panelKeteranganDP As Panel
    Friend WithEvents panelDatabaseDP As Panel
    Friend WithEvents dgvDaftarPasien As DataGridView
    Friend WithEvents panelTab As Panel
    Friend WithEvents btnSemuaPasien As Button
    Friend WithEvents btnBelumSelesaiPasien As Button
    Friend WithEvents panelAtas As Panel
    Friend WithEvents panelKanan As Panel
    Friend WithEvents panelKiri As Panel
    Friend WithEvents panelTengah As Panel
    Friend WithEvents panelTransaksi As Panel
    Friend WithEvents panelDatabaseTransaksi As Panel
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents btnBelumBayar As Button
    Friend WithEvents btnSemuaTransaksi As Button
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Panel9 As Panel
    Friend WithEvents panelKeteranganTransaksi As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents VScrollBar2 As VScrollBar
    Friend WithEvents panelDashboard As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel16 As Panel
    Friend WithEvents Label9 As Label
    Friend WithEvents VScrollBar3 As VScrollBar
    Friend WithEvents panelLaporan As Panel
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Label10 As Label
    Friend WithEvents VScrollBar4 As VScrollBar
    Friend WithEvents panelAkun As Panel
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Label11 As Label
    Friend WithEvents VScrollBar5 As VScrollBar
    Friend WithEvents panelGrup As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label12 As Label
    Friend WithEvents buttonDaftarUser As Button
    Friend WithEvents txtNamaPengguna As Label
    Friend WithEvents panelDaftarUser As Panel
    Friend WithEvents Panel14 As Panel
    Friend WithEvents dgvDaftarUser As DataGridView
    Friend WithEvents VScrollBar6 As VScrollBar
    Friend WithEvents panelFormulir As Panel
    Friend WithEvents Panel27 As Panel
    Friend WithEvents btnTambah As Button
    Friend WithEvents Panel34 As Panel
    Friend WithEvents btnEdit As Button
    Friend WithEvents Panel28 As Panel
    Friend WithEvents btnHapus As Button
    Friend WithEvents Panel29 As Panel
    Friend WithEvents btnRefresh As Button
    Friend WithEvents Panel30 As Panel
    Friend WithEvents Panel31 As Panel
    Friend WithEvents Panel32 As Panel
    Friend WithEvents Panel33 As Panel
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Panel17 As Panel
    Friend WithEvents txtCariNamaPengguna As TextBox
    Friend WithEvents Panel24 As Panel
    Friend WithEvents btnCariPengguna As Button
    Friend WithEvents Panel19 As Panel
    Friend WithEvents Panel20 As Panel
    Friend WithEvents Panel21 As Panel
    Friend WithEvents Panel26 As Panel
    Friend WithEvents Panel22 As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents Panel40 As Panel
    Friend WithEvents Panel23 As Panel
    Friend WithEvents Panel39 As Panel
    Friend WithEvents Panel38 As Panel
    Friend WithEvents Panel37 As Panel
    Friend WithEvents Panel44 As Panel
    Friend WithEvents Panel43 As Panel
    Friend WithEvents Panel42 As Panel
    Friend WithEvents Panel41 As Panel
    Friend WithEvents btnSimpan As Button
    Friend WithEvents Panel36 As Panel
    Friend WithEvents Panel56 As Panel
    Friend WithEvents Panel55 As Panel
    Friend WithEvents Panel54 As Panel
    Friend WithEvents Panel53 As Panel
    Friend WithEvents Panel52 As Panel
    Friend WithEvents Panel51 As Panel
    Friend WithEvents Panel50 As Panel
    Friend WithEvents Panel49 As Panel
    Friend WithEvents Panel48 As Panel
    Friend WithEvents Panel47 As Panel
    Friend WithEvents Panel46 As Panel
    Friend WithEvents Panel61 As Panel
    Friend WithEvents Panel60 As Panel
    Friend WithEvents Panel59 As Panel
    Friend WithEvents Panel58 As Panel
    Friend WithEvents Panel57 As Panel
    Friend WithEvents Panel45 As Panel
    Friend WithEvents Panel62 As Panel
    Friend WithEvents Panel63 As Panel
    Friend WithEvents Panel64 As Panel
    Friend WithEvents Panel65 As Panel
    Friend WithEvents Panel66 As Panel
    Friend WithEvents btnBatal As Button
    Friend WithEvents txtUserName As TextBox
    Friend WithEvents txtNickName As TextBox
    Friend WithEvents Panel18 As Panel
    Friend WithEvents Panel25 As Panel
    Friend WithEvents Panel67 As Panel
    Friend WithEvents Panel68 As Panel
    Friend WithEvents Panel69 As Panel
    Friend WithEvents Panel70 As Panel
    Friend WithEvents Panel71 As Panel
    Friend WithEvents Panel72 As Panel
    Friend WithEvents Panel73 As Panel
    Friend WithEvents Panel74 As Panel
    Friend WithEvents Panel75 As Panel
    Friend WithEvents Panel76 As Panel
    Friend WithEvents Panel77 As Panel
    Friend WithEvents Panel78 As Panel
    Friend WithEvents Label16 As Label
    Friend WithEvents Panel79 As Panel
    Friend WithEvents Panel80 As Panel
    Friend WithEvents Label17 As Label
    Friend WithEvents Panel81 As Panel
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Panel82 As Panel
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Panel83 As Panel
    Friend WithEvents txtAge As TextBox
    Friend WithEvents txtGender As ComboBox
    Friend WithEvents txtAddress As TextBox
    Friend WithEvents txtPosition As ComboBox
    Friend WithEvents txtKonfirmasiPassword As TextBox
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents panelFormulirPasien As Panel
    Friend WithEvents Panel85 As Panel
    Friend WithEvents Panel88 As Panel
    Friend WithEvents Panel89 As Panel
    Friend WithEvents txtNIKPasien As TextBox
    Friend WithEvents Panel90 As Panel
    Friend WithEvents Panel91 As Panel
    Friend WithEvents txtFaskesPasien As ComboBox
    Friend WithEvents Panel92 As Panel
    Friend WithEvents Panel93 As Panel
    Friend WithEvents txtAlamatPasien As TextBox
    Friend WithEvents Panel94 As Panel
    Friend WithEvents Panel95 As Panel
    Friend WithEvents txtJenisKelaminPasien As ComboBox
    Friend WithEvents Panel96 As Panel
    Friend WithEvents Panel97 As Panel
    Friend WithEvents txtUmurPasien As TextBox
    Friend WithEvents Panel98 As Panel
    Friend WithEvents Panel99 As Panel
    Friend WithEvents txtNamaLengkapPasien As TextBox
    Friend WithEvents Panel100 As Panel
    Friend WithEvents Panel101 As Panel
    Friend WithEvents txtUserNamePasien As TextBox
    Friend WithEvents Panel102 As Panel
    Friend WithEvents Panel103 As Panel
    Friend WithEvents Panel104 As Panel
    Friend WithEvents Panel105 As Panel
    Friend WithEvents Panel106 As Panel
    Friend WithEvents Panel107 As Panel
    Friend WithEvents Panel108 As Panel
    Friend WithEvents Panel109 As Panel
    Friend WithEvents btnBatalPasien As Button
    Friend WithEvents Panel110 As Panel
    Friend WithEvents Panel111 As Panel
    Friend WithEvents Panel112 As Panel
    Friend WithEvents Panel113 As Panel
    Friend WithEvents Panel114 As Panel
    Friend WithEvents Panel115 As Panel
    Friend WithEvents btnSimpanPasien As Button
    Friend WithEvents Panel116 As Panel
    Friend WithEvents Panel117 As Panel
    Friend WithEvents Panel120 As Panel
    Friend WithEvents Panel121 As Panel
    Friend WithEvents Label23 As Label
    Friend WithEvents Panel122 As Panel
    Friend WithEvents Panel123 As Panel
    Friend WithEvents Label24 As Label
    Friend WithEvents Panel124 As Panel
    Friend WithEvents Panel125 As Panel
    Friend WithEvents Label25 As Label
    Friend WithEvents Panel126 As Panel
    Friend WithEvents Panel127 As Panel
    Friend WithEvents Label26 As Label
    Friend WithEvents Panel128 As Panel
    Friend WithEvents Panel129 As Panel
    Friend WithEvents Label27 As Label
    Friend WithEvents Panel130 As Panel
    Friend WithEvents Panel131 As Panel
    Friend WithEvents Label28 As Label
    Friend WithEvents Panel132 As Panel
    Friend WithEvents Panel133 As Panel
    Friend WithEvents Label29 As Label
    Friend WithEvents Panel134 As Panel
    Friend WithEvents Panel135 As Panel
    Friend WithEvents Panel136 As Panel
    Friend WithEvents Panel137 As Panel
    Friend WithEvents btnEditPasien As Button
    Friend WithEvents Panel139 As Panel
    Friend WithEvents btnHapusPasien As Button
    Friend WithEvents Panel140 As Panel
    Friend WithEvents btnRefreshPasien As Button
    Friend WithEvents Panel141 As Panel
    Friend WithEvents Panel142 As Panel
    Friend WithEvents Panel143 As Panel
    Friend WithEvents Panel144 As Panel
    Friend WithEvents Panel145 As Panel
    Friend WithEvents Panel146 As Panel
    Friend WithEvents txtCariPasien As TextBox
    Friend WithEvents Panel147 As Panel
    Friend WithEvents btnCariPasien As Button
    Friend WithEvents Panel148 As Panel
    Friend WithEvents Panel149 As Panel
    Friend WithEvents Panel150 As Panel
    Friend WithEvents Panel151 As Panel
    Friend WithEvents Label30 As Label
    Friend WithEvents Panel35 As Panel
    Friend WithEvents Panel155 As Panel
    Friend WithEvents Panel154 As Panel
    Friend WithEvents Panel153 As Panel
    Friend WithEvents Panel152 As Panel
    Friend WithEvents Panel156 As Panel
    Friend WithEvents Label31 As Label
    Friend WithEvents btnTambahPasien As Button
    Friend WithEvents Panel138 As Panel
    Friend WithEvents Panel157 As Panel
    Friend WithEvents Panel158 As Panel
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents Panel159 As Panel
    Friend WithEvents Button8 As Button
    Friend WithEvents Panel160 As Panel
    Friend WithEvents Panel161 As Panel
    Friend WithEvents Panel162 As Panel
    Friend WithEvents Panel163 As Panel
    Friend WithEvents Label33 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents panelDGVPasien As Panel
    Friend WithEvents TLPNoData As TableLayoutPanel
    Friend WithEvents Label35 As Label
    Friend WithEvents panelBerandaDP As Panel
    Friend WithEvents panelTindakanDP As Panel
    Friend WithEvents Panel240 As Panel
    Friend WithEvents Label45 As Label
    Friend WithEvents Panel164 As Panel
    Friend WithEvents Panel84 As Panel
    Friend WithEvents Panel167 As Panel
    Friend WithEvents Panel173 As Panel
    Friend WithEvents txt_IP_Faskes As Label
    Friend WithEvents Panel174 As Panel
    Friend WithEvents Panel175 As Panel
    Friend WithEvents txt_IP_Alamat As Label
    Friend WithEvents Panel176 As Panel
    Friend WithEvents Panel177 As Panel
    Friend WithEvents txt_IP_JenisKelamin As Label
    Friend WithEvents Panel178 As Panel
    Friend WithEvents Panel179 As Panel
    Friend WithEvents txt_IP_Umur As Label
    Friend WithEvents Panel180 As Panel
    Friend WithEvents Panel181 As Panel
    Friend WithEvents txt_IP_NamaLengkap As Label
    Friend WithEvents Panel182 As Panel
    Friend WithEvents Panel183 As Panel
    Friend WithEvents txt_IP_UserName As Label
    Friend WithEvents Panel184 As Panel
    Friend WithEvents Panel185 As Panel
    Friend WithEvents Panel191 As Panel
    Friend WithEvents Label47 As Label
    Friend WithEvents Panel192 As Panel
    Friend WithEvents Panel193 As Panel
    Friend WithEvents Label48 As Label
    Friend WithEvents Panel194 As Panel
    Friend WithEvents Panel195 As Panel
    Friend WithEvents Label49 As Label
    Friend WithEvents Panel196 As Panel
    Friend WithEvents Panel197 As Panel
    Friend WithEvents Label50 As Label
    Friend WithEvents Panel198 As Panel
    Friend WithEvents Panel199 As Panel
    Friend WithEvents Label51 As Label
    Friend WithEvents Panel200 As Panel
    Friend WithEvents Panel201 As Panel
    Friend WithEvents Label52 As Label
    Friend WithEvents Panel202 As Panel
    Friend WithEvents Panel170 As Panel
    Friend WithEvents Panel188 As Panel
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents btn_IP_AjukanDokter As Button
    Friend WithEvents btn_IP_Batal As Button
    Friend WithEvents Panel165 As Panel
    Friend WithEvents btn_IP_Kembali As Button
    Friend WithEvents txtJadwal As Label
    Friend WithEvents jadwal As Timer
    Friend WithEvents Panel86 As Panel
    Friend WithEvents Panel87 As Panel
    Friend WithEvents txt_IP_NIK As Label
    Friend WithEvents Panel119 As Panel
    Friend WithEvents Panel118 As Panel
    Friend WithEvents Label22 As Label
End Class
