﻿Public Class AdminDashboard
    Dim id_users As Integer
    Private Sub TampilDataGrid_DataPasien()
        Dim strtampil As String = "SELECT * FROM tb_pasien AS a ORDER By username"
        Dim strtabel As String = "tb_pasien"
        Call TampilData(strtampil, strtabel)
        dgvDaftarPasien.DataSource = (ds.Tables("tb_pasien"))
        dgvDaftarPasien.ReadOnly = True
    End Sub
    Private Sub JudulGrid_DataPasien()
        dgvDaftarPasien.Columns(0).HeaderText = "ID"
        dgvDaftarPasien.Columns(1).HeaderText = "NIK"
        dgvDaftarPasien.Columns(2).HeaderText = "Username"
        dgvDaftarPasien.Columns(3).HeaderText = "Nama Lengkap"
        dgvDaftarPasien.Columns(4).HeaderText = "Umur"
        dgvDaftarPasien.Columns(5).HeaderText = "Jenis Kelamin"
        dgvDaftarPasien.Columns(6).HeaderText = "Alamat"
        dgvDaftarPasien.Columns(7).HeaderText = "Faskes"
        dgvDaftarPasien.Columns(8).HeaderText = "Status"
        dgvDaftarPasien.Columns(0).Width = 50
        dgvDaftarPasien.Columns(1).Width = 150
        dgvDaftarPasien.Columns(2).Width = 100
        dgvDaftarPasien.Columns(3).Width = 200
        dgvDaftarPasien.Columns(4).Width = 50
        dgvDaftarPasien.Columns(5).Width = 100
        dgvDaftarPasien.Columns(6).Width = 200
        dgvDaftarPasien.Columns(7).Width = 200
        dgvDaftarPasien.Columns(8).Width = 150
    End Sub

    Private Sub RefreshForm_DataPasien()
        TLPNoData.Visible = False
        panelFormulirPasien.Visible = False
        Call Me.TampilDataGrid_DataPasien()
        Call Me.JudulGrid_DataPasien()
        dgvDaftarPasien.Focus()
    End Sub
    Private Sub ClearForm_DataPasien()
        txtUserNamePasien.Text = ""
        txtNamaLengkapPasien.Text = ""
        txtUmurPasien.Text = ""
        txtJenisKelaminPasien.Text = ""
        txtAlamatPasien.Text = ""
        txtFaskesPasien.Text = ""
        txtNIKPasien.Text = ""
        txtUserNamePasien.Enabled = True
        txtNamaLengkapPasien.Enabled = True
        txtUmurPasien.Enabled = True
        txtJenisKelaminPasien.Enabled = True
        txtAlamatPasien.Enabled = True
        txtFaskesPasien.Enabled = True
        txtNIKPasien.Enabled = True

        btnSimpanPasien.Enabled = True
        btnBatalPasien.Enabled = True

        txtUserNamePasien.Focus()
    End Sub
    Private Sub Simpan_DataPasien()
        Dim SQLSelect, SQLSimpan As String
        If (txtNIKPasien.Text = "") Or
            (txtUserNamePasien.Text = "") Or
            (txtNamaLengkapPasien.Text = "") Or
            (txtUmurPasien.Text = "") Or
            (txtJenisKelaminPasien.Text = "") Or
            (txtAlamatPasien.Text = "") Or
            (txtFaskesPasien.Text = "") Then
            MsgBox("Data pasien belum lengkap!", vbInformation, "Tambah Data")
            Exit Sub
        End If
        SQLSelect = "SELECT username FROM tb_pasien WHERE username like '" & txtUserNamePasien.Text & "'"
        If KoneksiDB.CariData(SQLSelect) Then
            MsgBox("Data pasien sudah terdaftar", vbInformation, "Tambah Data")
            Exit Sub
        End If

        SQLSimpan = "INSERT INTO tb_pasien (nik,username,namalengkap,umur,jeniskelamin,alamat,faskes) 
VALUES ('" & txtNIKPasien.Text & "',
'" & txtUserNamePasien.Text & "',
'" & txtNamaLengkapPasien.Text & "',
'" & txtUmurPasien.Text & "',
'" & txtJenisKelaminPasien.Text & "',
'" & txtAlamatPasien.Text & "',
'" & txtFaskesPasien.Text & "')"
        Call KoneksiDB.ProsesSQL(SQLSimpan)
        MsgBox("Data pasien berhasil ditambahkan", vbInformation, "Tambah Data")
        Call Me.RefreshForm_DataPasien()
    End Sub

    Private Sub Update_DataPasien()
        Dim SQLSelect, SQLUpdate As String
        If (txtNIKPasien.Text = "") Or
            (txtUserNamePasien.Text = "") Or
            (txtNamaLengkapPasien.Text = "") Or
            (txtUmurPasien.Text = "") Or
            (txtJenisKelaminPasien.Text = "") Or
            (txtAlamatPasien.Text = "") Or
            (txtFaskesPasien.Text = "") Then
            MsgBox("Data pasien belum lengkap!", vbInformation, "Tambah Data")
            Exit Sub
        End If
        SQLSelect = "SELECT username FROM tb_pasien WHERE username like'" & txtUserNamePasien.Text & "' AND id != '" & id_users & "'"
        If KoneksiDB.CariData(SQLSelect) Then
            MsgBox("Data pasien sudah terdaftar", vbInformation, "Tambah Data")
            Exit Sub
        End If
        SQLUpdate = "UPDATE tb_pasien SET nik = '" & txtUserNamePasien.Text & "',username = '" & txtUserNamePasien.Text & "',namalengkap = '" & txtNamaLengkapPasien.Text & "',umur = '" & txtUmurPasien.Text & "',jeniskelamin = '" & txtJenisKelaminPasien.Text & "',alamat = '" & txtAlamatPasien.Text & "',faskes = '" & txtFaskesPasien.Text & "' WHERE id = '" & id_users & "'"
        Call KoneksiDB.ProsesSQL(SQLUpdate)

        MsgBox("Data pasien berhasil diupdate", vbInformation, "Tambah Data")
        Call Me.RefreshForm_DataPasien()
    End Sub

    Private Sub TampilDataGrid_DataUser()
        Dim strtampil As String = "SELECT id,username,namalengkap,umur,jeniskelamin,alamat,jabatan FROM tb_user AS a ORDER By username"
        Dim strtabel As String = "tb_user"
        Call TampilData(strtampil, strtabel)
        dgvDaftarUser.DataSource = (ds.Tables("tb_user"))
        dgvDaftarUser.ReadOnly = True
    End Sub
    Private Sub JudulGrid_DataUser()
        dgvDaftarUser.Columns(0).HeaderText = "ID"
        dgvDaftarUser.Columns(1).HeaderText = "Username"
        dgvDaftarUser.Columns(2).HeaderText = "Nama Lengkap"
        dgvDaftarUser.Columns(3).HeaderText = "Umur"
        dgvDaftarUser.Columns(4).HeaderText = "Jenis Kelamin"
        dgvDaftarUser.Columns(5).HeaderText = "Alamat"
        dgvDaftarUser.Columns(6).HeaderText = "Jabatan"
        dgvDaftarUser.Columns(0).Width = 50
        dgvDaftarUser.Columns(1).Width = 150
        dgvDaftarUser.Columns(2).Width = 250
        dgvDaftarUser.Columns(3).Width = 50
        dgvDaftarUser.Columns(4).Width = 150
        dgvDaftarUser.Columns(5).Width = 300
        dgvDaftarUser.Columns(6).Width = 200
    End Sub
    Private Sub RefreshForm_DataUser()
        txtUserName.Text = ""
        txtNickName.Text = ""
        txtAge.Text = ""
        txtGender.Text = ""
        txtAddress.Text = ""
        txtPosition.Text = ""
        txtPassword.Text = ""
        txtKonfirmasiPassword.Text = ""
        panelFormulir.Visible = False
        Call Me.TampilDataGrid_DataUser()
        Call Me.JudulGrid_DataUser()
        dgvDaftarUser.Focus()
    End Sub
    Private Sub ClearForm_DataUser()
        txtUserName.Text = ""
        txtNickName.Text = ""
        txtAge.Text = ""
        txtGender.Text = ""
        txtAddress.Text = ""
        txtPosition.Text = ""
        txtPassword.Text = ""
        txtKonfirmasiPassword.Text = ""
        txtUserName.Enabled = True
        txtNickName.Enabled = True
        txtAge.Enabled = True
        txtGender.Enabled = True
        txtAddress.Enabled = True
        txtPosition.Enabled = True
        txtPassword.Enabled = True
        txtKonfirmasiPassword.Enabled = True

        btnSimpan.Enabled = True
        btnBatal.Enabled = True

        txtUserName.Focus()
    End Sub
    Private Sub Simpan_DataUser()
        Dim SQLSelect, SQLSimpan As String
        If (txtUserName.Text = "") Or (txtNickName.Text = "") Or (txtAge.Text = "") Or (txtGender.Text = "") Or (txtAddress.Text = "") Or (txtPosition.Text = "") Or (txtPassword.Text = "") Or (txtKonfirmasiPassword.Text = "") Then
            MsgBox("Data belum lengkap!", vbInformation, "Tambah Data")
            Exit Sub
        End If
        SQLSelect = "SELECT username FROM tb_user WHERE username like '" & txtUserName.Text & "'"
        If KoneksiDB.CariData(SQLSelect) Then
            MsgBox("Data sudah terdaftar", vbInformation, "Tambah Data")
            Exit Sub
        End If

        SQLSimpan = "INSERT INTO tb_user (username,namalengkap,umur,jeniskelamin,alamat,jabatan,password) VALUES ('" & txtUserName.Text & "',
'" & txtNickName.Text & "','" & txtAge.Text & "','" & txtGender.Text & "','" & txtAddress.Text & "','" & txtPosition.Text & "',MD5('" & txtPassword.Text & "'))"
        Call KoneksiDB.ProsesSQL(SQLSimpan)
        MsgBox("Data berhasil ditambahkan", vbInformation, "Tambah Data")
        Call Me.RefreshForm_DataUser()
    End Sub

    Private Sub Update_DataUser()
        Dim SQLSelect, SQLUpdate As String
        If (txtUserName.Text = "") Or (txtNickName.Text = "") Or (txtAge.Text = "") Or (txtGender.Text = "") Or (txtAddress.Text = "") Or (txtPosition.Text = "") Or (txtPassword.Text = "") Or (txtKonfirmasiPassword.Text = "") Then
            MsgBox("Data belum lengkap!", vbInformation, "Tambah Data")
            Exit Sub
        End If
        SQLSelect = "SELECT username FROM tb_user WHERE username like'" & txtUserName.Text & "' AND id != '" & id_users & "'"
        If KoneksiDB.CariData(SQLSelect) Then
            MsgBox("Data sudah terdaftar", vbInformation, "Tambah Data")
            Exit Sub
        End If
        SQLUpdate = "UPDATE tb_user SET username = '" & txtUserName.Text & "',namalengkap = '" & txtNickName.Text & "',umur = '" & txtAge.Text & "',jeniskelamin = '" & txtGender.Text & "',alamat = '" & txtAddress.Text & "',jabatan = '" & txtPosition.Text & "',password = MD5('" & txtPassword.Text & "') WHERE id = '" & id_users & "'"
        Call KoneksiDB.ProsesSQL(SQLUpdate)

        MsgBox("Data berhasil diupdate", vbInformation, "Tambah Data")
        Call Me.RefreshForm_DataUser()
    End Sub

    Private Sub AdminDashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call KoneksiDB.KonekDB()
        Call Me.RefreshForm_DataUser()
        Call Me.RefreshForm_DataPasien()
        Label30.Text = dgvDaftarUser.Rows.Count
        jadwal.Enabled = True
    End Sub
    Private Sub showMenuItem_Click(sender As Object, e As EventArgs) Handles showMenuItem.Click
        listMenuItem.Visible = True
        showMenuItem.Visible = False
    End Sub
    Private Sub hideMenuItem_Click(sender As Object, e As EventArgs) Handles hideMenuItem.Click
        listMenuItem.Visible = False
        showMenuItem.Visible = True
    End Sub
    Private Sub buttonDashboard_Click(sender As Object, e As EventArgs) Handles buttonDashboard.Click
        panelDashboard.Visible = True
        panelDaftarPasien.Visible = False
        panelTransaksi.Visible = False
        panelLaporan.Visible = False
        panelAkun.Visible = False
        panelDaftarUser.Visible = False
    End Sub

    Private Sub buttonDaftar_Pasien_Click(sender As Object, e As EventArgs) Handles buttonDaftar_Pasien.Click
        panelDashboard.Visible = False
        panelDaftarPasien.Visible = True
        panelTransaksi.Visible = False
        panelLaporan.Visible = False
        panelAkun.Visible = False
        panelDaftarUser.Visible = False
    End Sub

    Private Sub buttonTransaksi_Click(sender As Object, e As EventArgs) Handles buttonTransaksi.Click
        panelDashboard.Visible = False
        panelDaftarPasien.Visible = False
        panelTransaksi.Visible = True
        panelLaporan.Visible = False
        panelAkun.Visible = False
        panelDaftarUser.Visible = False
    End Sub

    Private Sub buttonLaporan_Click(sender As Object, e As EventArgs) Handles buttonLaporan.Click
        panelDashboard.Visible = False
        panelDaftarPasien.Visible = False
        panelTransaksi.Visible = False
        panelLaporan.Visible = True
        panelAkun.Visible = False
        panelDaftarUser.Visible = False
    End Sub

    Private Sub buttonAkun_Click(sender As Object, e As EventArgs) Handles buttonAkun.Click
        panelDashboard.Visible = False
        panelDaftarPasien.Visible = False
        panelTransaksi.Visible = False
        panelLaporan.Visible = False
        panelAkun.Visible = True
        panelDaftarUser.Visible = False
    End Sub
    Private Sub butttonDaftarUser_Click(sender As Object, e As EventArgs) Handles buttonDaftarUser.Click
        panelDashboard.Visible = False
        panelDaftarPasien.Visible = False
        panelTransaksi.Visible = False
        panelLaporan.Visible = False
        panelAkun.Visible = False
        panelDaftarUser.Visible = True
    End Sub

    Private Sub buttonKeluar_Click(sender As Object, e As EventArgs) Handles buttonKeluar.Click
        Me.Close()
    End Sub

    Private Sub btnTambah_Click(sender As Object, e As EventArgs) Handles btnTambah.Click
        Me.panelFormulir.Visible = True
        Call Me.ClearForm_DataUser()
        btnSimpan.Text = "Simpan"
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        Me.panelFormulir.Visible = True
        Dim SQLCari As String
        If dgvDaftarUser.Rows.Item(dgvDaftarUser.CurrentRow.Index).Cells(0).Value.ToString() = "" Then
            MsgBox("Data kosong!", vbInformation, "Pilih Data")
        Else
            id_users = dgvDaftarUser.Rows.Item(dgvDaftarUser.CurrentRow.Index).Cells(0).Value
            SQLCari = "SELECT * FROM tb_user WHERE id = '" & id_users & "'"
            cmd = New Odbc.OdbcCommand
            cmd.CommandType = CommandType.Text
            cmd.Connection = conn
            cmd.CommandText = SQLCari
            dr = cmd.ExecuteReader()
            If dr.Read Then
                txtUserName.Text = dr.Item("Username")
                txtAge.Text = dr.Item("Umur")
                txtAddress.Text = dr.Item("Alamat")
                txtPosition.Text = dr.Item("Jabatan")
                panelFormulir.Visible = True
                btnSimpan.Text = "Update"
                btnSimpan.Enabled = True
                btnBatal.Enabled = True
            End If
        End If
    End Sub

    Private Sub btnHapus_Click(sender As Object, e As EventArgs) Handles btnHapus.Click
        Dim Hapus, SQLHapus As String
        If dgvDaftarUser.Rows.Item(dgvDaftarUser.CurrentRow.Index).Cells(0).Value.ToString = "" Then
            MsgBox("Data kosong!", vbInformation, "Pilih Data")
        Else
            id_users = dgvDaftarUser.Rows.Item(dgvDaftarUser.CurrentRow.Index).Cells(0).Value
            Hapus = MessageBox.Show("Yakin data ID " & id_users & " mau dihapus ?", "Keluar", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If Hapus = MsgBoxResult.Yes Then
                SQLHapus = "DELETE FROM tb_user WHERE id = '" & id_users & "'"
                Call KoneksiDB.ProsesSQL(SQLHapus)
                MsgBox("Data sudah terhapus!", vbInformation, "Hapus Data")
                Call Me.RefreshForm_DataUser()
            End If
        End If
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        Call Me.RefreshForm_DataUser()
    End Sub

    Private Sub btnCariPengguna_Click(sender As Object, e As EventArgs) Handles btnCariPengguna.Click
        Dim strtampil As String = "SELECT id,username,namalengkap,umur,jeniskelamin,alamat,jabatan FROM tb_user WHERE username like '%" & txtCariNamaPengguna.Text & "%' ORDER By username"
        Dim strtabel As String = "tb_user"
        Call TampilData(strtampil, strtabel)
        dgvDaftarUser.DataSource = (ds.Tables("tb_user"))
        dgvDaftarUser.ReadOnly = True
    End Sub

    Private Sub btnSimpan_Click(sender As Object, e As EventArgs) Handles btnSimpan.Click
        panelFormulir.Visible = False
        If btnSimpan.Text = "Simpan" Then
            Call Me.Simpan_DataUser()
        ElseIf btnSimpan.Text = "Update" Then
            Call Me.Update_DataUser()
        End If
    End Sub

    Private Sub btnBatal_Click(sender As Object, e As EventArgs) Handles btnBatal.Click
        Me.panelFormulir.Visible = False
    End Sub

    Private Sub btnTambahPasien_Click(sender As Object, e As EventArgs) Handles btnTambahPasien.Click
        Me.panelFormulirPasien.Visible = True
        Call Me.ClearForm_DataPasien()
        btnSimpanPasien.Text = "Simpan"
    End Sub

    Private Sub btnEditPasien_Click(sender As Object, e As EventArgs) Handles btnEditPasien.Click
        Me.panelFormulirPasien.Visible = True
        Dim SQLCari As String
        If dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(0).Value.ToString() = "" Then
            MsgBox("Data pasien kosong!", vbInformation, "Pilih Data")
        Else
            id_users = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(0).Value
            SQLCari = "SELECT * FROM tb_pasien WHERE id = '" & id_users & "'"
            cmd = New Odbc.OdbcCommand
            cmd.CommandType = CommandType.Text
            cmd.Connection = conn
            cmd.CommandText = SQLCari
            dr = cmd.ExecuteReader()
            If dr.Read Then
                txtUserNamePasien.Text = dr.Item("Username")
                txtUmurPasien.Text = dr.Item("Umur")
                txtAlamatPasien.Text = dr.Item("Alamat")
                txtFaskesPasien.Text = dr.Item("Faskes")
                txtNIKPasien.Text = dr.Item("NIK")
                panelFormulirPasien.Visible = True
                btnSimpanPasien.Text = "Update"
                btnSimpanPasien.Enabled = True
                btnBatalPasien.Enabled = True
            End If
        End If
    End Sub

    Private Sub btnHapusPasien_Click(sender As Object, e As EventArgs) Handles btnHapusPasien.Click
        Dim Hapus, SQLHapus As String
        If dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(0).Value.ToString = "" Then
            MsgBox("Data pasien kosong!", vbInformation, "Pilih Data")
        Else
            id_users = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(0).Value
            Hapus = MessageBox.Show("Yakin data pasien ID " & id_users & " mau dihapus ?", "Konfirmasi Hapus", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If Hapus = MsgBoxResult.Yes Then
                SQLHapus = "DELETE FROM tb_pasien WHERE id = '" & id_users & "'"
                Call KoneksiDB.ProsesSQL(SQLHapus)
                MsgBox("Data pasien sudah terhapus!", vbInformation, "Hapus Data")
                Call Me.RefreshForm_DataPasien()
            End If
        End If
    End Sub

    Private Sub btnRefreshPasien_Click(sender As Object, e As EventArgs) Handles btnRefreshPasien.Click
        Call Me.RefreshForm_DataPasien()
    End Sub

    Private Sub btnCariPasien_Click(sender As Object, e As EventArgs) Handles btnCariPasien.Click
        Dim strtampil As String = "SELECT * FROM tb_pasien WHERE username like '%" & txtCariPasien.Text & "%' ORDER By username"
        Dim strtabel As String = "tb_pasien"
        Call TampilData(strtampil, strtabel)
        dgvDaftarPasien.DataSource = (ds.Tables("tb_pasien"))
        dgvDaftarPasien.ReadOnly = True
    End Sub

    Private Sub btnSimpanPasien_Click(sender As Object, e As EventArgs) Handles btnSimpanPasien.Click
        panelFormulirPasien.Visible = False
        If btnSimpanPasien.Text = "Simpan" Then
            Call Me.Simpan_DataPasien()
        ElseIf btnSimpanPasien.Text = "Update" Then
            Call Me.Update_DataPasien()
        End If
    End Sub

    Private Sub btnBatalPasien_Click(sender As Object, e As EventArgs) Handles btnBatalPasien.Click
        Me.panelFormulirPasien.Visible = False
    End Sub

    Private Sub btnBelumSelesaiPasien_Click(sender As Object, e As EventArgs) Handles btnBelumSelesaiPasien.Click
        Dim dt As New DataTable
        cmd = New Odbc.OdbcCommand("SELECT * FROM tb_pasien WHERE status = 'Menunggu Antrian'", conn)
        If dgvDaftarPasien.Rows.Count = 0 Then
            TLPNoData.Visible = True
            dgvDaftarPasien.Visible = False
        ElseIf dgvDaftarPasien.Rows.Count > 0 Then
            TLPNoData.Visible = False
            dgvDaftarPasien.Visible = True
            da.SelectCommand = cmd
            dt.Clear()
            da.Fill(dt)
            dgvDaftarPasien.DataSource = dt
        End If
    End Sub

    Private Sub btnSemuaPasien_Click(sender As Object, e As EventArgs) Handles btnSemuaPasien.Click
        TLPNoData.Visible = False
        dgvDaftarPasien.Visible = True
        Call Me.RefreshForm_DataPasien()
    End Sub

    Private Sub dgvDaftarPasien_CellMouseDoubleClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgvDaftarPasien.CellMouseDoubleClick
        Dim getID = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(0).Value
        Dim getNIK = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(1).Value
        Dim getUser_Name = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(2).Value
        Dim getNama_Lengkap = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(3).Value
        Dim getUmur = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(4).Value
        Dim getJenis_Kelamin = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(5).Value
        Dim getAlamat = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(6).Value
        Dim getFaskes = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(7).Value
        If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 Then
            Dim selectedRow As DataGridViewRow = dgvDaftarPasien.Rows(e.RowIndex)
            panelBerandaDP.Visible = False
            panelTindakanDP.Visible = True
            txt_IP_NIK.Text = getNIK
            txt_IP_UserName.Text = getUser_Name
            txt_IP_NamaLengkap.Text = getNama_Lengkap
            txt_IP_Umur.Text = getUmur
            txt_IP_JenisKelamin.Text = getJenis_Kelamin
            txt_IP_Alamat.Text = getAlamat
            txt_IP_Faskes.Text = getFaskes
        End If
    End Sub

    Private Sub btn_IP_Kembali_Click(sender As Object, e As EventArgs) Handles btn_IP_Kembali.Click
        panelBerandaDP.Visible = True
        panelTindakanDP.Visible = False
    End Sub

    Private Sub btn_IP_AjukanDokter_Click(sender As Object, e As EventArgs) Handles btn_IP_AjukanDokter.Click
        Dim SQLUpdateStatus As String = "UPDATE tb_pasien SET status = 'Menunggu Dokter' WHERE username = '" & txt_IP_UserName.Text & "'"
        KoneksiDB.ProsesSQL(SQLUpdateStatus)
        panelBerandaDP.Visible = True
        panelTindakanDP.Visible = False
    End Sub

    Private Sub btn_IP_Batal_Click(sender As Object, e As EventArgs) Handles btn_IP_Batal.Click
        panelBerandaDP.Visible = True
        panelTindakanDP.Visible = False
    End Sub

    Private Sub jadwal_Tick(sender As Object, e As EventArgs) Handles jadwal.Tick
        txtJadwal.Text = Date.Now.ToString("dd mm yyyy hh:mm:ss")
    End Sub
End Class