﻿Public Class ApotekerDashboard
    Dim id_users As Integer
    Private Sub TampilDataGrid()
        Dim strtampil As String = "SELECT * FROM tb_obat AS a ORDER By namaobat"
        Dim strtabel As String = "tb_obat"
        Call TampilData(strtampil, strtabel)
        dgvDaftarObat.DataSource = (ds.Tables("tb_obat"))
        dgvDaftarObat.ReadOnly = True
    End Sub
    Private Sub JudulGrid()
        dgvDaftarObat.Columns(0).HeaderText = "ID"
        dgvDaftarObat.Columns(1).HeaderText = "Nama Obat"
        dgvDaftarObat.Columns(2).HeaderText = "Jumlah Obat"
        dgvDaftarObat.Columns(3).HeaderText = "Harga Obat"
        dgvDaftarObat.Columns(4).HeaderText = "Stok Masuk"
        dgvDaftarObat.Columns(5).HeaderText = "Stok Keluar"
        dgvDaftarObat.Columns(0).Width = 50
        dgvDaftarObat.Columns(1).Width = 250
        dgvDaftarObat.Columns(2).Width = 150
        dgvDaftarObat.Columns(3).Width = 150
        dgvDaftarObat.Columns(4).Width = 150
        dgvDaftarObat.Columns(5).Width = 150
    End Sub
    Private Sub RefreshForm()
        txtNamaObat.Text = ""
        txtJumlahObat.Text = ""
        txtHargaObat.Text = ""
        panelFormulirObat.Visible = False
        Call Me.TampilDataGrid()
        Call Me.JudulGrid()
        dgvDaftarObat.Focus()
    End Sub
    Private Sub ClearForm()
        txtNamaObat.Text = ""
        txtJumlahObat.Text = ""
        txtHargaObat.Text = ""
        panelFormulirObat.Visible = True

        txtNamaObat.Focus()
    End Sub
    Private Sub Simpan()
        Dim SQLSelect, SQLSimpan As String
        If (txtNamaObat.Text = "") Or (txtJumlahObat.Text = "") Or (txtHargaObat.Text = "") Then
            MsgBox("Data belum lengkap!", vbInformation, "Tambah Data")
            Exit Sub
        End If
        SQLSelect = "SELECT namaobat FROM tb_obat WHERE namaobat like '" & txtNamaObat.Text & "'"
        If KoneksiDB.CariData(SQLSelect) Then
            MsgBox("Obat sudah terdaftar", vbInformation, "Tambah Data")
            Exit Sub
        End If

        SQLSimpan = "INSERT INTO tb_obat (namaobat,jumlahobat,hargaobat,stokmasuk,stokkeluar) 
VALUES ('" & txtNamaObat.Text & "','" & txtJumlahObat.Text & "','" & txtHargaObat.Text & "','0','0')"
        Call KoneksiDB.ProsesSQL(SQLSimpan)
        MsgBox("Data berhasil ditambahkan", vbInformation, "Tambah Data")
        Call Me.RefreshForm()
    End Sub

    Private Overloads Sub Update()
        Dim SQLSelect, SQLUpdate As String
        If (txtNamaObat.Text = "") Or (txtJumlahObat.Text = "") Or (txtHargaObat.Text = "") Then
            MsgBox("Data belum lengkap!", vbInformation, "Tambah Data")
            Exit Sub
        End If
        SQLSelect = "SELECT namaobat FROM tb_obat WHERE namaobat like'" & txtNamaObat.Text & "' AND id != '" & id_users & "'"
        If KoneksiDB.CariData(SQLSelect) Then
            MsgBox("Obat sudah terdaftar", vbInformation, "Tambah Data")
            Exit Sub
        End If
        SQLUpdate = "UPDATE tb_obat SET namaobat = '" & txtNamaObat.Text & "', jumlahobat = '" & txtJumlahObat.Text & "', hargaobat = '" & txtHargaObat.Text & "' WHERE id = '" & id_users & "'"
        Call KoneksiDB.ProsesSQL(SQLUpdate)

        MsgBox("Data berhasil diupdate", vbInformation, "Tambah Data")
        Call Me.RefreshForm()
    End Sub
    Private Sub TampilDataGrid_DataPasien()
        Dim strtampil As String = "SELECT id,username,namalengkap,umur,jeniskelamin,alamat,faskes FROM tb_pasien AS a ORDER By username"
        Dim strtabel As String = "tb_pasien"
        Call TampilData(strtampil, strtabel)
        dgvDaftarPasien.DataSource = (ds.Tables("tb_pasien"))
        dgvDaftarPasien.ReadOnly = True
    End Sub
    Private Sub JudulGrid_DataPasien()
        dgvDaftarPasien.Columns(0).HeaderText = "ID"
        dgvDaftarPasien.Columns(1).HeaderText = "Username"
        dgvDaftarPasien.Columns(2).HeaderText = "Nama Lengkap"
        dgvDaftarPasien.Columns(3).HeaderText = "Umur"
        dgvDaftarPasien.Columns(4).HeaderText = "Jenis Kelamin"
        dgvDaftarPasien.Columns(5).HeaderText = "Alamat"
        dgvDaftarPasien.Columns(6).HeaderText = "Faskes"
        dgvDaftarPasien.Columns(0).Width = 50
        dgvDaftarPasien.Columns(1).Width = 150
        dgvDaftarPasien.Columns(2).Width = 250
        dgvDaftarPasien.Columns(3).Width = 50
        dgvDaftarPasien.Columns(4).Width = 150
        dgvDaftarPasien.Columns(5).Width = 300
        dgvDaftarPasien.Columns(6).Width = 200
    End Sub
    Private Sub RefreshForm_DataPasien()
        Call Me.TampilDataGrid_DataPasien()
        Call Me.JudulGrid_DataPasien()
        dgvDaftarPasien.Focus()
    End Sub
    Private Sub showMenuItem_Click(sender As Object, e As EventArgs) Handles showMenuItem.Click
        listMenuItem.Visible = True
        showMenuItem.Visible = False
    End Sub
    Private Sub hideMenuItem_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        listMenuItem.Visible = False
        showMenuItem.Visible = True
    End Sub
    Private Sub ApotekerDashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call KoneksiDB.KonekDB()
        Call Me.RefreshForm_DataPasien()
        Call Me.RefreshForm()
        textKeterangan.Focus()
        jadwal.Enabled = True
    End Sub

    Private Sub btnTindakanObat_Click(sender As Object, e As EventArgs)
        PilihObat.ShowDialog()
    End Sub

    Private Sub buttonDashboard_Click(sender As Object, e As EventArgs) Handles buttonDashboard.Click
        panelDashboard.Visible = True
        panelDaftarPasien.Visible = False
        panelDaftarObat.Visible = False
        panelTransaksi.Visible = False
        panelLaporan.Visible = False
        panelAkun.Visible = False
    End Sub

    Private Sub buttonDaftar_Pasien_Click(sender As Object, e As EventArgs) Handles buttonDaftar_Pasien.Click
        panelDashboard.Visible = False
        panelDaftarPasien.Visible = True
        panelDaftarObat.Visible = False
        panelTransaksi.Visible = False
        panelLaporan.Visible = False
        panelAkun.Visible = False
    End Sub
    Private Sub buttonDaftar_Obat_Click(sender As Object, e As EventArgs) Handles buttonDaftar_Obat.Click
        panelDashboard.Visible = False
        panelDaftarPasien.Visible = False
        panelDaftarObat.Visible = True
        panelTransaksi.Visible = False
        panelLaporan.Visible = False
        panelAkun.Visible = False
    End Sub
    Private Sub buttonTransaksi_Click(sender As Object, e As EventArgs) Handles buttonTransaksi.Click
        panelDashboard.Visible = False
        panelDaftarPasien.Visible = False
        panelDaftarObat.Visible = False
        panelTransaksi.Visible = True
        panelLaporan.Visible = False
        panelAkun.Visible = False
    End Sub

    Private Sub buttonLaporan_Click(sender As Object, e As EventArgs) Handles buttonLaporan.Click
        panelDashboard.Visible = False
        panelDaftarPasien.Visible = False
        panelDaftarObat.Visible = False
        panelTransaksi.Visible = False
        panelLaporan.Visible = True
        panelAkun.Visible = False
    End Sub

    Private Sub buttonAkun_Click(sender As Object, e As EventArgs) Handles buttonAkun.Click
        panelDashboard.Visible = False
        panelDaftarPasien.Visible = False
        panelDaftarObat.Visible = False
        panelTransaksi.Visible = False
        panelLaporan.Visible = False
        panelAkun.Visible = True
    End Sub
    Private Sub buttonKeluar_Click(sender As Object, e As EventArgs) Handles buttonKeluar.Click
        Me.Close()
    End Sub

    Private Sub btnCariPasien_Click(sender As Object, e As EventArgs) Handles btnCariPasien.Click
        Dim strtampil As String = "SELECT id,username,namalengkap,umur,jeniskelamin,alamat,faskes FROM tb_pasien WHERE username like '%" & txtCariPasien.Text & "%' ORDER By username"
        Dim strtabel As String = "tb_pasien"
        Call TampilData(strtampil, strtabel)
        dgvDaftarPasien.DataSource = (ds.Tables("tb_pasien"))
        dgvDaftarPasien.ReadOnly = True
    End Sub

    Private Sub btn_IP_Kembali_Click(sender As Object, e As EventArgs) Handles btn_IP_Kembali.Click
        panelBerandaDP.Visible = True
        panelTindakanDP.Visible = False
    End Sub

    Private Sub btn_IP_Batal_Click(sender As Object, e As EventArgs) Handles btn_IP_Batal.Click
        panelBerandaDP.Visible = True
        panelTindakanDP.Visible = False
    End Sub

    Private Sub dgvDaftarPasien_CellMouseDoubleClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgvDaftarPasien.CellMouseDoubleClick
        Dim getID = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(0).Value
        'Dim getNIK = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(1).Value
        Dim getUser_Name = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(1).Value
        Dim getNama_Lengkap = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(2).Value
        Dim getUmur = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(3).Value
        Dim getJenis_Kelamin = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(4).Value
        Dim getAlamat = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(5).Value
        Dim getfaskes = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(6).Value
        If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 Then
            Dim selectedRow As DataGridViewRow = dgvDaftarPasien.Rows(e.RowIndex)
            panelBerandaDP.Visible = False
            panelTindakanDP.Visible = True
            txt_IP_NIK.Text = getID
            txt_IP_UserName.Text = getUser_Name
            txt_IP_NamaLengkap.Text = getNama_Lengkap
            txt_IP_Umur.Text = getUmur
            txt_IP_JenisKelamin.Text = getJenis_Kelamin
            txt_IP_Alamat.Text = getAlamat
            txt_IP_Faskes.Text = getfaskes
        End If
    End Sub
    Private Sub jadwal_Tick(sender As Object, e As EventArgs) Handles jadwal.Tick
        txtJadwal.Text = Date.Now.ToString("dd mm yyyy hh:mm:ss")
    End Sub

    Private Sub btnCariObat_Click(sender As Object, e As EventArgs) Handles btnCariObat.Click
        Dim strtampil As String = "SELECT * FROM tb_obat WHERE namaobat like '%" & txtCariNamaObat.Text & "%' ORDER By namaobat"
        Dim strtabel As String = "tb_obat"
        Call TampilData(strtampil, strtabel)
        dgvDaftarObat.DataSource = (ds.Tables("tb_obat"))
        dgvDaftarObat.ReadOnly = True
    End Sub

    Private Sub btnTambah_Click(sender As Object, e As EventArgs) Handles btnTambah.Click
        Call Me.ClearForm()
        btnSimpan.Text = "&Simpan"
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        Dim SQLCari As String
        If dgvDaftarObat.Rows.Item(dgvDaftarObat.CurrentRow.Index).Cells(0).Value.ToString() = "" Then
            MsgBox("Data kosong!", vbInformation, "Pilih Data")
        Else
            id_users = dgvDaftarObat.Rows.Item(dgvDaftarObat.CurrentRow.Index).Cells(0).Value
            SQLCari = "SELECT * FROM tb_obat WHERE id = '" & id_users & "'"
            cmd = New Odbc.OdbcCommand
            cmd.CommandType = CommandType.Text
            cmd.Connection = conn
            cmd.CommandText = SQLCari
            dr = cmd.ExecuteReader()
            If dr.Read Then
                txtNamaObat.Text = dr.Item("namaobat")
                panelFormulirObat.Visible = True
                btnSimpan.Text = "&Update"
            End If
        End If
    End Sub

    Private Sub btnHapus_Click(sender As Object, e As EventArgs) Handles btnHapus.Click
        Dim Hapus, SQLHapus As String
        If dgvDaftarObat.Rows.Item(dgvDaftarObat.CurrentRow.Index).Cells(0).Value.ToString = "" Then
            MsgBox("Data kosong!", vbInformation, "Pilih Data")
        Else
            id_users = dgvDaftarObat.Rows.Item(dgvDaftarObat.CurrentRow.Index).Cells(0).Value
            Hapus = MessageBox.Show("Yakin data ID " & id_users & " mau dihapus ?", "Keluar", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If Hapus = MsgBoxResult.Yes Then
                SQLHapus = "DELETE FROM tb_obat WHERE id = '" & id_users & "'"
                Call KoneksiDB.ProsesSQL(SQLHapus)
                MsgBox("Data sudah terhapus!", vbInformation, "Hapus Data")
                Call Me.RefreshForm()
            End If
        End If
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        Call Me.RefreshForm()
    End Sub

    Private Sub btnSimpan_Click(sender As Object, e As EventArgs) Handles btnSimpan.Click
        If btnSimpan.Text = "&Simpan" Then
            Call Me.Simpan()
        ElseIf btnSimpan.Text = "&Update" Then
            Call Me.Update()
        End If
    End Sub

    Private Sub btnBatal_Click(sender As Object, e As EventArgs) Handles btnBatal.Click
        Call Me.RefreshForm()
    End Sub

    Private Sub dgvObat_DoubleClick(sender As Object, e As EventArgs)
        PilihObat.Show()
    End Sub

    'Private Sub dgvObat_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)
    '    Dim getID = dgvObat.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(0).Value

    'End Sub

    Private Sub btnBelumBayar_Click(sender As Object, e As EventArgs) Handles btnBelumBayar.Click
        Dim dt As New DataTable
        cmd = New Odbc.OdbcCommand("SELECT * FROM tb_pasien WHERE status = 'Menunggu Antrian'", conn)
        If dgvDaftarPasien.Rows.Count = 0 Then
            TLPNoData.Visible = True
            dgvDaftarPasien.Visible = False
        ElseIf dgvDaftarPasien.Rows.Count > 0 Then
            TLPNoData.Visible = False
            dgvDaftarPasien.Visible = True
            da.SelectCommand = cmd
            dt.Clear()
            da.Fill(dt)
            dgvDaftarPasien.DataSource = dt
        End If
    End Sub

    Private Sub DaftarKeranjang_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles DaftarKeranjang.MouseDoubleClick
        PilihObat.Show()
    End Sub
End Class