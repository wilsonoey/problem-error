﻿Imports System.ComponentModel

Public Class ItemKeranjang
#Region "Properties"
    Private _title As String
    Private _itemcount As Integer
    <Category("Custom Props")>
    Public Property Title As String
        Get
            Return _title
        End Get
        Set(ByVal value As String)
            _title = value
            NamaItemObat.Text = value
        End Set
    End Property
    <Category("Custom Props")>
    Public Property ItemCount As Integer
        Get
            Return _itemcount
        End Get
        Set(ByVal value As Integer)
            _itemcount = value
            ItemObat.Text = value
        End Set
    End Property
#End Region
End Class
