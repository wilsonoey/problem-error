﻿Imports System.Data.Odbc

Public Class PilihObat
    Dim id_users As Integer
    Private Sub TampilDataGrid()
        Dim strtampil As String = "SELECT id,namaobat,jumlahobat,hargaobat FROM tb_obat AS a ORDER By namaobat"
        Dim strtabel As String = "tb_obat"
        Call TampilData(strtampil, strtabel)
        dgvPilihDaftarObat.DataSource = (ds.Tables("tb_obat"))
        dgvPilihDaftarObat.ReadOnly = True
    End Sub
    Private Sub JudulGrid()
        dgvPilihDaftarObat.Columns(0).HeaderText = "ID"
        dgvPilihDaftarObat.Columns(1).HeaderText = "Nama Obat"
        dgvPilihDaftarObat.Columns(2).HeaderText = "Jumlah Obat"
        dgvPilihDaftarObat.Columns(3).HeaderText = "Harga Obat"
        dgvPilihDaftarObat.Columns(0).Width = 50
        dgvPilihDaftarObat.Columns(1).Width = 250
        dgvPilihDaftarObat.Columns(2).Width = 150
        dgvPilihDaftarObat.Columns(3).Width = 150
    End Sub
    Private Sub RefreshForm()
        Call Me.TampilDataGrid()
        Call Me.JudulGrid()
        dgvPilihDaftarObat.Focus()
    End Sub

    Private Sub TindakanDaftarObat_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Me.RefreshForm()
    End Sub

    Private Sub txtCariPilihObat_TextChanged(sender As Object, e As EventArgs) Handles txtCariPilihObat.TextChanged
        Dim strtampil As String = "SELECT id,namaobat,jumlahobat,hargaobat FROM tb_obat WHERE namaobat like '%" & txtCariPilihObat.Text & "%' ORDER By namaobat"
        Dim strtabel As String = "tb_obat"
        Call TampilData(strtampil, strtabel)
        dgvPilihDaftarObat.DataSource = (ds.Tables("tb_obat"))
        dgvPilihDaftarObat.ReadOnly = True
    End Sub

    Public Class Obat
        Property Id As Integer
        Property Nama As String
        Property Jumlahobat As String
        Property Hargaobat As Decimal
    End Class

    Private Sub btnPilih_Click(sender As Object, e As EventArgs) Handles btnPilih.Click
        Dim id = dgvPilihDaftarObat.Rows.Item(dgvPilihDaftarObat.CurrentRow.Index).Cells(0).Value.ToString()

        If id = "" Then
            MsgBox("Data kosong!", vbInformation, "Pilih Data")

        Else
            Dim id_barang = CInt(id)
            Dim sql = "SELECT namaobat, jumlahobat, hargaobat FROM tb_obat WHERE id = '" & id_barang & "'"

            Using conn As New OdbcConnection, cmd As New OdbcCommand(sql, conn)

                cmd.Parameters.Add("@id", OdbcType.Int).Value = id_barang
                conn.Open()
                Dim rdr = cmd.ExecuteReader()

                If rdr.Read() Then
                    Dim d As New Obat() With {.Id = id_barang,
                                              .Nama = rdr.GetString(0),
                                              .Jumlahobat = rdr.GetString(1),
                                              .Hargaobat = rdr.GetDecimal(2)}

                    'TODO: Add d to whatever collection contains the list of drugs.
                    Dim listItems As ItemKeranjang() = New ItemKeranjang(sql.Length) {d.Id}
                    Dim judul As Object() = New Object(sql.Length - 1) {}
                    Dim i As Integer
                    For i = 0 To listItems.Length - 1
                        If i < judul.Length Then
                            listItems(i) = New ItemKeranjang()
                            listItems(i).Title = judul(i)
                            If i <> 0 Then
                                ApotekerDashboard.DaftarKeranjang.Controls.Add(listItems(i))
                            End If
                        End If
                    Next
                    Me.Close()
                End If

            End Using

        End If

    End Sub

    'private sub btnpilih_click(sender as object, e as eventargs) handles btnpilih.click
    '    dim sqlcari, sqlnama as string
    '    dim id_barang as integer
    '    if dgvpilihdaftarobat.rows.item(dgvpilihdaftarobat.currentrow.index).cells(0).value.tostring = "" then
    '        msgbox("data kosong!", vbinformation, "pilih data")
    '    else
    '        id_barang = dgvpilihdaftarobat.rows.item(dgvpilihdaftarobat.currentrow.index).cells(0).value
    '        sqlcari = "select id,namaobat,jumlahobat,hargaobat from tb_obat where id = '" & id_barang & "'"
    '        cmd = new odbc.odbccommand
    '        cmd.commandtype = commandtype.text
    '        cmd.connection = conn
    '        cmd.commandtext = sqlcari
    '        dr = cmd.executereader()
    '        if dr.read then
    '            sqlnama = dr.item("namaobat")
    '            dim listitems as itemkeranjang() = new itemkeranjang(sqlcari.length) {}
    '            dim judul as object() = new object(sqlcari.length - 1) {}
    '            dim i as integer
    '            for i = 0 to listitems.length - 1
    '                if i < judul.length then
    '                    listitems(i) = new itemkeranjang()
    '                    listitems(i).title = judul(i)
    '                    if i <> 0 then
    '                        apotekerdashboard.daftarkeranjang.controls.add(listitems(i))
    '                    end if
    '                end if
    '            next
    '            me.close()
    '        end if
    '    end if
    'end sub
End Class