﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class PilihStokObat
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblNamaObat = New System.Windows.Forms.Label()
        Me.txtStokObat = New System.Windows.Forms.TextBox()
        Me.btnUbahStok = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblNamaObat
        '
        Me.lblNamaObat.AutoSize = True
        Me.lblNamaObat.Location = New System.Drawing.Point(30, 59)
        Me.lblNamaObat.Name = "lblNamaObat"
        Me.lblNamaObat.Size = New System.Drawing.Size(51, 17)
        Me.lblNamaObat.TabIndex = 0
        Me.lblNamaObat.Text = "Label1"
        '
        'txtStokObat
        '
        Me.txtStokObat.Location = New System.Drawing.Point(33, 113)
        Me.txtStokObat.Name = "txtStokObat"
        Me.txtStokObat.Size = New System.Drawing.Size(273, 22)
        Me.txtStokObat.TabIndex = 1
        '
        'btnUbahStok
        '
        Me.btnUbahStok.Location = New System.Drawing.Point(118, 186)
        Me.btnUbahStok.Name = "btnUbahStok"
        Me.btnUbahStok.Size = New System.Drawing.Size(75, 23)
        Me.btnUbahStok.TabIndex = 2
        Me.btnUbahStok.Text = "Simpan"
        Me.btnUbahStok.UseVisualStyleBackColor = True
        '
        'PilihStokObat
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(345, 253)
        Me.Controls.Add(Me.btnUbahStok)
        Me.Controls.Add(Me.txtStokObat)
        Me.Controls.Add(Me.lblNamaObat)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "PilihStokObat"
        Me.ShowIcon = False
        Me.Text = "Pilih Stok Obat"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblNamaObat As Label
    Friend WithEvents txtStokObat As TextBox
    Friend WithEvents btnUbahStok As Button
End Class
