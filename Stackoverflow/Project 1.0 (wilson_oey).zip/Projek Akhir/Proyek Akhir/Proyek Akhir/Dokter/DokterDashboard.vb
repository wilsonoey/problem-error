﻿Public Class DokterDashboard
    Private Sub TampilDataGrid_DataPasien()
        Dim strtampil As String = "SELECT * FROM tb_pasien WHERE status = 'Menunggu Dokter'"
        Dim strtabel As String = "tb_pasien"
        Call TampilData(strtampil, strtabel)
        dgvDaftarPasien.DataSource = (ds.Tables("tb_pasien"))
        dgvDaftarPasien.ReadOnly = True
        If KoneksiDB.CariData(strtampil) And dgvDaftarPasien.Rows.Count > 0 Then
            TLPNoData.Visible = False
            dgvDaftarPasien.Visible = True
        Else
            TLPNoData.Visible = True
            dgvDaftarPasien.Visible = False
        End If
    End Sub
    Private Sub JudulGrid_DataPasien()
        dgvDaftarPasien.Columns(0).HeaderText = "ID"
        dgvDaftarPasien.Columns(1).HeaderText = "NIK"
        dgvDaftarPasien.Columns(2).HeaderText = "Username"
        dgvDaftarPasien.Columns(3).HeaderText = "Nama Lengkap"
        dgvDaftarPasien.Columns(4).HeaderText = "Umur"
        dgvDaftarPasien.Columns(5).HeaderText = "Jenis Kelamin"
        dgvDaftarPasien.Columns(6).HeaderText = "Alamat"
        dgvDaftarPasien.Columns(7).HeaderText = "Faskes"
        dgvDaftarPasien.Columns(8).HeaderText = "Status"
        dgvDaftarPasien.Columns(0).Width = 50
        dgvDaftarPasien.Columns(1).Width = 150
        dgvDaftarPasien.Columns(2).Width = 100
        dgvDaftarPasien.Columns(3).Width = 200
        dgvDaftarPasien.Columns(4).Width = 50
        dgvDaftarPasien.Columns(5).Width = 100
        dgvDaftarPasien.Columns(6).Width = 200
        dgvDaftarPasien.Columns(7).Width = 200
        dgvDaftarPasien.Columns(8).Width = 150
    End Sub
    Private Sub RefreshForm_DataPasien()
        Call Me.TampilDataGrid_DataPasien()
        Call Me.JudulGrid_DataPasien()
        dgvDaftarPasien.Focus()
    End Sub


    'Private Sub TampilDataGrid_DataRiwayatPasien()
    '    Dim getID As Integer
    '    getID = dgvRiwayatPasien.Rows.Item(dgvRiwayatPasien.CurrentRow.Index).Cells(0).Value
    '    Dim strtampil As String = "SELECT * FROM tb_dokter WHERE id='" & getID & "'"
    '    Dim strtabel As String = "tb_dokter"
    '    Call TampilData(strtampil, strtabel)
    '    dgvDaftarPasien.DataSource = (ds.Tables("tb_dokter"))
    '    dgvDaftarPasien.ReadOnly = True
    '    If KoneksiDB.CariData(strtampil) And dgvDaftarPasien.Rows.Count > 0 Then
    '        TLPNoData.Visible = False
    '        dgvRiwayatPasien.Visible = True
    '    Else
    '        TLPNoData.Visible = True
    '        dgvRiwayatPasien.Visible = False
    '    End If
    'End Sub
    'Private Sub JudulGrid_DataRiwayatPasien()
    '    dgvRiwayatPasien.Columns(0).HeaderText = "ID"
    '    dgvRiwayatPasien.Columns(1).HeaderText = "NIK"
    '    dgvRiwayatPasien.Columns(2).HeaderText = "Username"
    '    dgvRiwayatPasien.Columns(3).HeaderText = "Nama Lengkap"
    '    dgvRiwayatPasien.Columns(4).HeaderText = "Umur"
    '    dgvRiwayatPasien.Columns(5).HeaderText = "Jenis Kelamin"
    '    dgvRiwayatPasien.Columns(6).HeaderText = "Alamat"
    '    dgvRiwayatPasien.Columns(7).HeaderText = "Faskes"
    '    dgvRiwayatPasien.Columns(8).HeaderText = "diagnosa"
    '    dgvRiwayatPasien.Columns(9).HeaderText = "obat"
    '    dgvRiwayatPasien.Columns(10).HeaderText = "Harga Konsultasi"
    '    dgvRiwayatPasien.Columns(11).HeaderText = "Status Pembayaran"
    '    dgvRiwayatPasien.Columns(0).Width = 50
    '    dgvRiwayatPasien.Columns(1).Width = 150
    '    dgvRiwayatPasien.Columns(2).Width = 100
    '    dgvRiwayatPasien.Columns(3).Width = 200
    '    dgvRiwayatPasien.Columns(4).Width = 50
    '    dgvRiwayatPasien.Columns(5).Width = 100
    '    dgvRiwayatPasien.Columns(6).Width = 200
    '    dgvRiwayatPasien.Columns(7).Width = 200
    '    dgvRiwayatPasien.Columns(8).Width = 150
    '    dgvRiwayatPasien.Columns(9).Width = 200
    '    dgvRiwayatPasien.Columns(10).Width = 200
    '    dgvRiwayatPasien.Columns(11).Width = 150
    'End Sub
    'Private Sub RefreshForm_DataRiwayatPasien()
    '    Call Me.TampilDataGrid_DataRiwayatPasien()
    '    Call Me.JudulGrid_DataRiwayatPasien()
    '    dgvDaftarPasien.Focus()
    'End Sub


    Private Sub DokterDashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call KoneksiDB.KonekDB()
        Call Me.RefreshForm_DataPasien()
        'Call Me.RefreshForm_DataRiwayatPasien()
        textKeterangan.Focus()
        jadwal.Enabled = True
    End Sub
    Private Sub showMenuItem_Click(sender As Object, e As EventArgs) Handles showMenuItem.Click
        listMenuItem.Visible = True
        showMenuItem.Visible = False
    End Sub
    Private Sub hideMenuItem_Click(sender As Object, e As EventArgs) Handles hideMenuItem.Click
        listMenuItem.Visible = False
        showMenuItem.Visible = True
    End Sub
    Private Sub buttonDashboard_Click(sender As Object, e As EventArgs) Handles buttonDashboard.Click
        panelDashboard.Visible = True
        panelDaftarPasien.Visible = False
        panelTransaksi.Visible = False
        panelLaporan.Visible = False
        panelAkun.Visible = False
    End Sub
    Private Sub buttonDaftar_Pasien_Click(sender As Object, e As EventArgs) Handles buttonDaftar_Pasien.Click
        panelDashboard.Visible = False
        panelDaftarPasien.Visible = True
        panelTransaksi.Visible = False
        panelLaporan.Visible = False
        panelAkun.Visible = False
    End Sub
    Private Sub buttonTransaksi_Click(sender As Object, e As EventArgs) Handles buttonTransaksi.Click
        panelDashboard.Visible = False
        panelDaftarPasien.Visible = False
        panelTransaksi.Visible = True
        panelLaporan.Visible = False
        panelAkun.Visible = False
    End Sub
    Private Sub buttonLaporan_Click(sender As Object, e As EventArgs) Handles buttonLaporan.Click
        panelDashboard.Visible = False
        panelDaftarPasien.Visible = False
        panelTransaksi.Visible = False
        panelLaporan.Visible = True
        panelAkun.Visible = False
    End Sub
    Private Sub buttonAkun_Click(sender As Object, e As EventArgs) Handles buttonAkun.Click
        panelDashboard.Visible = False
        panelDaftarPasien.Visible = False
        panelTransaksi.Visible = False
        panelLaporan.Visible = False
        panelAkun.Visible = True
    End Sub
    Private Sub buttonKeluar_Click(sender As Object, e As EventArgs) Handles buttonKeluar.Click
        Me.Close()
    End Sub

    Private Sub btnCariPasien_Click(sender As Object, e As EventArgs) Handles btnCariPasien.Click
        Dim strtampil As String = "SELECT * FROM tb_pasien WHERE username like '%" & txtCariPasien.Text & "%' ORDER By username"
        Dim strtabel As String = "tb_pasien"
        Call TampilData(strtampil, strtabel)
        dgvDaftarPasien.DataSource = (ds.Tables("tb_pasien"))
        dgvDaftarPasien.ReadOnly = True
    End Sub
    Private Sub dgvDaftarPasien_CellMouseDoubleClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgvDaftarPasien.CellMouseDoubleClick
        Dim getID = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(0).Value
        Dim getNIK = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(1).Value
        Dim getUser_Name = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(2).Value
        Dim getNama_Lengkap = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(3).Value
        Dim getUmur = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(4).Value
        Dim getJenis_Kelamin = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(5).Value
        Dim getAlamat = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(6).Value
        Dim getFaskes = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(7).Value
        If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 Then
            Dim selectedRow As DataGridViewRow = dgvDaftarPasien.Rows(e.RowIndex)
            panelBerandaDP.Visible = False
            panelTindakanDP.Visible = True
            txt_IP_NIK.Text = getNIK
            txt_IP_UserName.Text = getUser_Name
            txt_IP_NamaLengkap.Text = getNama_Lengkap
            txt_IP_Umur.Text = getUmur
            txt_IP_JenisKelamin.Text = getJenis_Kelamin
            txt_IP_Alamat.Text = getAlamat
            txt_IP_Faskes.Text = getFaskes

            'Dim dt As New DataTable
            'cmd = New Odbc.OdbcCommand("SELECT * FROM tb_dokter WHERE id='" & getID & "'", conn)
            'If dgvRiwayatPasien.Rows.Count = 0 Then
            '    panelTindakanDP.Visible = True
            'ElseIf dgvDaftarPasien.Rows.Count > 0 Then
            '    TLPNoData.Visible = False
            '    dgvRiwayatPasien.Visible = True
            '    da.SelectCommand = cmd
            '    dt.Clear()
            '    da.Fill(dt)
            '    dgvDaftarPasien.DataSource = dt
            'End If
        End If
    End Sub

    Private Sub btn_IP_Kembali_Click(sender As Object, e As EventArgs) Handles btn_IP_Kembali.Click
        panelBerandaDP.Visible = True
        panelTindakanDP.Visible = False
    End Sub

    Private Sub btn_IP_Batal_Click(sender As Object, e As EventArgs) Handles btn_IP_Batal.Click
        panelBerandaDP.Visible = True
        panelTindakanDP.Visible = False
    End Sub
    Private Sub jadwal_Tick(sender As Object, e As EventArgs) Handles jadwal.Tick
        txtJadwal.Text = Date.Now.ToString("dd mm yyyy hh:mm:ss")
    End Sub

    Private Sub btn_IP_AjukanApoteker_Click(sender As Object, e As EventArgs) Handles btn_IP_AjukanApoteker.Click
        Dim getID = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(0).Value
        Dim getNIK = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(1).Value
        Dim getUser_Name = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(2).Value
        Dim getNama_Lengkap = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(3).Value
        Dim getUmur = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(4).Value
        Dim getJenis_Kelamin = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(5).Value
        Dim getAlamat = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(6).Value
        Dim getFaskes = dgvDaftarPasien.Rows.Item(dgvDaftarPasien.CurrentRow.Index).Cells(7).Value
        Dim SQLSimpanApoteker As String = "INSERT INTO tb_dokter (nik,username,namalengkap,umur,jeniskelamin,alamat,faskes,diagnosa,obat,hargakonsultasi,statuspembayaran) 
VALUES ('" & getNIK & "','" & getUser_Name & "','" & getNama_Lengkap & "','" & getUmur & "','" & getJenis_Kelamin & "','" & getAlamat & "','" & getFaskes & "',
'" & txt_IP_Diagnosa.Text & "','" & txt_IP_Terapi.Text & "','" & txt_IP_Harga.Text & "','Menunggu Pembayaran')"
        Call KoneksiDB.ProsesSQL(SQLSimpanApoteker)
        panelBerandaDP.Visible = True
        panelTindakanDP.Visible = False
    End Sub
End Class