﻿Imports System.Data
Imports System.Data.Odbc
Module KoneksiDB
    Public conn As OdbcConnection
    Public da As OdbcDataAdapter
    Public ds As DataSet
    Public da2 As OdbcDataAdapter
    Public ds2 As DataSet
    Public cmd As OdbcCommand
    Public dr As OdbcDataReader
    Public str As String
    Public Sub KonekDB()
        Try
            conn = New OdbcConnection("dsn=db_klinik")
            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Sub TampilData(ByVal sqldata As String, ByVal sqltabel As String)
        Try
            da = New Data.Odbc.OdbcDataAdapter(sqldata, conn)
            ds = New DataSet
            ds.Clear()
            da.Fill(ds, sqltabel)
        Catch ex As Exception
            MsgBox(ex.ToString(), 16, "Error")
        End Try
    End Sub
    Sub ProsesSQL(ByVal sqlisi As String)
        Try
            Call KonekDB()
            Dim sqlquery As New Odbc.OdbcCommand With {
                .Connection = conn,
                .CommandType = CommandType.Text,
                .CommandText = sqlisi
            }
            sqlquery.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString(), 16, "Error")
        End Try
    End Sub
    Function CariData(ByVal sqlisi As String) As Boolean
        Try
            Call KonekDB()
            cmd = New Odbc.OdbcCommand With {
                .CommandType = CommandType.Text,
                .Connection = conn,
                .CommandText = sqlisi
            }
            dr = cmd.ExecuteReader()
            If dr.HasRows Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString(), 16, "Error")
        End Try
        Return CariData
    End Function
End Module
