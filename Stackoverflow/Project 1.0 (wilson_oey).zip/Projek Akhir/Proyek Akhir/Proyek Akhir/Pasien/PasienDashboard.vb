﻿Public Class PasienDashboard
    Private Sub showMenuItem_Click(sender As Object, e As EventArgs) Handles showMenuItem.Click
        listMenuItem.Visible = True
        showMenuItem.Visible = False
    End Sub
    Private Sub hideMenuItem_Click(sender As Object, e As EventArgs) Handles hideMenuItem.Click
        listMenuItem.Visible = False
        showMenuItem.Visible = True
    End Sub
    Private Sub ApotekerDashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        textDashboard.Focus()
    End Sub
    Private Sub buttonDashboard_Click(sender As Object, e As EventArgs) Handles buttonDashboard.Click
        panelDashboard.Visible = True
        panelRiwayat.Visible = False
        panelAkun.Visible = False
    End Sub
    Private Sub buttonRiwayat_Click(sender As Object, e As EventArgs) Handles buttonRiwayat.Click
        panelDashboard.Visible = False
        panelRiwayat.Visible = True
        panelAkun.Visible = False
    End Sub
    Private Sub buttonAkun_Click(sender As Object, e As EventArgs) Handles buttonAkun.Click
        panelDashboard.Visible = False
        panelRiwayat.Visible = False
        panelAkun.Visible = True
    End Sub
    Private Sub buttonKeluar_Click(sender As Object, e As EventArgs) Handles buttonKeluar.Click
        Me.Close()
    End Sub
End Class